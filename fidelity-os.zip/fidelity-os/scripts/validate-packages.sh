#!/bin/bash
# FidelityOS Package Validation Script
# Run this before building to check if all packages exist

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║   FidelityOS Package Validator           ║"
echo "╚══════════════════════════════════════════╝"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Update package cache
echo "[*] Updating package cache..."
apt-get update -qq

total=0
missing=0
found=0

for list in "$PROJECT_DIR"/config/package-lists/*.list.chroot; do
    [ -f "$list" ] || continue
    list_name=$(basename "$list")
    echo ""
    echo -e "${YELLOW}Checking: $list_name${NC}"
    
    while IFS= read -r pkg || [ -n "$pkg" ]; do
        # Skip comments and empty lines
        [[ "$pkg" =~ ^#.*$ ]] && continue
        [[ -z "${pkg// }" ]] && continue
        
        ((total++))
        
        if apt-cache show "$pkg" &>/dev/null 2>&1; then
            ((found++))
        else
            echo -e "  ${RED}✗ Not found: $pkg${NC}"
            ((missing++))
        fi
    done < "$list"
done

echo ""
echo "════════════════════════════════════════════"
echo -e "Total packages: $total"
echo -e "${GREEN}Found: $found${NC}"
if [ $missing -gt 0 ]; then
    echo -e "${RED}Missing: $missing${NC}"
    echo ""
    echo -e "${RED}⚠ Build may fail! Fix missing packages first.${NC}"
    exit 1
else
    echo -e "${GREEN}✓ All packages validated successfully!${NC}"
    exit 0
fi
