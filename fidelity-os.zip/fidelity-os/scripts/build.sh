#!/bin/bash
# FidelityOS Build Script
# Supports: amd64 (x86_64) and arm64 (Raspberry Pi)
#
# Usage:
#   sudo ./scripts/build.sh              # Build for current architecture
#   sudo ./scripts/build.sh --skip-rust  # Skip Rust installation (faster)
#   sudo ./scripts/build.sh --quick      # Quick build (skip validation)
#   sudo FIDELITY_ARCH=amd64 ./scripts/build.sh   # Force x86_64

set -uo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# Logging functions
log_info() { echo -e "${GREEN}[✓]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[!]${NC} $1"; }
log_error() { echo -e "${RED}[✗]${NC} $1"; }
log_step() { echo -e "${BLUE}[*]${NC} $1"; }
log_header() { echo -e "\n${CYAN}━━━ $1 ━━━${NC}\n"; }

# Build options
SKIP_RUST=0
QUICK_BUILD=0
SKIP_VALIDATION=0

# Parse arguments
for arg in "$@"; do
    case $arg in
        --skip-rust)
            SKIP_RUST=1
            ;;
        --quick)
            QUICK_BUILD=1
            SKIP_VALIDATION=1
            ;;
        --skip-validation)
            SKIP_VALIDATION=1
            ;;
        --help|-h)
            echo "FidelityOS Build Script"
            echo ""
            echo "Usage: sudo ./scripts/build.sh [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --skip-rust       Skip Rust toolchain installation"
            echo "  --quick           Quick build (skip validation)"
            echo "  --skip-validation Skip package validation"
            echo "  --help            Show this help"
            exit 0
            ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
LOG_FILE="$PROJECT_DIR/build.log"
START_TIME=$(date +%s)

# Determine target architecture
if [ -n "${FIDELITY_ARCH:-}" ]; then
    TARGET_ARCH="$FIDELITY_ARCH"
else
    TARGET_ARCH=$(dpkg --print-architecture)
fi

# Start logging
exec > >(tee -a "$LOG_FILE") 2>&1

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║       FidelityOS Build System            ║"
echo "╠══════════════════════════════════════════╣"
echo "║  Target: $TARGET_ARCH                            ║"
echo "║  Date: $(date '+%Y-%m-%d %H:%M')                  ║"
echo "║  Log: build.log                          ║"
echo "╚══════════════════════════════════════════╝"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    log_error "Please run with sudo: sudo ./scripts/build.sh"
    exit 1
fi

# Error handler
handle_error() {
    local line_no=$1
    local error_code=$2
    log_error "Build failed at line $line_no (exit code: $error_code)"
    log_error "Check build.log for details"
    
    # Show last 20 lines of log
    echo ""
    echo "Last 20 lines of build output:"
    echo "─────────────────────────────────"
    tail -20 "$LOG_FILE" 2>/dev/null || true
    
    exit $error_code
}

trap 'handle_error ${LINENO} $?' ERR

# Check for required commands
check_dependencies() {
    log_header "Checking Dependencies"
    
    local missing=()
    local required=(debootstrap lb curl wget)
    
    for cmd in "${required[@]}"; do
        if command -v "$cmd" &> /dev/null; then
            log_info "$cmd found"
        else
            missing+=("$cmd")
        fi
    done
    
    if [ ${#missing[@]} -gt 0 ]; then
        log_step "Installing missing dependencies: ${missing[*]}"
        apt-get update -qq
        apt-get install -y -qq live-build debootstrap curl wget
    fi
    
    log_info "All dependencies satisfied"
}

# Fix CRLF line endings
fix_line_endings() {
    log_header "Fixing Line Endings"
    
    local count=0
    while IFS= read -r -d '' file; do
        if file "$file" | grep -q "CRLF"; then
            sed -i 's/\r$//' "$file"
            ((count++))
        fi
    done < <(find "$PROJECT_DIR" -type f \( -name "*.sh" -o -name "*.chroot" -o -name "*.list.chroot" -o -path "*/auto/*" \) -print0 2>/dev/null)
    
    # Also fix with sed regardless (safer)
    find "$PROJECT_DIR" -type f \( -name "*.sh" -o -name "*.chroot" -o -name "*.list.chroot" -o -path "*/auto/*" \) -exec sed -i 's/\r$//' {} \; 2>/dev/null || true
    
    log_info "Line endings fixed ($count files had CRLF)"
}

# Validate package lists
validate_packages() {
    if [ "$SKIP_VALIDATION" = "1" ]; then
        log_warn "Skipping package validation (--skip-validation)"
        return 0
    fi
    
    log_header "Validating Package Lists"
    
    local errors=0
    local total=0
    
    for list in "$PROJECT_DIR"/config/package-lists/*.list.chroot; do
        [ -f "$list" ] || continue
        local list_name=$(basename "$list")
        log_step "Checking $list_name..."
        
        while IFS= read -r pkg || [ -n "$pkg" ]; do
            [[ "$pkg" =~ ^#.*$ ]] && continue
            [[ -z "${pkg// }" ]] && continue
            ((total++))
            
            if ! apt-cache show "$pkg" &>/dev/null 2>&1; then
                log_warn "  Package not found: $pkg"
                ((errors++))
            fi
        done < "$list"
    done
    
    if [ $errors -gt 0 ]; then
        log_warn "Found $errors/$total packages with issues"
        log_warn "Build may fail. Consider fixing package lists."
    else
        log_info "All $total packages validated"
    fi
}

# Disable problematic hooks if requested
configure_hooks() {
    log_header "Configuring Hooks"
    
    if [ "$SKIP_RUST" = "1" ]; then
        local rust_hook="$PROJECT_DIR/config/hooks/live/0055-install-rust.hook.chroot"
        if [ -f "$rust_hook" ]; then
            mv "$rust_hook" "${rust_hook}.disabled"
            log_warn "Rust installation disabled (--skip-rust)"
        fi
    fi
    
    # Make all hooks executable
    find "$PROJECT_DIR/config/hooks" -name "*.hook.chroot" -exec chmod +x {} \; 2>/dev/null || true
    
    local hook_count=$(find "$PROJECT_DIR/config/hooks/live" -name "*.hook.chroot" 2>/dev/null | wc -l)
    log_info "$hook_count hooks configured"
}

# Copy assets
copy_assets() {
    log_header "Copying Assets"
    
    # Background image
    if [ -f "$PROJECT_DIR/background.png" ]; then
        mkdir -p "$PROJECT_DIR/config/includes.chroot/usr/share/backgrounds/fidelity"
        cp "$PROJECT_DIR/background.png" "$PROJECT_DIR/config/includes.chroot/usr/share/backgrounds/fidelity/default.png"
        log_info "Background image copied"
    else
        log_warn "No background.png found"
    fi
    
    # Logo
    if [ -f "$PROJECT_DIR/logo.png" ]; then
        mkdir -p "$PROJECT_DIR/config/includes.chroot/opt/fidelity-branding"
        cp "$PROJECT_DIR/logo.png" "$PROJECT_DIR/config/includes.chroot/opt/fidelity-branding/logo.png"
        log_info "Logo copied"
    else
        log_warn "No logo.png found"
    fi
    
    # Rust tools source
    if [ -d "$PROJECT_DIR/tools" ]; then
        mkdir -p "$PROJECT_DIR/config/includes.chroot/opt/fidelity-tools"
        cp -r "$PROJECT_DIR/tools/"* "$PROJECT_DIR/config/includes.chroot/opt/fidelity-tools/"
        log_info "Rust tools source copied"
    fi
    
    # ASCII art
    if [ -f "$PROJECT_DIR/ascii-art.txt" ]; then
        mkdir -p "$PROJECT_DIR/config/includes.chroot/usr/share/fidelity"
        cp "$PROJECT_DIR/ascii-art.txt" "$PROJECT_DIR/config/includes.chroot/usr/share/fidelity/"
        log_info "ASCII art copied"
    fi
}

# Cross-architecture setup
setup_cross_build() {
    HOST_ARCH=$(dpkg --print-architecture)
    if [ "$TARGET_ARCH" != "$HOST_ARCH" ]; then
        log_header "Cross-Build Setup"
        log_warn "Cross-build: $HOST_ARCH → $TARGET_ARCH"
        apt-get install -y -qq qemu-user-static binfmt-support
        
        if [ ! -f /proc/sys/fs/binfmt_misc/status ]; then
            log_error "binfmt_misc not available"
            exit 1
        fi
        log_info "Cross-build environment ready"
    fi
}

# Main build
run_build() {
    log_header "Building ISO"
    
    cd "$PROJECT_DIR"
    
    # Make auto scripts executable
    chmod +x auto/* 2>/dev/null || true
    
    # Export architecture
    export FIDELITY_ARCH="$TARGET_ARCH"
    
    # Clean
    log_step "Cleaning previous build..."
    lb clean 2>/dev/null || true
    
    # Configure
    log_step "Configuring live-build..."
    if ! lb config 2>&1; then
        log_error "lb config failed"
        exit 1
    fi
    log_info "Configuration complete"
    
    # Build
    log_step "Building ISO (this takes 30-60 minutes)..."
    echo ""
    
    if ! lb build 2>&1; then
        log_error "lb build failed"
        exit 1
    fi
}

# Summary
show_summary() {
    local end_time=$(date +%s)
    local duration=$((end_time - START_TIME))
    local minutes=$((duration / 60))
    local seconds=$((duration % 60))
    
    echo ""
    echo "╔══════════════════════════════════════════╗"
    echo "║          Build Complete!                 ║"
    echo "╚══════════════════════════════════════════╝"
    echo ""
    
    local iso_file=$(ls -1 "$PROJECT_DIR"/*.iso 2>/dev/null | head -1)
    
    if [ -n "$iso_file" ] && [ -f "$iso_file" ]; then
        local iso_size=$(du -h "$iso_file" | cut -f1)
        local iso_name=$(basename "$iso_file")
        local sha256=$(sha256sum "$iso_file" | cut -d' ' -f1)
        
        log_info "ISO: $iso_name"
        log_info "Size: $iso_size"
        log_info "SHA256: ${sha256:0:16}..."
        log_info "Duration: ${minutes}m ${seconds}s"
        echo ""
        echo "To download:"
        echo "  scp root@\$(hostname -I | awk '{print \$1}'):$iso_file ."
    else
        log_error "No ISO file found!"
        log_error "Check build.log for errors"
    fi
    
    echo ""
}

# Main
main() {
    cd "$PROJECT_DIR"
    
    check_dependencies
    fix_line_endings
    setup_cross_build
    configure_hooks
    validate_packages
    copy_assets
    run_build
    show_summary
}

main
