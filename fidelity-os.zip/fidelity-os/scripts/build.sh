#!/bin/bash
# FidelityOS Build Script
# Supports: amd64 (x86_64) and arm64 (Raspberry Pi)
#
# Usage:
#   sudo ./scripts/build.sh          # Build for current architecture
#   sudo FIDELITY_ARCH=amd64 ./scripts/build.sh   # Force x86_64
#   sudo FIDELITY_ARCH=arm64 ./scripts/build.sh   # Force ARM64

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Determine target architecture
if [ -n "$FIDELITY_ARCH" ]; then
    TARGET_ARCH="$FIDELITY_ARCH"
else
    TARGET_ARCH=$(dpkg --print-architecture)
fi

echo "=========================================="
echo "  FidelityOS Build Script"
echo "  Target: $TARGET_ARCH"
echo "=========================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run with sudo: sudo ./scripts/build.sh"
    exit 1
fi

# Install live-build if not present
if ! command -v lb &> /dev/null; then
    echo "[*] Installing live-build..."
    apt-get update
    apt-get install -y live-build debootstrap
fi

# For cross-architecture builds, install qemu
HOST_ARCH=$(dpkg --print-architecture)
if [ "$TARGET_ARCH" != "$HOST_ARCH" ]; then
    echo "[*] Cross-build detected ($HOST_ARCH -> $TARGET_ARCH)"
    echo "[*] Installing qemu-user-static for cross-compilation..."
    apt-get install -y qemu-user-static binfmt-support
fi

# Navigate to project directory
cd "$PROJECT_DIR"

# Make auto scripts executable
chmod +x auto/* 2>/dev/null || true

# Update version with build date
BUILD_DATE=$(date +%Y-%m-%d)
sed -i "s/FIDELITY_BUILD_DATE=\"\"/FIDELITY_BUILD_DATE=\"$BUILD_DATE\"/" \
    config/includes.chroot/etc/fidelity/version 2>/dev/null || true

# Make hook scripts executable
find config/hooks -name "*.hook.chroot" -exec chmod +x {} \; 2>/dev/null || true

# Export architecture for auto/config
export FIDELITY_ARCH="$TARGET_ARCH"

# Clean previous build
echo "[*] Cleaning previous build..."
lb clean

# Configure
echo "[*] Configuring live-build for $TARGET_ARCH..."
lb config

# Build
echo "[*] Building ISO (this will take a while)..."
lb build

echo "=========================================="
echo "  Build complete!"
echo "  ISO: $(ls -1 fidelity-os-*.iso 2>/dev/null || echo 'Check for .iso file')"
echo "=========================================="
