#!/bin/bash
# FidelityOS Build Script
# Supports: amd64 (x86_64) and arm64 (Raspberry Pi)
#
# Usage:
#   sudo ./scripts/build.sh          # Build for current architecture
#   sudo FIDELITY_ARCH=amd64 ./scripts/build.sh   # Force x86_64
#   sudo FIDELITY_ARCH=arm64 ./scripts/build.sh   # Force ARM64

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() { echo -e "${GREEN}[*]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[!]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Determine target architecture
if [ -n "${FIDELITY_ARCH:-}" ]; then
    TARGET_ARCH="$FIDELITY_ARCH"
else
    TARGET_ARCH=$(dpkg --print-architecture)
fi

echo "=========================================="
echo "  FidelityOS Build Script"
echo "  Target: $TARGET_ARCH"
echo "  Date: $(date)"
echo "=========================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    log_error "Please run with sudo: sudo ./scripts/build.sh"
    exit 1
fi

# Check for required commands
check_dependencies() {
    local missing=()
    for cmd in debootstrap lb; do
        if ! command -v "$cmd" &> /dev/null; then
            missing+=("$cmd")
        fi
    done
    
    if [ ${#missing[@]} -gt 0 ]; then
        log_info "Installing missing dependencies: ${missing[*]}"
        apt-get update
        apt-get install -y live-build debootstrap
    fi
}

# Fix CRLF line endings in all scripts
fix_line_endings() {
    log_info "Fixing line endings..."
    if command -v dos2unix &> /dev/null; then
        find "$PROJECT_DIR" -type f \( -name "*.sh" -o -name "*.chroot" -o -path "*/auto/*" \) -exec dos2unix {} \; 2>/dev/null || true
    else
        # Fallback using sed
        find "$PROJECT_DIR" -type f \( -name "*.sh" -o -name "*.chroot" -o -path "*/auto/*" \) -exec sed -i 's/\r$//' {} \; 2>/dev/null || true
    fi
}

# Validate package lists
validate_packages() {
    log_info "Validating package lists..."
    local errors=0
    
    for list in "$PROJECT_DIR"/config/package-lists/*.list.chroot; do
        if [ -f "$list" ]; then
            while IFS= read -r pkg || [ -n "$pkg" ]; do
                # Skip comments and empty lines
                [[ "$pkg" =~ ^#.*$ ]] && continue
                [[ -z "${pkg// }" ]] && continue
                
                # Check if package exists (basic check)
                if ! apt-cache show "$pkg" &>/dev/null; then
                    log_warn "Package may not exist: $pkg (in $(basename "$list"))"
                    ((errors++)) || true
                fi
            done < "$list"
        fi
    done
    
    if [ $errors -gt 0 ]; then
        log_warn "Found $errors potential package issues. Build may fail."
        read -p "Continue anyway? [y/N] " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# For cross-architecture builds
setup_cross_build() {
    HOST_ARCH=$(dpkg --print-architecture)
    if [ "$TARGET_ARCH" != "$HOST_ARCH" ]; then
        log_warn "Cross-build detected ($HOST_ARCH -> $TARGET_ARCH)"
        log_info "Installing qemu-user-static for cross-compilation..."
        apt-get install -y qemu-user-static binfmt-support
        
        # Verify binfmt is working
        if [ ! -f /proc/sys/fs/binfmt_misc/status ]; then
            log_error "binfmt_misc not available. Cross-compilation may fail."
            exit 1
        fi
    fi
}

# Clean up on error
cleanup_on_error() {
    log_error "Build failed! Cleaning up..."
    lb clean --purge 2>/dev/null || true
    exit 1
}

trap cleanup_on_error ERR

# Main build process
main() {
    cd "$PROJECT_DIR"
    
    check_dependencies
    fix_line_endings
    setup_cross_build
    
    # Make auto scripts executable
    chmod +x auto/* 2>/dev/null || true
    
    # Copy branding assets to includes.chroot
    log_info "Copying branding assets..."
    if [ -f "background.png" ]; then
        mkdir -p config/includes.chroot/usr/share/backgrounds/fidelity
        cp background.png config/includes.chroot/usr/share/backgrounds/fidelity/default.png
        log_info "Background image copied"
    fi
    
    # Copy Rust tools source for building during chroot
    log_info "Copying Rust tools source..."
    if [ -d "tools" ]; then
        mkdir -p config/includes.chroot/opt/fidelity-tools
        cp -r tools/* config/includes.chroot/opt/fidelity-tools/
        log_info "Rust tools source copied"
    fi
    
    # Copy ASCII art for neofetch branding
    if [ -f "ascii-art.txt" ]; then
        mkdir -p config/includes.chroot/usr/share/fidelity
        cp ascii-art.txt config/includes.chroot/usr/share/fidelity/
        log_info "ASCII art copied"
    fi
    
    # Update version with build date
    BUILD_DATE=$(date +%Y-%m-%d)
    if [ -f "config/includes.chroot/etc/fidelity/version" ]; then
        sed -i "s/FIDELITY_BUILD_DATE=\"[^\"]*\"/FIDELITY_BUILD_DATE=\"$BUILD_DATE\"/" \
            config/includes.chroot/etc/fidelity/version
    fi
    
    # Make hook scripts executable
    find config/hooks -name "*.hook.chroot" -exec chmod +x {} \; 2>/dev/null || true
    
    # Validate packages (optional, can be slow)
    if [ "${VALIDATE_PACKAGES:-0}" = "1" ]; then
        validate_packages
    fi
    
    # Export architecture for auto/config
    export FIDELITY_ARCH="$TARGET_ARCH"
    
    # Clean previous build
    log_info "Cleaning previous build..."
    lb clean
    
    # Configure
    log_info "Configuring live-build for $TARGET_ARCH..."
    if ! lb config; then
        log_error "lb config failed!"
        exit 1
    fi
    
    # Build
    log_info "Building ISO (this will take a while)..."
    if ! lb build; then
        log_error "lb build failed! Check the logs above for details."
        exit 1
    fi
    
    # Find the ISO
    ISO_FILE=$(ls -1 *.iso 2>/dev/null | head -1)
    
    echo ""
    echo "=========================================="
    echo -e "  ${GREEN}Build complete!${NC}"
    if [ -n "$ISO_FILE" ]; then
        ISO_SIZE=$(du -h "$ISO_FILE" | cut -f1)
        echo "  ISO: $ISO_FILE ($ISO_SIZE)"
        echo "  SHA256: $(sha256sum "$ISO_FILE" | cut -d' ' -f1)"
    else
        log_warn "No ISO file found. Check for errors above."
    fi
    echo "=========================================="
}

main "$@"
