#!/bin/bash
# Build FidelityOS Rust tools
# Run this before building the ISO

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
TOOLS_DIR="$PROJECT_DIR/tools"
OUTPUT_DIR="$PROJECT_DIR/config/includes.chroot/usr/bin"

echo "=========================================="
echo "  Building FidelityOS Tools"
echo "=========================================="

# Check for Rust
if ! command -v cargo &> /dev/null; then
    echo "[!] Rust not found. Installing..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Build each tool
for tool in fidelity-welcome fidelity-settings fidelity-software; do
    echo "[*] Building $tool..."
    cd "$TOOLS_DIR/$tool"
    cargo build --release
    cp "target/release/$tool" "$OUTPUT_DIR/"
    echo "[✓] $tool built successfully"
done

echo "=========================================="
echo "  All tools built!"
echo "  Binaries in: $OUTPUT_DIR"
echo "=========================================="
