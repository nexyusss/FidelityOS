// System actions for FidelityOS Settings

use std::process::Command;

pub fn set_color_scheme(scheme: &str) {
    let _ = Command::new("gsettings")
        .args(["set", "org.gnome.desktop.interface", "color-scheme", scheme])
        .spawn();
}

pub fn set_accent_color(color: &str) {
    let _ = Command::new("gsettings")
        .args(["set", "org.gnome.desktop.interface", "accent-color", color])
        .spawn();
}

pub fn set_icon_theme(theme: &str) {
    let _ = Command::new("gsettings")
        .args(["set", "org.gnome.desktop.interface", "icon-theme", theme])
        .spawn();
}

pub fn set_font_scale(scale: f64) {
    let _ = Command::new("gsettings")
        .args(["set", "org.gnome.desktop.interface", "text-scaling-factor", &scale.to_string()])
        .spawn();
}

pub fn set_animations_enabled(enabled: bool) {
    let value = if enabled { "true" } else { "false" };
    let _ = Command::new("gsettings")
        .args(["set", "org.gnome.desktop.interface", "enable-animations", value])
        .spawn();
}

pub fn apply_privacy_level(level: usize) {
    match level {
        0 => apply_standard_privacy(),
        1 => apply_enhanced_privacy(),
        2 => apply_maximum_privacy(),
        _ => {}
    }
}

fn apply_standard_privacy() {
    set_firewall_enabled(true);
    save_privacy_level("standard");
}

fn apply_enhanced_privacy() {
    apply_standard_privacy();
    set_doh_enabled(true);
    set_mac_randomization(true);
    save_privacy_level("enhanced");
}

fn apply_maximum_privacy() {
    apply_enhanced_privacy();
    save_privacy_level("maximum");
}

fn save_privacy_level(level: &str) {
    let config_dir = glib::user_config_dir().join("fidelity");
    std::fs::create_dir_all(&config_dir).ok();
    std::fs::write(config_dir.join("privacy-level"), level).ok();
}

pub fn set_firewall_enabled(enabled: bool) {
    let action = if enabled { "enable" } else { "disable" };
    let _ = Command::new("pkexec")
        .args(["ufw", action])
        .spawn();
}

pub fn set_doh_enabled(enabled: bool) {
    if enabled {
        let config = r#"[Resolve]
DNS=1.1.1.1#cloudflare-dns.com 1.0.0.1#cloudflare-dns.com
DNSOverTLS=yes
"#;
        let _ = Command::new("pkexec")
            .args(["tee", "/etc/systemd/resolved.conf.d/fidelity-doh.conf"])
            .stdin(std::process::Stdio::piped())
            .spawn()
            .and_then(|mut child| {
                if let Some(stdin) = child.stdin.as_mut() {
                    use std::io::Write;
                    stdin.write_all(config.as_bytes()).ok();
                }
                child.wait()
            });
        
        let _ = Command::new("pkexec")
            .args(["systemctl", "restart", "systemd-resolved"])
            .spawn();
    } else {
        let _ = Command::new("pkexec")
            .args(["rm", "-f", "/etc/systemd/resolved.conf.d/fidelity-doh.conf"])
            .spawn();
    }
}

pub fn set_mac_randomization(enabled: bool) {
    if enabled {
        let config = r#"[device]
wifi.scan-rand-mac-address=yes

[connection]
wifi.cloned-mac-address=random
ethernet.cloned-mac-address=random
"#;
        let _ = Command::new("pkexec")
            .args(["tee", "/etc/NetworkManager/conf.d/fidelity-privacy.conf"])
            .stdin(std::process::Stdio::piped())
            .spawn()
            .and_then(|mut child| {
                if let Some(stdin) = child.stdin.as_mut() {
                    use std::io::Write;
                    stdin.write_all(config.as_bytes()).ok();
                }
                child.wait()
            });
    } else {
        let _ = Command::new("pkexec")
            .args(["rm", "-f", "/etc/NetworkManager/conf.d/fidelity-privacy.conf"])
            .spawn();
    }
}
