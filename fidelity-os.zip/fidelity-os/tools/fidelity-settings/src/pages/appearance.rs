// Appearance settings page
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use glib;
use gtk::prelude::*;
use adw::prelude::*;

use crate::actions;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("Appearance")
        .icon_name("preferences-desktop-appearance-symbolic")
        .build();

    // Style group
    let style_group = adw::PreferencesGroup::builder()
        .title("Style")
        .description("Choose your visual style")
        .build();

    // Color scheme
    let scheme_row = adw::ComboRow::builder()
        .title("Color Scheme")
        .subtitle("Light or dark appearance")
        .build();

    let schemes = gtk::StringList::new(&["Dark", "Light", "Follow System"]);
    scheme_row.set_model(Some(&schemes));
    scheme_row.set_selected(get_current_scheme());

    scheme_row.connect_selected_notify(|row| {
        let scheme = match row.selected() {
            0 => "prefer-dark",
            1 => "prefer-light",
            _ => "default",
        };
        actions::set_color_scheme(scheme);
    });

    // Accent color
    let accent_row = adw::ComboRow::builder()
        .title("Accent Color")
        .subtitle("Highlight color for buttons and links")
        .build();

    let accents = gtk::StringList::new(&["Blue", "Teal", "Green", "Yellow", "Orange", "Red", "Pink", "Purple"]);
    accent_row.set_model(Some(&accents));
    accent_row.set_selected(get_current_accent());

    accent_row.connect_selected_notify(|row| {
        let colors = ["blue", "teal", "green", "yellow", "orange", "red", "pink", "purple"];
        if let Some(color) = colors.get(row.selected() as usize) {
            actions::set_accent_color(color);
        }
    });

    style_group.add(&scheme_row);
    style_group.add(&accent_row);

    // Fonts group
    let fonts_group = adw::PreferencesGroup::builder()
        .title("Fonts")
        .build();

    let interface_font = adw::ActionRow::builder()
        .title("Interface Font")
        .subtitle("Inter")
        .activatable(true)
        .build();
    interface_font.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    let document_font = adw::ActionRow::builder()
        .title("Document Font")
        .subtitle("Noto Sans")
        .activatable(true)
        .build();
    document_font.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    let monospace_font = adw::ActionRow::builder()
        .title("Monospace Font")
        .subtitle("JetBrains Mono")
        .activatable(true)
        .build();
    monospace_font.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    // Font scaling - use ActionRow with SpinButton instead of SpinRow
    let font_scale_row = adw::ActionRow::builder()
        .title("Text Scaling")
        .subtitle("Adjust text size")
        .build();
    
    let font_scale_btn = gtk::SpinButton::with_range(0.5, 3.0, 0.1);
    font_scale_btn.set_value(get_font_scale());
    font_scale_btn.set_valign(gtk::Align::Center);
    font_scale_btn.connect_value_changed(|btn| {
        actions::set_font_scale(btn.value());
    });
    font_scale_row.add_suffix(&font_scale_btn);

    fonts_group.add(&interface_font);
    fonts_group.add(&document_font);
    fonts_group.add(&monospace_font);
    fonts_group.add(&font_scale_row);

    // Desktop group
    let desktop_group = adw::PreferencesGroup::builder()
        .title("Desktop")
        .build();

    let wallpaper_row = adw::ActionRow::builder()
        .title("Wallpaper")
        .subtitle("Change desktop background")
        .activatable(true)
        .build();
    wallpaper_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    wallpaper_row.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("background")
            .spawn();
    });

    let icons_row = adw::ComboRow::builder()
        .title("Icon Theme")
        .subtitle("Application and folder icons")
        .build();

    let icons = gtk::StringList::new(&["Papirus", "Papirus-Dark", "Adwaita", "Yaru"]);
    icons_row.set_model(Some(&icons));

    icons_row.connect_selected_notify(|row| {
        let themes = ["Papirus", "Papirus-Dark", "Adwaita", "Yaru"];
        if let Some(theme) = themes.get(row.selected() as usize) {
            actions::set_icon_theme(theme);
        }
    });

    let cursor_row = adw::ComboRow::builder()
        .title("Cursor Theme")
        .build();

    let cursors = gtk::StringList::new(&["Adwaita", "DMZ-White", "DMZ-Black"]);
    cursor_row.set_model(Some(&cursors));

    desktop_group.add(&wallpaper_row);
    desktop_group.add(&icons_row);
    desktop_group.add(&cursor_row);

    // Animations group
    let animations_group = adw::PreferencesGroup::builder()
        .title("Animations")
        .build();

    let enable_animations = create_switch_row(
        "Enable Animations",
        "Window and interface animations",
        true
    );

    let anim_switch = get_row_switch(&enable_animations);
    anim_switch.connect_state_set(|_, state| {
        actions::set_animations_enabled(state);
        glib::Propagation::Proceed
    });

    animations_group.add(&enable_animations);

    page.add(&style_group);
    page.add(&fonts_group);
    page.add(&desktop_group);
    page.add(&animations_group);

    page
}

// Helper to create ActionRow with Switch (libadwaita 1.2 compatible)
fn create_switch_row(title: &str, subtitle: &str, active: bool) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .subtitle(subtitle)
        .build();
    
    let switch = gtk::Switch::builder()
        .active(active)
        .valign(gtk::Align::Center)
        .build();
    
    row.add_suffix(&switch);
    row.set_activatable_widget(Some(&switch));
    row
}

fn get_row_switch(row: &adw::ActionRow) -> gtk::Switch {
    row.activatable_widget()
        .and_then(|w| w.downcast::<gtk::Switch>().ok())
        .expect("Row should have a Switch widget")
}

fn get_current_scheme() -> u32 {
    0 // Default to dark
}

fn get_current_accent() -> u32 {
    0 // Default to blue
}

fn get_font_scale() -> f64 {
    1.0
}
