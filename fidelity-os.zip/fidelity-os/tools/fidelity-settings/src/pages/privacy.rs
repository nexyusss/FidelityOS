// Privacy & Security settings page
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

use crate::actions;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("Privacy & Security")
        .icon_name("security-high-symbolic")
        .build();

    // Privacy Level group
    let level_group = adw::PreferencesGroup::builder()
        .title("Privacy Level")
        .description("Quick privacy presets")
        .build();

    let level_row = adw::ComboRow::builder()
        .title("Privacy Level")
        .subtitle("Choose your protection level")
        .build();

    let levels = gtk::StringList::new(&["Standard", "Enhanced", "Maximum"]);
    level_row.set_model(Some(&levels));
    level_row.set_selected(get_privacy_level());

    level_row.connect_selected_notify(|row| {
        actions::apply_privacy_level(row.selected() as usize);
    });

    level_group.add(&level_row);

    // Firewall group
    let firewall_group = adw::PreferencesGroup::builder()
        .title("Firewall")
        .description("Control network access")
        .build();

    let firewall_enabled = create_switch_row(
        "Firewall",
        "Block unauthorized network connections",
        is_firewall_enabled()
    );
    
    let firewall_switch = get_row_switch(&firewall_enabled);
    firewall_switch.connect_state_set(|_, state| {
        actions::set_firewall_enabled(state);
        glib::Propagation::Proceed
    });

    let firewall_settings = adw::ActionRow::builder()
        .title("Firewall Rules")
        .subtitle("Configure allowed connections")
        .activatable(true)
        .build();
    firewall_settings.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    firewall_settings.connect_activated(|_| {
        let _ = std::process::Command::new("gufw").spawn();
    });

    firewall_group.add(&firewall_enabled);
    firewall_group.add(&firewall_settings);

    // Network Privacy group
    let network_group = adw::PreferencesGroup::builder()
        .title("Network Privacy")
        .build();

    let dns_over_https = create_switch_row(
        "DNS-over-HTTPS",
        "Encrypt DNS queries for privacy",
        is_doh_enabled()
    );

    let doh_switch = get_row_switch(&dns_over_https);
    doh_switch.connect_state_set(|_, state| {
        actions::set_doh_enabled(state);
        glib::Propagation::Proceed
    });

    let dns_provider = adw::ComboRow::builder()
        .title("DNS Provider")
        .subtitle("Choose your encrypted DNS server")
        .sensitive(is_doh_enabled())
        .build();

    let providers = gtk::StringList::new(&["Cloudflare (1.1.1.1)", "Google (8.8.8.8)", "Quad9 (9.9.9.9)"]);
    dns_provider.set_model(Some(&providers));

    let mac_randomization = create_switch_row(
        "MAC Address Randomization",
        "Use random hardware address on WiFi",
        is_mac_random_enabled()
    );

    let mac_switch = get_row_switch(&mac_randomization);
    mac_switch.connect_state_set(|_, state| {
        actions::set_mac_randomization(state);
        glib::Propagation::Proceed
    });

    network_group.add(&dns_over_https);
    network_group.add(&dns_provider);
    network_group.add(&mac_randomization);

    // App Security group
    let security_group = adw::PreferencesGroup::builder()
        .title("Application Security")
        .build();

    let apparmor_status = adw::ActionRow::builder()
        .title("AppArmor")
        .subtitle(get_apparmor_status())
        .build();

    let apparmor_icon = gtk::Image::from_icon_name("emblem-ok-symbolic");
    apparmor_icon.add_css_class("success");
    apparmor_status.add_suffix(&apparmor_icon);

    security_group.add(&apparmor_status);

    // Screen Lock group
    let lock_group = adw::PreferencesGroup::builder()
        .title("Screen Lock")
        .build();

    let auto_lock = create_switch_row(
        "Automatic Screen Lock",
        "Lock screen when inactive",
        true
    );

    let lock_delay = adw::ComboRow::builder()
        .title("Lock After")
        .build();

    let delays = gtk::StringList::new(&["1 minute", "2 minutes", "5 minutes", "10 minutes", "30 minutes"]);
    lock_delay.set_model(Some(&delays));
    lock_delay.set_selected(2);

    lock_group.add(&auto_lock);
    lock_group.add(&lock_delay);

    // Location group
    let location_group = adw::PreferencesGroup::builder()
        .title("Location")
        .build();

    let location_services = create_switch_row(
        "Location Services",
        "Allow apps to determine your location",
        false
    );

    location_group.add(&location_services);

    page.add(&level_group);
    page.add(&firewall_group);
    page.add(&network_group);
    page.add(&security_group);
    page.add(&lock_group);
    page.add(&location_group);

    page
}

// Helper to create ActionRow with Switch (libadwaita 1.2 compatible)
fn create_switch_row(title: &str, subtitle: &str, active: bool) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .subtitle(subtitle)
        .build();
    
    let switch = gtk::Switch::builder()
        .active(active)
        .valign(gtk::Align::Center)
        .build();
    
    row.add_suffix(&switch);
    row.set_activatable_widget(Some(&switch));
    row
}

fn get_row_switch(row: &adw::ActionRow) -> gtk::Switch {
    // Get the switch from the row's suffix
    row.activatable_widget()
        .and_then(|w| w.downcast::<gtk::Switch>().ok())
        .expect("Row should have a Switch widget")
}

fn get_privacy_level() -> u32 {
    1 // Enhanced default
}

fn is_firewall_enabled() -> bool {
    true // Default enabled
}

fn is_doh_enabled() -> bool {
    std::path::Path::new("/etc/systemd/resolved.conf.d/fidelity-doh.conf").exists()
}

fn is_mac_random_enabled() -> bool {
    std::path::Path::new("/etc/NetworkManager/conf.d/fidelity-privacy.conf").exists()
}

fn get_apparmor_status() -> &'static str {
    "Active and enforcing"
}
