// Network settings page
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("Network")
        .icon_name("network-wireless-symbolic")
        .build();

    // WiFi group
    let wifi_group = adw::PreferencesGroup::builder()
        .title("Wi-Fi")
        .build();

    let wifi_enabled = create_switch_row("Wi-Fi", "Wireless network connection", true);

    let wifi_networks = adw::ActionRow::builder()
        .title("Available Networks")
        .subtitle("Connect to a wireless network")
        .activatable(true)
        .build();
    wifi_networks.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    wifi_networks.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("wifi")
            .spawn();
    });

    let hotspot = adw::ActionRow::builder()
        .title("Mobile Hotspot")
        .subtitle("Share your connection with other devices")
        .activatable(true)
        .build();
    hotspot.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    wifi_group.add(&wifi_enabled);
    wifi_group.add(&wifi_networks);
    wifi_group.add(&hotspot);

    // VPN group
    let vpn_group = adw::PreferencesGroup::builder()
        .title("VPN")
        .description("Secure your connection with a virtual private network")
        .build();

    let add_vpn = adw::ActionRow::builder()
        .title("Add VPN Connection")
        .subtitle("Configure OpenVPN, WireGuard, or other VPN")
        .activatable(true)
        .build();
    add_vpn.add_prefix(&gtk::Image::from_icon_name("list-add-symbolic"));

    add_vpn.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("network")
            .spawn();
    });

    let wireguard_row = adw::ActionRow::builder()
        .title("WireGuard")
        .subtitle("Fast, modern VPN protocol")
        .activatable(true)
        .build();

    let wg_status = gtk::Label::builder()
        .label("Not configured")
        .build();
    wg_status.add_css_class("dim-label");
    wireguard_row.add_suffix(&wg_status);
    wireguard_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    vpn_group.add(&add_vpn);
    vpn_group.add(&wireguard_row);

    // Proxy group
    let proxy_group = adw::PreferencesGroup::builder()
        .title("Proxy")
        .description("Route traffic through a proxy server")
        .build();

    let proxy_mode = adw::ComboRow::builder()
        .title("Proxy Mode")
        .subtitle("Choose how to configure proxy settings")
        .build();

    let modes = gtk::StringList::new(&["None", "Manual", "Automatic"]);
    proxy_mode.set_model(Some(&modes));

    // Use ActionRow with Entry instead of EntryRow
    let http_proxy = create_entry_row("HTTP Proxy", false);
    let https_proxy = create_entry_row("HTTPS Proxy", false);

    let http_clone = http_proxy.clone();
    let https_clone = https_proxy.clone();
    proxy_mode.connect_selected_notify(move |row| {
        let enabled = row.selected() == 1;
        http_clone.set_sensitive(enabled);
        https_clone.set_sensitive(enabled);
    });

    proxy_group.add(&proxy_mode);
    proxy_group.add(&http_proxy);
    proxy_group.add(&https_proxy);

    // Bluetooth group
    let bluetooth_group = adw::PreferencesGroup::builder()
        .title("Bluetooth")
        .build();

    let bluetooth_enabled = create_switch_row("Bluetooth", "Connect wireless devices", true);

    let bluetooth_devices = adw::ActionRow::builder()
        .title("Paired Devices")
        .subtitle("Manage connected Bluetooth devices")
        .activatable(true)
        .build();
    bluetooth_devices.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    bluetooth_devices.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("bluetooth")
            .spawn();
    });

    bluetooth_group.add(&bluetooth_enabled);
    bluetooth_group.add(&bluetooth_devices);

    page.add(&wifi_group);
    page.add(&vpn_group);
    page.add(&proxy_group);
    page.add(&bluetooth_group);

    page
}

// Helper to create ActionRow with Switch (libadwaita 1.2 compatible)
fn create_switch_row(title: &str, subtitle: &str, active: bool) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .subtitle(subtitle)
        .build();
    
    let switch = gtk::Switch::builder()
        .active(active)
        .valign(gtk::Align::Center)
        .build();
    
    row.add_suffix(&switch);
    row.set_activatable_widget(Some(&switch));
    row
}

// Helper to create ActionRow with Entry (libadwaita 1.2 compatible)
fn create_entry_row(title: &str, sensitive: bool) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .sensitive(sensitive)
        .build();
    
    let entry = gtk::Entry::builder()
        .valign(gtk::Align::Center)
        .hexpand(true)
        .build();
    
    row.add_suffix(&entry);
    row
}
