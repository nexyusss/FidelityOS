// Network settings page

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;
use glib::clone;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("Network")
        .icon_name("network-wireless-symbolic")
        .build();

    // WiFi group
    let wifi_group = adw::PreferencesGroup::builder()
        .title("Wi-Fi")
        .build();

    let wifi_enabled = adw::SwitchRow::builder()
        .title("Wi-Fi")
        .subtitle("Wireless network connection")
        .active(true)
        .build();

    let wifi_networks = adw::ActionRow::builder()
        .title("Available Networks")
        .subtitle("Connect to a wireless network")
        .activatable(true)
        .build();
    wifi_networks.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    wifi_networks.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("wifi")
            .spawn();
    });

    let hotspot = adw::ActionRow::builder()
        .title("Mobile Hotspot")
        .subtitle("Share your connection with other devices")
        .activatable(true)
        .build();
    hotspot.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    wifi_group.add(&wifi_enabled);
    wifi_group.add(&wifi_networks);
    wifi_group.add(&hotspot);

    // VPN group
    let vpn_group = adw::PreferencesGroup::builder()
        .title("VPN")
        .description("Secure your connection with a virtual private network")
        .build();

    let add_vpn = adw::ActionRow::builder()
        .title("Add VPN Connection")
        .subtitle("Configure OpenVPN, WireGuard, or other VPN")
        .activatable(true)
        .build();
    add_vpn.add_prefix(&gtk::Image::from_icon_name("list-add-symbolic"));

    add_vpn.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("network")
            .spawn();
    });

    let wireguard_row = adw::ActionRow::builder()
        .title("WireGuard")
        .subtitle("Fast, modern VPN protocol")
        .activatable(true)
        .build();

    let wg_status = gtk::Label::builder()
        .label("Not configured")
        .css_classes(["dim-label"])
        .build();
    wireguard_row.add_suffix(&wg_status);
    wireguard_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    vpn_group.add(&add_vpn);
    vpn_group.add(&wireguard_row);

    // Proxy group
    let proxy_group = adw::PreferencesGroup::builder()
        .title("Proxy")
        .description("Route traffic through a proxy server")
        .build();

    let proxy_mode = adw::ComboRow::builder()
        .title("Proxy Mode")
        .subtitle("Choose how to configure proxy settings")
        .build();

    let modes = gtk::StringList::new(&["None", "Manual", "Automatic"]);
    proxy_mode.set_model(Some(&modes));

    let http_proxy = adw::EntryRow::builder()
        .title("HTTP Proxy")
        .sensitive(false)
        .build();

    let https_proxy = adw::EntryRow::builder()
        .title("HTTPS Proxy")
        .sensitive(false)
        .build();

    proxy_mode.connect_selected_notify(clone!(
        #[weak] http_proxy,
        #[weak] https_proxy,
        move |row| {
            let enabled = row.selected() == 1;
            http_proxy.set_sensitive(enabled);
            https_proxy.set_sensitive(enabled);
        }
    ));

    proxy_group.add(&proxy_mode);
    proxy_group.add(&http_proxy);
    proxy_group.add(&https_proxy);

    // Bluetooth group
    let bluetooth_group = adw::PreferencesGroup::builder()
        .title("Bluetooth")
        .build();

    let bluetooth_enabled = adw::SwitchRow::builder()
        .title("Bluetooth")
        .subtitle("Connect wireless devices")
        .active(true)
        .build();

    let bluetooth_devices = adw::ActionRow::builder()
        .title("Paired Devices")
        .subtitle("Manage connected Bluetooth devices")
        .activatable(true)
        .build();
    bluetooth_devices.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    bluetooth_devices.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("bluetooth")
            .spawn();
    });

    bluetooth_group.add(&bluetooth_enabled);
    bluetooth_group.add(&bluetooth_devices);

    page.add(&wifi_group);
    page.add(&vpn_group);
    page.add(&proxy_group);
    page.add(&bluetooth_group);

    page
}
