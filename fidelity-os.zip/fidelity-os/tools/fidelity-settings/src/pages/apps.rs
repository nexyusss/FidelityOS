// Applications settings page
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use glib;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("Applications")
        .icon_name("application-x-executable-symbolic")
        .build();

    // Default Apps group
    let defaults_group = adw::PreferencesGroup::builder()
        .title("Default Applications")
        .description("Choose which apps open different types of content")
        .build();

    let web_browser = adw::ComboRow::builder()
        .title("Web Browser")
        .subtitle("Opens web links")
        .build();
    let browsers = gtk::StringList::new(&["Firefox", "Chromium", "GNOME Web"]);
    web_browser.set_model(Some(&browsers));

    let email_client = adw::ComboRow::builder()
        .title("Email")
        .subtitle("Opens email links")
        .build();
    let email_apps = gtk::StringList::new(&["Thunderbird", "Geary", "Evolution"]);
    email_client.set_model(Some(&email_apps));

    let file_manager = adw::ComboRow::builder()
        .title("File Manager")
        .subtitle("Opens folders")
        .build();
    let file_apps = gtk::StringList::new(&["Files (Nautilus)", "Nemo", "Thunar"]);
    file_manager.set_model(Some(&file_apps));

    let music_player = adw::ComboRow::builder()
        .title("Music")
        .subtitle("Opens audio files")
        .build();
    let music_apps = gtk::StringList::new(&["Rhythmbox", "Lollypop", "Amberol"]);
    music_player.set_model(Some(&music_apps));

    let video_player = adw::ComboRow::builder()
        .title("Video")
        .subtitle("Opens video files")
        .build();
    let video_apps = gtk::StringList::new(&["Celluloid", "Totem", "VLC"]);
    video_player.set_model(Some(&video_apps));

    let image_viewer = adw::ComboRow::builder()
        .title("Images")
        .subtitle("Opens image files")
        .build();
    let image_apps = gtk::StringList::new(&["Eye of GNOME", "Loupe", "gThumb"]);
    image_viewer.set_model(Some(&image_apps));

    defaults_group.add(&web_browser);
    defaults_group.add(&email_client);
    defaults_group.add(&file_manager);
    defaults_group.add(&music_player);
    defaults_group.add(&video_player);
    defaults_group.add(&image_viewer);

    // Startup Apps group
    let startup_group = adw::PreferencesGroup::builder()
        .title("Startup Applications")
        .description("Apps that start automatically when you log in")
        .build();

    let startup_apps = get_startup_apps();
    
    for (name, enabled) in startup_apps {
        let row = create_switch_row(&name, "", enabled);
        startup_group.add(&row);
    }

    let add_startup = adw::ActionRow::builder()
        .title("Add Startup Application")
        .activatable(true)
        .build();
    add_startup.add_prefix(&gtk::Image::from_icon_name("list-add-symbolic"));

    add_startup.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-tweaks").spawn();
    });

    startup_group.add(&add_startup);

    // Flatpak group
    let flatpak_group = adw::PreferencesGroup::builder()
        .title("Flatpak")
        .description("Sandboxed application management")
        .build();

    let flathub_enabled = create_switch_row(
        "Flathub Repository",
        "Access thousands of apps",
        is_flathub_enabled()
    );

    let flathub_switch = get_row_switch(&flathub_enabled);
    flathub_switch.connect_state_set(|_, state| {
        if state {
            let _ = std::process::Command::new("flatpak")
                .args(["remote-add", "--if-not-exists", "flathub", 
                       "https://flathub.org/repo/flathub.flatpakrepo"])
                .spawn();
        }
        glib::Propagation::Proceed
    });

    let manage_permissions = adw::ActionRow::builder()
        .title("Manage Permissions")
        .subtitle("Control what Flatpak apps can access")
        .activatable(true)
        .build();
    manage_permissions.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    manage_permissions.connect_activated(|_| {
        let _ = std::process::Command::new("flatpak")
            .args(["run", "com.github.tchx84.Flatseal"])
            .spawn();
    });

    let update_flatpaks = adw::ActionRow::builder()
        .title("Update All Flatpaks")
        .activatable(true)
        .build();
    update_flatpaks.add_prefix(&gtk::Image::from_icon_name("emblem-synchronizing-symbolic"));

    update_flatpaks.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-terminal")
            .args(["--", "flatpak", "update", "-y"])
            .spawn();
    });

    flatpak_group.add(&flathub_enabled);
    flatpak_group.add(&manage_permissions);
    flatpak_group.add(&update_flatpaks);

    // Removable Media group
    let media_group = adw::PreferencesGroup::builder()
        .title("Removable Media")
        .build();

    let autorun = create_switch_row(
        "Autorun",
        "Automatically run software from removable media",
        false
    );

    let automount = create_switch_row(
        "Automount",
        "Automatically mount removable drives",
        true
    );

    media_group.add(&autorun);
    media_group.add(&automount);

    page.add(&defaults_group);
    page.add(&startup_group);
    page.add(&flatpak_group);
    page.add(&media_group);

    page
}

// Helper to create ActionRow with Switch (libadwaita 1.2 compatible)
fn create_switch_row(title: &str, subtitle: &str, active: bool) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .build();
    
    if !subtitle.is_empty() {
        row.set_subtitle(subtitle);
    }
    
    let switch = gtk::Switch::builder()
        .active(active)
        .valign(gtk::Align::Center)
        .build();
    
    row.add_suffix(&switch);
    row.set_activatable_widget(Some(&switch));
    row
}

fn get_row_switch(row: &adw::ActionRow) -> gtk::Switch {
    row.activatable_widget()
        .and_then(|w| w.downcast::<gtk::Switch>().ok())
        .expect("Row should have a Switch widget")
}

fn get_startup_apps() -> Vec<(String, bool)> {
    vec![("FidelityOS Welcome".to_string(), true)]
}

fn is_flathub_enabled() -> bool {
    true // Assume enabled by default
}
