// Applications settings page

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("Applications")
        .icon_name("application-x-executable-symbolic")
        .build();

    // Default Apps group
    let defaults_group = adw::PreferencesGroup::builder()
        .title("Default Applications")
        .description("Choose which apps open different types of content")
        .build();

    let web_browser = adw::ComboRow::builder()
        .title("Web Browser")
        .subtitle("Opens web links")
        .build();
    let browsers = gtk::StringList::new(&["Firefox", "Chromium", "GNOME Web"]);
    web_browser.set_model(Some(&browsers));

    let email_client = adw::ComboRow::builder()
        .title("Email")
        .subtitle("Opens email links")
        .build();
    let email_apps = gtk::StringList::new(&["Thunderbird", "Geary", "Evolution"]);
    email_client.set_model(Some(&email_apps));

    let file_manager = adw::ComboRow::builder()
        .title("File Manager")
        .subtitle("Opens folders")
        .build();
    let file_apps = gtk::StringList::new(&["Files (Nautilus)", "Nemo", "Thunar"]);
    file_manager.set_model(Some(&file_apps));

    let music_player = adw::ComboRow::builder()
        .title("Music")
        .subtitle("Opens audio files")
        .build();
    let music_apps = gtk::StringList::new(&["Rhythmbox", "Lollypop", "Amberol"]);
    music_player.set_model(Some(&music_apps));

    let video_player = adw::ComboRow::builder()
        .title("Video")
        .subtitle("Opens video files")
        .build();
    let video_apps = gtk::StringList::new(&["Celluloid", "Totem", "VLC"]);
    video_player.set_model(Some(&video_apps));

    let image_viewer = adw::ComboRow::builder()
        .title("Images")
        .subtitle("Opens image files")
        .build();
    let image_apps = gtk::StringList::new(&["Eye of GNOME", "Loupe", "gThumb"]);
    image_viewer.set_model(Some(&image_apps));

    defaults_group.add(&web_browser);
    defaults_group.add(&email_client);
    defaults_group.add(&file_manager);
    defaults_group.add(&music_player);
    defaults_group.add(&video_player);
    defaults_group.add(&image_viewer);

    // Startup Apps group
    let startup_group = adw::PreferencesGroup::builder()
        .title("Startup Applications")
        .description("Apps that start automatically when you log in")
        .build();

    let startup_apps = get_startup_apps();
    
    for (name, enabled) in startup_apps {
        let row = adw::SwitchRow::builder()
            .title(&name)
            .active(enabled)
            .build();
        startup_group.add(&row);
    }

    let add_startup = adw::ActionRow::builder()
        .title("Add Startup Application")
        .activatable(true)
        .build();
    add_startup.add_prefix(&gtk::Image::from_icon_name("list-add-symbolic"));

    add_startup.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-tweaks").spawn();
    });

    startup_group.add(&add_startup);

    // Flatpak group
    let flatpak_group = adw::PreferencesGroup::builder()
        .title("Flatpak")
        .description("Sandboxed application management")
        .build();

    let flathub_enabled = adw::SwitchRow::builder()
        .title("Flathub Repository")
        .subtitle("Access thousands of apps")
        .active(is_flathub_enabled())
        .build();

    flathub_enabled.connect_active_notify(|row| {
        if row.is_active() {
            let _ = std::process::Command::new("flatpak")
                .args(["remote-add", "--if-not-exists", "flathub", 
                       "https://flathub.org/repo/flathub.flatpakrepo"])
                .spawn();
        }
    });

    let manage_permissions = adw::ActionRow::builder()
        .title("Manage Permissions")
        .subtitle("Control what Flatpak apps can access")
        .activatable(true)
        .build();
    manage_permissions.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    manage_permissions.connect_activated(|_| {
        // Try Flatseal first, fall back to command line
        let _ = std::process::Command::new("flatpak")
            .args(["run", "com.github.tchx84.Flatseal"])
            .spawn();
    });

    let update_flatpaks = adw::ActionRow::builder()
        .title("Update All Flatpaks")
        .activatable(true)
        .build();
    update_flatpaks.add_prefix(&gtk::Image::from_icon_name("emblem-synchronizing-symbolic"));

    update_flatpaks.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-terminal")
            .args(["--", "flatpak", "update", "-y"])
            .spawn();
    });

    flatpak_group.add(&flathub_enabled);
    flatpak_group.add(&manage_permissions);
    flatpak_group.add(&update_flatpaks);

    // Removable Media group
    let media_group = adw::PreferencesGroup::builder()
        .title("Removable Media")
        .build();

    let autorun = adw::SwitchRow::builder()
        .title("Autorun")
        .subtitle("Automatically run software from removable media")
        .active(false)
        .build();

    let automount = adw::SwitchRow::builder()
        .title("Automount")
        .subtitle("Automatically mount removable drives")
        .active(true)
        .build();

    media_group.add(&autorun);
    media_group.add(&automount);

    page.add(&defaults_group);
    page.add(&startup_group);
    page.add(&flatpak_group);
    page.add(&media_group);

    page
}

fn get_startup_apps() -> Vec<(String, bool)> {
    // Read from ~/.config/autostart
    let autostart_dir = glib::user_config_dir().join("autostart");
    let mut apps = Vec::new();

    if let Ok(entries) = std::fs::read_dir(autostart_dir) {
        for entry in entries.flatten() {
            if let Some(name) = entry.file_name().to_str() {
                if name.ends_with(".desktop") {
                    let app_name = name.trim_end_matches(".desktop").to_string();
                    apps.push((app_name, true));
                }
            }
        }
    }

    if apps.is_empty() {
        // Default entries
        apps.push(("FidelityOS Welcome".to_string(), true));
    }

    apps
}

fn is_flathub_enabled() -> bool {
    let output = std::process::Command::new("flatpak")
        .args(["remotes", "--columns=name"])
        .output()
        .ok();

    if let Some(out) = output {
        String::from_utf8_lossy(&out.stdout).contains("flathub")
    } else {
        false
    }
}
