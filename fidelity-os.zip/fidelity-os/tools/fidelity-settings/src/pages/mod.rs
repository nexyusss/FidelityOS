// Settings pages

pub mod appearance;
pub mod privacy;
pub mod network;
pub mod apps;
pub mod system;
pub mod about;
