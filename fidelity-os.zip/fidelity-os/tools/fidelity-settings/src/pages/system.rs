// System settings page - Enhanced with more features
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("System")
        .icon_name("computer-symbolic")
        .build();

    // Updates group
    let updates_group = adw::PreferencesGroup::builder()
        .title("Software Updates")
        .description("Keep your system secure and up to date")
        .build();

    let auto_updates = create_switch_row(
        "Automatic Updates",
        "Install security updates automatically",
        true
    );

    let check_updates = adw::ActionRow::builder()
        .title("Check for Updates")
        .subtitle("Last checked: Today")
        .activatable(true)
        .build();
    check_updates.add_prefix(&gtk::Image::from_icon_name("software-update-available-symbolic"));
    check_updates.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    check_updates.connect_activated(|_| {
        let _ = std::process::Command::new("fidelity-software").spawn();
    });

    updates_group.add(&auto_updates);
    updates_group.add(&check_updates);

    // Storage group
    let storage_group = adw::PreferencesGroup::builder()
        .title("Storage")
        .build();

    let (used, total, percent) = get_storage_info();
    
    let storage_row = adw::ActionRow::builder()
        .title("Disk Usage")
        .subtitle(&format!("{} of {} used ({}%)", used, total, percent))
        .activatable(true)
        .build();
    storage_row.add_prefix(&gtk::Image::from_icon_name("drive-harddisk-symbolic"));
    storage_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    storage_row.connect_activated(|_| {
        let _ = std::process::Command::new("baobab").spawn();
    });

    let clean_storage = adw::ActionRow::builder()
        .title("Clean Up Storage")
        .subtitle("Remove temporary files and caches")
        .activatable(true)
        .build();
    clean_storage.add_prefix(&gtk::Image::from_icon_name("user-trash-symbolic"));

    clean_storage.connect_activated(|_| {
        // Run cleanup
        let _ = std::process::Command::new("sh")
            .args(["-c", "rm -rf ~/.cache/thumbnails/* /tmp/* 2>/dev/null"])
            .spawn();
    });

    storage_group.add(&storage_row);
    storage_group.add(&clean_storage);

    // Power group
    let power_group = adw::PreferencesGroup::builder()
        .title("Power")
        .build();

    let power_mode = adw::ComboRow::builder()
        .title("Power Mode")
        .subtitle("Balance performance and battery life")
        .build();
    power_mode.add_prefix(&gtk::Image::from_icon_name("battery-symbolic"));

    let modes = gtk::StringList::new(&["Balanced", "Power Saver", "Performance"]);
    power_mode.set_model(Some(&modes));

    let suspend_row = adw::ComboRow::builder()
        .title("Automatic Suspend")
        .subtitle("When inactive on battery")
        .build();
    suspend_row.add_prefix(&gtk::Image::from_icon_name("preferences-system-time-symbolic"));

    let suspend_times = gtk::StringList::new(&["15 minutes", "30 minutes", "1 hour", "Never"]);
    suspend_row.set_model(Some(&suspend_times));
    suspend_row.set_selected(1);

    let show_battery = create_switch_row(
        "Show Battery Percentage",
        "Display in top bar",
        true
    );

    power_group.add(&power_mode);
    power_group.add(&suspend_row);
    power_group.add(&show_battery);

    // Keyboard Shortcuts group
    let shortcuts_group = adw::PreferencesGroup::builder()
        .title("Keyboard Shortcuts")
        .description("Quick access to common actions")
        .build();

    let shortcuts = [
        ("Super", "Activities overview"),
        ("Super + A", "Show all applications"),
        ("Super + T", "Open terminal"),
        ("Super + E", "Open file manager"),
        ("Super + S", "Open settings"),
        ("Super + Q", "Close window"),
        ("Super + Tab", "Switch applications"),
        ("Alt + Tab", "Switch windows"),
    ];

    for (key, action) in shortcuts {
        let row = adw::ActionRow::builder()
            .title(action)
            .build();
        
        let key_label = gtk::Label::builder()
            .label(key)
            .css_classes(["dim-label", "caption"])
            .build();
        
        row.add_suffix(&key_label);
        shortcuts_group.add(&row);
    }

    let more_shortcuts = adw::ActionRow::builder()
        .title("View All Shortcuts")
        .activatable(true)
        .build();
    more_shortcuts.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    more_shortcuts.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("keyboard")
            .spawn();
    });

    shortcuts_group.add(&more_shortcuts);

    // Users group
    let users_group = adw::PreferencesGroup::builder()
        .title("Users")
        .build();

    let current_user = adw::ActionRow::builder()
        .title(&get_current_user())
        .subtitle("Administrator")
        .activatable(true)
        .build();

    let user_icon = gtk::Image::builder()
        .icon_name("avatar-default-symbolic")
        .pixel_size(32)
        .build();
    current_user.add_prefix(&user_icon);
    current_user.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    current_user.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("user-accounts")
            .spawn();
    });

    users_group.add(&current_user);

    // Date & Time group
    let datetime_group = adw::PreferencesGroup::builder()
        .title("Date & Time")
        .build();

    let auto_datetime = create_switch_row(
        "Automatic Date & Time",
        "Set from the internet",
        true
    );

    let timezone_row = adw::ActionRow::builder()
        .title("Time Zone")
        .subtitle(&get_timezone())
        .activatable(true)
        .build();
    timezone_row.add_prefix(&gtk::Image::from_icon_name("preferences-system-time-symbolic"));
    timezone_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    timezone_row.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("datetime")
            .spawn();
    });

    datetime_group.add(&auto_datetime);
    datetime_group.add(&timezone_row);

    // Region & Language group
    let region_group = adw::PreferencesGroup::builder()
        .title("Region & Language")
        .build();

    let language_row = adw::ActionRow::builder()
        .title("Language")
        .subtitle(&get_language())
        .activatable(true)
        .build();
    language_row.add_prefix(&gtk::Image::from_icon_name("preferences-desktop-locale-symbolic"));
    language_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    language_row.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("region")
            .spawn();
    });

    region_group.add(&language_row);

    page.add(&updates_group);
    page.add(&storage_group);
    page.add(&power_group);
    page.add(&shortcuts_group);
    page.add(&users_group);
    page.add(&datetime_group);
    page.add(&region_group);

    page
}

fn create_switch_row(title: &str, subtitle: &str, active: bool) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .build();
    
    if !subtitle.is_empty() {
        row.set_subtitle(subtitle);
    }
    
    let switch = gtk::Switch::builder()
        .active(active)
        .valign(gtk::Align::Center)
        .build();
    
    row.add_suffix(&switch);
    row.set_activatable_widget(Some(&switch));
    row
}

fn get_storage_info() -> (String, String, u32) {
    std::process::Command::new("df")
        .args(["-h", "/"])
        .output()
        .ok()
        .and_then(|o| {
            let output = String::from_utf8_lossy(&o.stdout);
            output.lines().nth(1).map(|line| {
                let parts: Vec<&str> = line.split_whitespace().collect();
                if parts.len() >= 5 {
                    let total = parts[1].to_string();
                    let used = parts[2].to_string();
                    let percent = parts[4].trim_end_matches('%').parse().unwrap_or(0);
                    (used, total, percent)
                } else {
                    ("Unknown".to_string(), "Unknown".to_string(), 0)
                }
            })
        })
        .unwrap_or(("Unknown".to_string(), "Unknown".to_string(), 0))
}

fn get_current_user() -> String {
    std::env::var("USER").unwrap_or_else(|_| "User".to_string())
}

fn get_timezone() -> String {
    std::fs::read_link("/etc/localtime")
        .ok()
        .and_then(|p| {
            p.to_str()
                .and_then(|s| s.split("/zoneinfo/").last())
                .map(|s| s.to_string())
        })
        .unwrap_or_else(|| "UTC".to_string())
}

fn get_language() -> String {
    std::env::var("LANG")
        .ok()
        .map(|l| {
            match l.split('.').next().unwrap_or("en_US") {
                "en_US" => "English (US)".to_string(),
                "en_GB" => "English (UK)".to_string(),
                "de_DE" => "German".to_string(),
                "fr_FR" => "French".to_string(),
                "es_ES" => "Spanish".to_string(),
                other => other.to_string(),
            }
        })
        .unwrap_or_else(|| "English (US)".to_string())
}
