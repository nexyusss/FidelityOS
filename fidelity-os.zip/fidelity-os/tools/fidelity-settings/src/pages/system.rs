// System settings page
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("System")
        .icon_name("computer-symbolic")
        .build();

    // Updates group
    let updates_group = adw::PreferencesGroup::builder()
        .title("Software Updates")
        .build();

    let auto_updates = create_switch_row(
        "Automatic Updates",
        "Install security updates automatically",
        true
    );

    let check_updates = adw::ActionRow::builder()
        .title("Check for Updates")
        .activatable(true)
        .build();
    check_updates.add_prefix(&gtk::Image::from_icon_name("emblem-synchronizing-symbolic"));

    check_updates.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-software")
            .arg("--mode=updates")
            .spawn();
    });

    updates_group.add(&auto_updates);
    updates_group.add(&check_updates);

    // Storage group
    let storage_group = adw::PreferencesGroup::builder()
        .title("Storage")
        .build();

    let storage_info = get_storage_info();
    let storage_row = adw::ActionRow::builder()
        .title("Disk Usage")
        .subtitle(&storage_info)
        .activatable(true)
        .build();
    storage_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    storage_row.connect_activated(|_| {
        let _ = std::process::Command::new("baobab").spawn();
    });

    let clean_storage = adw::ActionRow::builder()
        .title("Clean Up Storage")
        .subtitle("Remove temporary files and caches")
        .activatable(true)
        .build();
    clean_storage.add_prefix(&gtk::Image::from_icon_name("user-trash-symbolic"));

    storage_group.add(&storage_row);
    storage_group.add(&clean_storage);

    // Power group
    let power_group = adw::PreferencesGroup::builder()
        .title("Power")
        .build();

    let power_mode = adw::ComboRow::builder()
        .title("Power Mode")
        .build();

    let modes = gtk::StringList::new(&["Balanced", "Power Saver", "Performance"]);
    power_mode.set_model(Some(&modes));

    let suspend_row = adw::ComboRow::builder()
        .title("Automatic Suspend")
        .build();

    let suspend_times = gtk::StringList::new(&["15 minutes", "30 minutes", "1 hour", "Never"]);
    suspend_row.set_model(Some(&suspend_times));
    suspend_row.set_selected(1);

    power_group.add(&power_mode);
    power_group.add(&suspend_row);

    // Users group
    let users_group = adw::PreferencesGroup::builder()
        .title("Users")
        .build();

    let current_user = adw::ActionRow::builder()
        .title(&get_current_user())
        .subtitle("Administrator")
        .activatable(true)
        .build();

    let user_icon = gtk::Image::from_icon_name("avatar-default-symbolic");
    current_user.add_prefix(&user_icon);
    current_user.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    current_user.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("user-accounts")
            .spawn();
    });

    users_group.add(&current_user);

    // Date & Time group
    let datetime_group = adw::PreferencesGroup::builder()
        .title("Date & Time")
        .build();

    let auto_datetime = create_switch_row(
        "Automatic Date & Time",
        "",
        true
    );

    let timezone_row = adw::ActionRow::builder()
        .title("Time Zone")
        .subtitle(&get_timezone())
        .activatable(true)
        .build();
    timezone_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    datetime_group.add(&auto_datetime);
    datetime_group.add(&timezone_row);

    page.add(&updates_group);
    page.add(&storage_group);
    page.add(&power_group);
    page.add(&users_group);
    page.add(&datetime_group);

    page
}

// Helper to create ActionRow with Switch (libadwaita 1.2 compatible)
fn create_switch_row(title: &str, subtitle: &str, active: bool) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .build();
    
    if !subtitle.is_empty() {
        row.set_subtitle(subtitle);
    }
    
    let switch = gtk::Switch::builder()
        .active(active)
        .valign(gtk::Align::Center)
        .build();
    
    row.add_suffix(&switch);
    row.set_activatable_widget(Some(&switch));
    row
}

fn get_storage_info() -> String {
    "Unknown".to_string()
}

fn get_current_user() -> String {
    std::env::var("USER").unwrap_or_else(|_| "User".to_string())
}

fn get_timezone() -> String {
    "UTC".to_string()
}
