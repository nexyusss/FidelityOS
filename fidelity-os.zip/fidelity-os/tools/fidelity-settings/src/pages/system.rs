// System settings page

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("System")
        .icon_name("computer-symbolic")
        .build();

    // Updates group
    let updates_group = adw::PreferencesGroup::builder()
        .title("Software Updates")
        .build();

    let auto_updates = adw::SwitchRow::builder()
        .title("Automatic Updates")
        .subtitle("Install security updates automatically")
        .active(true)
        .build();

    let check_updates = adw::ActionRow::builder()
        .title("Check for Updates")
        .activatable(true)
        .build();
    check_updates.add_prefix(&gtk::Image::from_icon_name("emblem-synchronizing-symbolic"));

    check_updates.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-software")
            .arg("--mode=updates")
            .spawn();
    });

    updates_group.add(&auto_updates);
    updates_group.add(&check_updates);

    // Storage group
    let storage_group = adw::PreferencesGroup::builder()
        .title("Storage")
        .build();

    let storage_info = get_storage_info();
    let storage_row = adw::ActionRow::builder()
        .title("Disk Usage")
        .subtitle(&storage_info)
        .activatable(true)
        .build();
    storage_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    storage_row.connect_activated(|_| {
        let _ = std::process::Command::new("baobab").spawn();
    });

    let clean_storage = adw::ActionRow::builder()
        .title("Clean Up Storage")
        .subtitle("Remove temporary files and caches")
        .activatable(true)
        .build();
    clean_storage.add_prefix(&gtk::Image::from_icon_name("user-trash-symbolic"));

    storage_group.add(&storage_row);
    storage_group.add(&clean_storage);

    // Power group
    let power_group = adw::PreferencesGroup::builder()
        .title("Power")
        .build();

    let power_mode = adw::ComboRow::builder()
        .title("Power Mode")
        .build();

    let modes = gtk::StringList::new(&["Balanced", "Power Saver", "Performance"]);
    power_mode.set_model(Some(&modes));

    let suspend_row = adw::ComboRow::builder()
        .title("Automatic Suspend")
        .build();

    let suspend_times = gtk::StringList::new(&["15 minutes", "30 minutes", "1 hour", "Never"]);
    suspend_row.set_model(Some(&suspend_times));
    suspend_row.set_selected(1);

    power_group.add(&power_mode);
    power_group.add(&suspend_row);

    // Users group
    let users_group = adw::PreferencesGroup::builder()
        .title("Users")
        .build();

    let current_user = adw::ActionRow::builder()
        .title(&get_current_user())
        .subtitle("Administrator")
        .activatable(true)
        .build();

    let user_icon = gtk::Image::from_icon_name("avatar-default-symbolic");
    current_user.add_prefix(&user_icon);
    current_user.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    current_user.connect_activated(|_| {
        let _ = std::process::Command::new("gnome-control-center")
            .arg("user-accounts")
            .spawn();
    });

    users_group.add(&current_user);

    // Date & Time group
    let datetime_group = adw::PreferencesGroup::builder()
        .title("Date & Time")
        .build();

    let auto_datetime = adw::SwitchRow::builder()
        .title("Automatic Date & Time")
        .active(true)
        .build();

    let timezone_row = adw::ActionRow::builder()
        .title("Time Zone")
        .subtitle(&get_timezone())
        .activatable(true)
        .build();
    timezone_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    datetime_group.add(&auto_datetime);
    datetime_group.add(&timezone_row);

    page.add(&updates_group);
    page.add(&storage_group);
    page.add(&power_group);
    page.add(&users_group);
    page.add(&datetime_group);

    page
}

fn get_storage_info() -> String {
    let output = std::process::Command::new("df")
        .args(["-h", "/"])
        .output()
        .ok();

    if let Some(out) = output {
        let text = String::from_utf8_lossy(&out.stdout);
        if let Some(line) = text.lines().nth(1) {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() >= 4 {
                return format!("{} used of {}", parts[2], parts[1]);
            }
        }
    }
    "Unknown".to_string()
}

fn get_current_user() -> String {
    std::env::var("USER").unwrap_or_else(|_| "User".to_string())
}

fn get_timezone() -> String {
    std::fs::read_link("/etc/localtime")
        .ok()
        .and_then(|p| p.to_str().map(|s| s.replace("/usr/share/zoneinfo/", "")))
        .unwrap_or_else(|| "UTC".to_string())
}
