// About page - Enhanced system information with visual polish

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("About")
        .icon_name("help-about-symbolic")
        .build();

    // FidelityOS Hero Section
    let hero_group = adw::PreferencesGroup::new();
    
    let hero_box = gtk::Box::new(gtk::Orientation::Vertical, 16);
    hero_box.set_margin_top(24);
    hero_box.set_margin_bottom(24);
    hero_box.set_halign(gtk::Align::Center);

    // Logo
    let logo = gtk::Image::builder()
        .icon_name("security-high-symbolic")
        .pixel_size(80)
        .opacity(0.9)
        .build();
    logo.add_css_class("accent");

    // OS Name
    let name_label = gtk::Label::builder()
        .label("FidelityOS")
        .css_classes(["title-1"])
        .build();

    // Version badge
    let version_badge = gtk::Label::builder()
        .label(&format!("Version {}", get_fidelity_version()))
        .css_classes(["caption"])
        .build();

    // Tagline
    let tagline = gtk::Label::builder()
        .label("Clean. Fast. Private. Yours.")
        .css_classes(["dim-label"])
        .margin_top(4)
        .build();

    hero_box.append(&logo);
    hero_box.append(&name_label);
    hero_box.append(&version_badge);
    hero_box.append(&tagline);

    let hero_row = adw::ActionRow::new();
    hero_row.set_child(Some(&hero_box));
    hero_group.add(&hero_row);

    // Device Info group
    let device_group = adw::PreferencesGroup::builder()
        .title("Device")
        .build();

    let device_name = get_device_name();
    let device_row = adw::ActionRow::builder()
        .title("Device Name")
        .subtitle(&device_name)
        .build();
    device_row.add_prefix(&gtk::Image::from_icon_name("computer-symbolic"));

    let (cpu, ram, disk, gpu) = get_hardware_info();

    let cpu_row = adw::ActionRow::builder()
        .title("Processor")
        .subtitle(&cpu)
        .build();
    cpu_row.add_prefix(&gtk::Image::from_icon_name("processor-symbolic"));

    let ram_row = adw::ActionRow::builder()
        .title("Memory")
        .subtitle(&ram)
        .build();
    ram_row.add_prefix(&gtk::Image::from_icon_name("memory-symbolic"));

    let disk_row = adw::ActionRow::builder()
        .title("Storage")
        .subtitle(&disk)
        .build();
    disk_row.add_prefix(&gtk::Image::from_icon_name("drive-harddisk-symbolic"));

    let gpu_row = adw::ActionRow::builder()
        .title("Graphics")
        .subtitle(&gpu)
        .build();
    gpu_row.add_prefix(&gtk::Image::from_icon_name("video-display-symbolic"));

    device_group.add(&device_row);
    device_group.add(&cpu_row);
    device_group.add(&ram_row);
    device_group.add(&disk_row);
    device_group.add(&gpu_row);

    // Software group
    let software_group = adw::PreferencesGroup::builder()
        .title("Software")
        .build();

    let os_row = adw::ActionRow::builder()
        .title("Operating System")
        .subtitle(&format!("FidelityOS {} (Genesis)", get_fidelity_version()))
        .build();
    os_row.add_prefix(&gtk::Image::from_icon_name("emblem-system-symbolic"));

    let kernel_row = adw::ActionRow::builder()
        .title("Kernel")
        .subtitle(&get_kernel_version())
        .build();
    kernel_row.add_prefix(&gtk::Image::from_icon_name("application-x-firmware-symbolic"));

    let gnome_row = adw::ActionRow::builder()
        .title("Desktop")
        .subtitle(&format!("GNOME {}", get_gnome_version()))
        .build();
    gnome_row.add_prefix(&gtk::Image::from_icon_name("user-desktop-symbolic"));

    let windowing_row = adw::ActionRow::builder()
        .title("Windowing System")
        .subtitle(&get_windowing_system())
        .build();
    windowing_row.add_prefix(&gtk::Image::from_icon_name("view-fullscreen-symbolic"));

    software_group.add(&os_row);
    software_group.add(&kernel_row);
    software_group.add(&gnome_row);
    software_group.add(&windowing_row);

    // Links group
    let links_group = adw::PreferencesGroup::builder()
        .title("Resources")
        .build();

    let website_row = adw::ActionRow::builder()
        .title("Website")
        .subtitle("fidelityos.org")
        .activatable(true)
        .build();
    website_row.add_prefix(&gtk::Image::from_icon_name("web-browser-symbolic"));
    website_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));
    website_row.connect_activated(|_| open_url("https://fidelityos.org"));

    let docs_row = adw::ActionRow::builder()
        .title("Documentation")
        .subtitle("User guides and tutorials")
        .activatable(true)
        .build();
    docs_row.add_prefix(&gtk::Image::from_icon_name("accessories-dictionary-symbolic"));
    docs_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));
    docs_row.connect_activated(|_| open_url("https://fidelityos.org/docs"));

    let github_row = adw::ActionRow::builder()
        .title("Source Code")
        .subtitle("GitHub repository")
        .activatable(true)
        .build();
    github_row.add_prefix(&gtk::Image::from_icon_name("folder-remote-symbolic"));
    github_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));
    github_row.connect_activated(|_| open_url("https://github.com/nexyusss/FidelityOS"));

    let report_row = adw::ActionRow::builder()
        .title("Report an Issue")
        .subtitle("Help us improve FidelityOS")
        .activatable(true)
        .build();
    report_row.add_prefix(&gtk::Image::from_icon_name("dialog-warning-symbolic"));
    report_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));
    report_row.connect_activated(|_| open_url("https://github.com/nexyusss/FidelityOS/issues"));

    links_group.add(&website_row);
    links_group.add(&docs_row);
    links_group.add(&github_row);
    links_group.add(&report_row);

    // Legal group
    let legal_group = adw::PreferencesGroup::builder()
        .title("Legal")
        .build();

    let license_row = adw::ActionRow::builder()
        .title("License")
        .subtitle("GNU General Public License v3.0")
        .activatable(true)
        .build();
    license_row.add_prefix(&gtk::Image::from_icon_name("text-x-copying-symbolic"));
    license_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    let credits_row = adw::ActionRow::builder()
        .title("Credits")
        .subtitle("Contributors and acknowledgments")
        .activatable(true)
        .build();
    credits_row.add_prefix(&gtk::Image::from_icon_name("system-users-symbolic"));
    credits_row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    legal_group.add(&license_row);
    legal_group.add(&credits_row);

    page.add(&hero_group);
    page.add(&device_group);
    page.add(&software_group);
    page.add(&links_group);
    page.add(&legal_group);

    page
}

fn open_url(url: &str) {
    let _ = gtk::gio::AppInfo::launch_default_for_uri(
        url,
        None::<&gtk::gio::AppLaunchContext>,
    );
}

fn get_fidelity_version() -> String {
    std::fs::read_to_string("/etc/fidelity/version")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("FIDELITY_VERSION"))
            .map(|l| l.split('=').nth(1).unwrap_or("1.0").trim_matches('"').to_string()))
        .unwrap_or_else(|| "1.0".to_string())
}

fn get_device_name() -> String {
    std::fs::read_to_string("/etc/hostname")
        .ok()
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|| "FidelityOS".to_string())
}

fn get_hardware_info() -> (String, String, String, String) {
    let cpu = std::fs::read_to_string("/proc/cpuinfo")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("model name"))
            .map(|l| l.split(':').nth(1).unwrap_or("Unknown").trim().to_string()))
        .unwrap_or_else(|| "Unknown".to_string());

    let ram = std::fs::read_to_string("/proc/meminfo")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("MemTotal"))
            .map(|l| {
                let kb: u64 = l.split_whitespace().nth(1).unwrap_or("0").parse().unwrap_or(0);
                format!("{:.1} GB", kb as f64 / 1024.0 / 1024.0)
            }))
        .unwrap_or_else(|| "Unknown".to_string());

    let disk = std::process::Command::new("lsblk")
        .args(["-d", "-o", "SIZE", "-n"])
        .output()
        .ok()
        .map(|o| {
            let output = String::from_utf8_lossy(&o.stdout);
            output.lines().next().unwrap_or("Unknown").trim().to_string()
        })
        .unwrap_or_else(|| "Unknown".to_string());

    let gpu = std::process::Command::new("lspci")
        .output()
        .ok()
        .map(|o| {
            let output = String::from_utf8_lossy(&o.stdout);
            output.lines()
                .find(|l| l.contains("VGA") || l.contains("3D"))
                .map(|l| {
                    l.split(':').last()
                        .unwrap_or("Unknown")
                        .trim()
                        .chars()
                        .take(50)
                        .collect::<String>()
                })
                .unwrap_or_else(|| "Unknown".to_string())
        })
        .unwrap_or_else(|| "Unknown".to_string());

    (cpu, ram, disk, gpu)
}

fn get_kernel_version() -> String {
    std::process::Command::new("uname")
        .arg("-r")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_else(|| "Unknown".to_string())
}

fn get_gnome_version() -> String {
    std::process::Command::new("gnome-shell")
        .arg("--version")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).replace("GNOME Shell ", "").trim().to_string())
        .unwrap_or_else(|| "Unknown".to_string())
}

fn get_windowing_system() -> String {
    std::env::var("XDG_SESSION_TYPE")
        .ok()
        .map(|s| match s.as_str() {
            "wayland" => "Wayland".to_string(),
            "x11" => "X11".to_string(),
            _ => s,
        })
        .unwrap_or_else(|| "Unknown".to_string())
}
