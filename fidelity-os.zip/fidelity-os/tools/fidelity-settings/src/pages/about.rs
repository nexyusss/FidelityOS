// About page - System information

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

pub fn create() -> adw::PreferencesPage {
    let page = adw::PreferencesPage::builder()
        .title("About")
        .icon_name("help-about-symbolic")
        .build();

    // FidelityOS info group
    let fidelity_group = adw::PreferencesGroup::builder()
        .title("FidelityOS")
        .build();

    let version_row = adw::ActionRow::builder()
        .title("Version")
        .subtitle(&get_fidelity_version())
        .build();

    let build_row = adw::ActionRow::builder()
        .title("Build Date")
        .subtitle(&get_build_date())
        .build();

    let website_row = adw::ActionRow::builder()
        .title("Website")
        .subtitle("fidelityos.org")
        .activatable(true)
        .build();
    website_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));

    website_row.connect_activated(|_| {
        let _ = gtk::gio::AppInfo::launch_default_for_uri(
            "https://fidelityos.org",
            gtk::gio::AppLaunchContext::NONE,
        );
    });

    fidelity_group.add(&version_row);
    fidelity_group.add(&build_row);
    fidelity_group.add(&website_row);

    // Hardware group
    let hardware_group = adw::PreferencesGroup::builder()
        .title("Hardware")
        .build();

    let (cpu, ram, disk) = get_hardware_info();

    let cpu_row = adw::ActionRow::builder()
        .title("Processor")
        .subtitle(&cpu)
        .build();

    let ram_row = adw::ActionRow::builder()
        .title("Memory")
        .subtitle(&ram)
        .build();

    let disk_row = adw::ActionRow::builder()
        .title("Storage")
        .subtitle(&disk)
        .build();

    hardware_group.add(&cpu_row);
    hardware_group.add(&ram_row);
    hardware_group.add(&disk_row);

    // Software group
    let software_group = adw::PreferencesGroup::builder()
        .title("Software")
        .build();

    let kernel_row = adw::ActionRow::builder()
        .title("Kernel")
        .subtitle(&get_kernel_version())
        .build();

    let gnome_row = adw::ActionRow::builder()
        .title("GNOME")
        .subtitle(&get_gnome_version())
        .build();

    let gtk_row = adw::ActionRow::builder()
        .title("GTK")
        .subtitle("4.12")
        .build();

    software_group.add(&kernel_row);
    software_group.add(&gnome_row);
    software_group.add(&gtk_row);

    // Support group
    let support_group = adw::PreferencesGroup::builder()
        .title("Support")
        .build();

    let docs_row = adw::ActionRow::builder()
        .title("Documentation")
        .activatable(true)
        .build();
    docs_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));

    docs_row.connect_activated(|_| {
        let _ = gtk::gio::AppInfo::launch_default_for_uri(
            "https://fidelityos.org/docs",
            gtk::gio::AppLaunchContext::NONE,
        );
    });

    let community_row = adw::ActionRow::builder()
        .title("Community")
        .activatable(true)
        .build();
    community_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));

    let report_row = adw::ActionRow::builder()
        .title("Report an Issue")
        .activatable(true)
        .build();
    report_row.add_suffix(&gtk::Image::from_icon_name("external-link-symbolic"));

    support_group.add(&docs_row);
    support_group.add(&community_row);
    support_group.add(&report_row);

    page.add(&fidelity_group);
    page.add(&hardware_group);
    page.add(&software_group);
    page.add(&support_group);

    page
}

fn get_fidelity_version() -> String {
    std::fs::read_to_string("/etc/fidelity/version")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("FIDELITY_VERSION"))
            .map(|l| l.split('=').nth(1).unwrap_or("1.0").trim_matches('"').to_string()))
        .unwrap_or_else(|| "1.0".to_string())
}

fn get_build_date() -> String {
    std::fs::read_to_string("/etc/fidelity/version")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("FIDELITY_BUILD_DATE"))
            .map(|l| l.split('=').nth(1).unwrap_or("Unknown").trim_matches('"').to_string()))
        .unwrap_or_else(|| "Unknown".to_string())
}

fn get_hardware_info() -> (String, String, String) {
    let cpu = std::fs::read_to_string("/proc/cpuinfo")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("model name"))
            .map(|l| l.split(':').nth(1).unwrap_or("Unknown").trim().to_string()))
        .unwrap_or_else(|| "Unknown".to_string());

    let ram = std::fs::read_to_string("/proc/meminfo")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("MemTotal"))
            .map(|l| {
                let kb: u64 = l.split_whitespace().nth(1).unwrap_or("0").parse().unwrap_or(0);
                format!("{:.1} GB", kb as f64 / 1024.0 / 1024.0)
            }))
        .unwrap_or_else(|| "Unknown".to_string());

    let disk = std::process::Command::new("lsblk")
        .args(["-d", "-o", "SIZE", "-n"])
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).lines().next().unwrap_or("Unknown").trim().to_string())
        .unwrap_or_else(|| "Unknown".to_string());

    (cpu, ram, disk)
}

fn get_kernel_version() -> String {
    std::process::Command::new("uname")
        .arg("-r")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string())
        .unwrap_or_else(|| "Unknown".to_string())
}

fn get_gnome_version() -> String {
    std::process::Command::new("gnome-shell")
        .arg("--version")
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).replace("GNOME Shell ", "").trim().to_string())
        .unwrap_or_else(|| "Unknown".to_string())
}
