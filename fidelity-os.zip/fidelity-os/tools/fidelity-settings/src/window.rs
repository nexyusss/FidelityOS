// Main settings window with navigation
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

use crate::pages;

pub fn build_window(app: &adw::Application) -> adw::ApplicationWindow {
    let window = adw::ApplicationWindow::builder()
        .application(app)
        .title("FidelityOS Settings")
        .default_width(1000)
        .default_height(700)
        .build();

    // Use Leaflet for adaptive layout (libadwaita 1.2 compatible)
    let leaflet = adw::Leaflet::builder()
        .can_navigate_back(true)
        .can_unfold(true)
        .build();
    
    // Sidebar with categories
    let sidebar_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let sidebar_header = adw::HeaderBar::builder()
        .title_widget(&gtk::Label::new(Some("Settings")))
        .show_end_title_buttons(false)
        .build();
    
    let sidebar = create_sidebar();
    let sidebar_scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vexpand(true)
        .child(&sidebar)
        .build();
    
    sidebar_box.append(&sidebar_header);
    sidebar_box.append(&sidebar_scroll);
    
    // Content area
    let content_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    let content_header = adw::HeaderBar::builder()
        .show_start_title_buttons(false)
        .build();
    
    let content_stack = gtk::Stack::builder()
        .transition_type(gtk::StackTransitionType::Crossfade)
        .vexpand(true)
        .build();

    // Add all settings pages
    let appearance_page = pages::appearance::create();
    let privacy_page = pages::privacy::create();
    let network_page = pages::network::create();
    let apps_page = pages::apps::create();
    let system_page = pages::system::create();
    let about_page = pages::about::create();

    content_stack.add_titled(&appearance_page, Some("appearance"), "Appearance");
    content_stack.add_titled(&privacy_page, Some("privacy"), "Privacy & Security");
    content_stack.add_titled(&network_page, Some("network"), "Network");
    content_stack.add_titled(&apps_page, Some("apps"), "Applications");
    content_stack.add_titled(&system_page, Some("system"), "System");
    content_stack.add_titled(&about_page, Some("about"), "About");

    content_box.append(&content_header);
    content_box.append(&content_stack);

    // Connect sidebar selection to stack
    let stack_clone = content_stack.clone();
    let leaflet_clone = leaflet.clone();
    sidebar.connect_row_selected(move |_, row| {
        if let Some(row) = row {
            let index = row.index();
            let page_name = match index {
                0 => "appearance",
                1 => "privacy",
                2 => "network",
                3 => "apps",
                4 => "system",
                5 => "about",
                _ => "appearance",
            };
            stack_clone.set_visible_child_name(page_name);
            // Navigate to content on mobile
            leaflet_clone.navigate(adw::NavigationDirection::Forward);
        }
    });

    // Add separator between sidebar and content
    let separator = gtk::Separator::new(gtk::Orientation::Vertical);

    leaflet.append(&sidebar_box);
    leaflet.append(&separator);
    leaflet.append(&content_box);

    // Set content as navigatable
    leaflet.set_can_navigate_back(true);

    window.set_content(Some(&leaflet));
    window
}

fn create_sidebar() -> gtk::ListBox {
    let listbox = gtk::ListBox::builder()
        .selection_mode(gtk::SelectionMode::Single)
        .build();
    listbox.add_css_class("navigation-sidebar");

    let categories = [
        ("preferences-desktop-appearance-symbolic", "Appearance", "Themes, colors, fonts"),
        ("security-high-symbolic", "Privacy & Security", "Firewall, encryption, privacy"),
        ("network-wireless-symbolic", "Network", "WiFi, VPN, proxy"),
        ("application-x-executable-symbolic", "Applications", "Default apps, startup"),
        ("computer-symbolic", "System", "Updates, storage, users"),
        ("help-about-symbolic", "About", "System info, support"),
    ];

    for (icon, title, subtitle) in categories {
        let row = create_sidebar_row(icon, title, subtitle);
        listbox.append(&row);
    }

    // Select first row by default
    if let Some(first_row) = listbox.row_at_index(0) {
        listbox.select_row(Some(&first_row));
    }

    listbox
}

fn create_sidebar_row(icon: &str, title: &str, subtitle: &str) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .subtitle(subtitle)
        .activatable(true)
        .build();
    
    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(24)
        .margin_end(8)
        .build();
    row.add_prefix(&icon_widget);
    
    row
}
