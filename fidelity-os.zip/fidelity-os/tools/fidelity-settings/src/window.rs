// Main settings window with navigation

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

use crate::pages;

pub fn build_window(app: &adw::Application) -> adw::ApplicationWindow {
    let window = adw::ApplicationWindow::builder()
        .application(app)
        .title("FidelityOS Settings")
        .default_width(1000)
        .default_height(700)
        .build();

    // Navigation view for adaptive layout
    let nav_view = adw::NavigationSplitView::new();
    
    // Sidebar with categories
    let sidebar = create_sidebar();
    
    // Content area
    let content_stack = gtk::Stack::builder()
        .transition_type(gtk::StackTransitionType::Crossfade)
        .build();

    // Add all settings pages
    let appearance_page = pages::appearance::create();
    let privacy_page = pages::privacy::create();
    let network_page = pages::network::create();
    let apps_page = pages::apps::create();
    let system_page = pages::system::create();
    let about_page = pages::about::create();

    content_stack.add_titled(&appearance_page, Some("appearance"), "Appearance");
    content_stack.add_titled(&privacy_page, Some("privacy"), "Privacy & Security");
    content_stack.add_titled(&network_page, Some("network"), "Network");
    content_stack.add_titled(&apps_page, Some("apps"), "Applications");
    content_stack.add_titled(&system_page, Some("system"), "System");
    content_stack.add_titled(&about_page, Some("about"), "About");

    // Content page with header
    let content_page = adw::NavigationPage::builder()
        .title("Settings")
        .child(&content_stack)
        .build();

    // Sidebar page
    let sidebar_page = adw::NavigationPage::builder()
        .title("Settings")
        .child(&sidebar)
        .build();

    // Connect sidebar selection to stack
    let stack_clone = content_stack.clone();
    sidebar.connect_row_selected(move |_, row| {
        if let Some(row) = row {
            let index = row.index();
            let page_name = match index {
                0 => "appearance",
                1 => "privacy",
                2 => "network",
                3 => "apps",
                4 => "system",
                5 => "about",
                _ => "appearance",
            };
            stack_clone.set_visible_child_name(page_name);
        }
    });

    nav_view.set_sidebar(&sidebar_page);
    nav_view.set_content(&content_page);

    window.set_content(Some(&nav_view));
    window
}

fn create_sidebar() -> gtk::ListBox {
    let listbox = gtk::ListBox::builder()
        .selection_mode(gtk::SelectionMode::Single)
        .css_classes(["navigation-sidebar"])
        .build();

    let categories = [
        ("preferences-desktop-appearance-symbolic", "Appearance", "Themes, colors, fonts"),
        ("security-high-symbolic", "Privacy & Security", "Firewall, encryption, privacy"),
        ("network-wireless-symbolic", "Network", "WiFi, VPN, proxy"),
        ("application-x-executable-symbolic", "Applications", "Default apps, startup"),
        ("computer-symbolic", "System", "Updates, storage, users"),
        ("help-about-symbolic", "About", "System info, support"),
    ];

    for (icon, title, subtitle) in categories {
        let row = create_sidebar_row(icon, title, subtitle);
        listbox.append(&row);
    }

    // Select first row by default
    if let Some(first_row) = listbox.row_at_index(0) {
        listbox.select_row(Some(&first_row));
    }

    listbox
}

fn create_sidebar_row(icon: &str, title: &str, subtitle: &str) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(title)
        .subtitle(subtitle)
        .activatable(true)
        .build();
    
    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(24)
        .margin_end(8)
        .build();
    row.add_prefix(&icon_widget);
    
    row
}
