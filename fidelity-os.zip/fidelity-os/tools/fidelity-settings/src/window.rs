// Main settings window with polished navigation
// Compatible with libadwaita 1.2 (Debian Bookworm)

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

use crate::pages;

pub fn build_window(app: &adw::Application) -> adw::ApplicationWindow {
    let window = adw::ApplicationWindow::builder()
        .application(app)
        .title("FidelityOS Settings")
        .default_width(980)
        .default_height(680)
        .build();

    // Main horizontal layout
    let main_box = gtk::Box::new(gtk::Orientation::Horizontal, 0);

    // Sidebar
    let sidebar_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    sidebar_box.set_size_request(280, -1);
    sidebar_box.add_css_class("sidebar");

    let sidebar_header = adw::HeaderBar::builder()
        .show_end_title_buttons(false)
        .build();
    
    // Sidebar title with icon
    let title_box = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    title_box.set_halign(gtk::Align::Center);

    let title_icon = gtk::Image::builder()
        .icon_name("emblem-system-symbolic")
        .pixel_size(18)
        .opacity(0.7)
        .build();

    let sidebar_title = gtk::Label::builder()
        .label("Settings")
        .css_classes(["title"])
        .build();

    title_box.append(&title_icon);
    title_box.append(&sidebar_title);
    sidebar_header.set_title_widget(Some(&title_box));
    
    let sidebar = create_sidebar();
    let sidebar_scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vexpand(true)
        .child(&sidebar)
        .build();
    
    sidebar_box.append(&sidebar_header);
    sidebar_box.append(&sidebar_scroll);
    
    // Content area
    let content_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    content_box.set_hexpand(true);

    let content_header = adw::HeaderBar::builder()
        .show_start_title_buttons(false)
        .build();

    // Initial title
    let content_title = gtk::Label::builder()
        .label("Appearance")
        .css_classes(["title"])
        .build();
    content_header.set_title_widget(Some(&content_title));
    
    let content_stack = gtk::Stack::builder()
        .transition_type(gtk::StackTransitionType::Crossfade)
        .vexpand(true)
        .build();

    // Add all settings pages
    let appearance_page = pages::appearance::create();
    let privacy_page = pages::privacy::create();
    let network_page = pages::network::create();
    let apps_page = pages::apps::create();
    let system_page = pages::system::create();
    let about_page = pages::about::create();

    content_stack.add_titled(&appearance_page, Some("appearance"), "Appearance");
    content_stack.add_titled(&privacy_page, Some("privacy"), "Privacy & Security");
    content_stack.add_titled(&network_page, Some("network"), "Network");
    content_stack.add_titled(&apps_page, Some("apps"), "Applications");
    content_stack.add_titled(&system_page, Some("system"), "System");
    content_stack.add_titled(&about_page, Some("about"), "About");

    // Wrap content in scrolled window
    let content_scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vexpand(true)
        .child(&content_stack)
        .build();

    content_box.append(&content_header);
    content_box.append(&content_scroll);

    // Connect sidebar selection to stack
    let stack_clone = content_stack.clone();
    let header_clone = content_header.clone();
    sidebar.connect_row_selected(move |_, row| {
        if let Some(row) = row {
            let index = row.index();
            let (page_name, title, icon) = match index {
                0 => ("appearance", "Appearance", "preferences-desktop-appearance-symbolic"),
                1 => ("privacy", "Privacy & Security", "security-high-symbolic"),
                2 => ("network", "Network", "network-wireless-symbolic"),
                3 => ("apps", "Applications", "application-x-executable-symbolic"),
                4 => ("system", "System", "computer-symbolic"),
                5 => ("about", "About", "help-about-symbolic"),
                _ => ("appearance", "Appearance", "preferences-desktop-appearance-symbolic"),
            };
            stack_clone.set_visible_child_name(page_name);
            
            // Update header with icon and title
            let title_box = gtk::Box::new(gtk::Orientation::Horizontal, 8);
            title_box.set_halign(gtk::Align::Center);

            let title_icon = gtk::Image::builder()
                .icon_name(icon)
                .pixel_size(18)
                .opacity(0.7)
                .build();

            let title_label = gtk::Label::builder()
                .label(title)
                .css_classes(["title"])
                .build();

            title_box.append(&title_icon);
            title_box.append(&title_label);
            header_clone.set_title_widget(Some(&title_box));
        }
    });

    // Separator
    let separator = gtk::Separator::new(gtk::Orientation::Vertical);

    main_box.append(&sidebar_box);
    main_box.append(&separator);
    main_box.append(&content_box);

    window.set_content(Some(&main_box));
    window
}

fn create_sidebar() -> gtk::ListBox {
    let listbox = gtk::ListBox::builder()
        .selection_mode(gtk::SelectionMode::Single)
        .build();
    listbox.add_css_class("navigation-sidebar");

    let categories = [
        ("preferences-desktop-appearance-symbolic", "Appearance", "Themes, colors, fonts", "🎨"),
        ("security-high-symbolic", "Privacy & Security", "Firewall, encryption", "🔒"),
        ("network-wireless-symbolic", "Network", "WiFi, VPN, proxy", "📶"),
        ("application-x-executable-symbolic", "Applications", "Default apps, startup", "📦"),
        ("computer-symbolic", "System", "Updates, storage, users", "💻"),
        ("help-about-symbolic", "About", "System information", "ℹ️"),
    ];

    for (icon, title, subtitle, _emoji) in categories {
        let row = create_sidebar_row(icon, title, subtitle);
        listbox.append(&row);
    }

    // Select first row by default
    if let Some(first_row) = listbox.row_at_index(0) {
        listbox.select_row(Some(&first_row));
    }

    listbox
}

fn create_sidebar_row(icon: &str, title: &str, subtitle: &str) -> gtk::ListBoxRow {
    let row = gtk::ListBoxRow::builder()
        .build();

    let content = gtk::Box::new(gtk::Orientation::Horizontal, 14);
    content.set_margin_top(12);
    content.set_margin_bottom(12);
    content.set_margin_start(14);
    content.set_margin_end(14);

    // Icon with subtle background
    let icon_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    icon_box.set_valign(gtk::Align::Center);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(22)
        .opacity(0.85)
        .build();

    icon_box.append(&icon_widget);

    // Text content
    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 2);
    text_box.set_valign(gtk::Align::Center);
    
    let title_label = gtk::Label::builder()
        .label(title)
        .halign(gtk::Align::Start)
        .css_classes(["heading"])
        .build();

    let subtitle_label = gtk::Label::builder()
        .label(subtitle)
        .halign(gtk::Align::Start)
        .css_classes(["caption", "dim-label"])
        .build();

    text_box.append(&title_label);
    text_box.append(&subtitle_label);

    // Arrow indicator
    let arrow = gtk::Image::builder()
        .icon_name("go-next-symbolic")
        .pixel_size(16)
        .opacity(0.3)
        .hexpand(true)
        .halign(gtk::Align::End)
        .build();

    content.append(&icon_box);
    content.append(&text_box);
    content.append(&arrow);

    row.set_child(Some(&content));
    row
}
