// Backend for APT and Flatpak operations

use std::process::Command;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum AppSource {
    System,  // APT
    Flatpak,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppInfo {
    pub id: String,
    pub name: String,
    pub summary: String,
    pub icon: String,
    pub source: AppSource,
    pub installed: bool,
    pub version: String,
}

pub fn get_installed_apps() -> Vec<AppInfo> {
    let mut apps = Vec::new();
    
    // Get Flatpak apps
    if let Ok(output) = Command::new("flatpak")
        .args(["list", "--app", "--columns=application,name,version"])
        .output()
    {
        let stdout = String::from_utf8_lossy(&output.stdout);
        for line in stdout.lines() {
            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() >= 3 {
                apps.push(AppInfo {
                    id: parts[0].to_string(),
                    name: parts[1].to_string(),
                    summary: String::new(),
                    icon: parts[0].to_string(),
                    source: AppSource::Flatpak,
                    installed: true,
                    version: parts[2].to_string(),
                });
            }
        }
    }

    // Get key system apps (simplified)
    let system_apps = [
        ("firefox-esr", "Firefox", "Web Browser"),
        ("thunderbird", "Thunderbird", "Email Client"),
        ("libreoffice", "LibreOffice", "Office Suite"),
        ("nautilus", "Files", "File Manager"),
    ];

    for (id, name, summary) in system_apps {
        if is_apt_installed(id) {
            apps.push(AppInfo {
                id: id.to_string(),
                name: name.to_string(),
                summary: summary.to_string(),
                icon: id.to_string(),
                source: AppSource::System,
                installed: true,
                version: get_apt_version(id),
            });
        }
    }

    apps
}

fn is_apt_installed(package: &str) -> bool {
    Command::new("dpkg")
        .args(["-s", package])
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false)
}

fn get_apt_version(package: &str) -> String {
    Command::new("dpkg-query")
        .args(["-W", "-f=${Version}", package])
        .output()
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).to_string())
        .unwrap_or_else(|| "Unknown".to_string())
}

pub fn search_apps(query: &str) -> Vec<AppInfo> {
    let mut results = Vec::new();
    let query_lower = query.to_lowercase();

    // Search Flatpak
    if let Ok(output) = Command::new("flatpak")
        .args(["search", query, "--columns=application,name,description"])
        .output()
    {
        let stdout = String::from_utf8_lossy(&output.stdout);
        for line in stdout.lines().take(20) {
            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() >= 2 {
                results.push(AppInfo {
                    id: parts[0].to_string(),
                    name: parts[1].to_string(),
                    summary: parts.get(2).unwrap_or(&"").to_string(),
                    icon: parts[0].to_string(),
                    source: AppSource::Flatpak,
                    installed: is_flatpak_installed(parts[0]),
                    version: String::new(),
                });
            }
        }
    }

    // Search APT
    if let Ok(output) = Command::new("apt-cache")
        .args(["search", query])
        .output()
    {
        let stdout = String::from_utf8_lossy(&output.stdout);
        for line in stdout.lines().take(10) {
            if let Some((name, desc)) = line.split_once(" - ") {
                if name.to_lowercase().contains(&query_lower) {
                    results.push(AppInfo {
                        id: name.to_string(),
                        name: name.to_string(),
                        summary: desc.to_string(),
                        icon: name.to_string(),
                        source: AppSource::System,
                        installed: is_apt_installed(name),
                        version: String::new(),
                    });
                }
            }
        }
    }

    results
}

fn is_flatpak_installed(app_id: &str) -> bool {
    Command::new("flatpak")
        .args(["info", app_id])
        .output()
        .map(|o| o.status.success())
        .unwrap_or(false)
}

pub fn install_app(app: &AppInfo) -> Result<(), String> {
    match app.source {
        AppSource::Flatpak => {
            Command::new("flatpak")
                .args(["install", "-y", "flathub", &app.id])
                .status()
                .map_err(|e| e.to_string())?;
        }
        AppSource::System => {
            Command::new("pkexec")
                .args(["apt", "install", "-y", &app.id])
                .status()
                .map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

pub fn uninstall_app(app: &AppInfo) -> Result<(), String> {
    match app.source {
        AppSource::Flatpak => {
            Command::new("flatpak")
                .args(["uninstall", "-y", &app.id])
                .status()
                .map_err(|e| e.to_string())?;
        }
        AppSource::System => {
            Command::new("pkexec")
                .args(["apt", "remove", "-y", &app.id])
                .status()
                .map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

pub fn update_all() {
    // Update Flatpaks
    let _ = Command::new("flatpak")
        .args(["update", "-y"])
        .spawn();

    // Update APT
    let _ = Command::new("pkexec")
        .args(["apt", "update"])
        .status();
    let _ = Command::new("pkexec")
        .args(["apt", "upgrade", "-y"])
        .spawn();
}

pub fn get_updates() -> Vec<AppInfo> {
    let mut updates = Vec::new();

    // Check Flatpak updates
    if let Ok(output) = Command::new("flatpak")
        .args(["remote-ls", "--updates", "--columns=application,name"])
        .output()
    {
        let stdout = String::from_utf8_lossy(&output.stdout);
        for line in stdout.lines() {
            let parts: Vec<&str> = line.split('\t').collect();
            if parts.len() >= 2 {
                updates.push(AppInfo {
                    id: parts[0].to_string(),
                    name: parts[1].to_string(),
                    summary: "Update available".to_string(),
                    icon: parts[0].to_string(),
                    source: AppSource::Flatpak,
                    installed: true,
                    version: String::new(),
                });
            }
        }
    }

    updates
}
