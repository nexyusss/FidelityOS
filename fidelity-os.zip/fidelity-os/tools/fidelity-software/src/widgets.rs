// UI widgets for Software Center - Polished with visual details

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

use crate::backend::{AppInfo, AppSource};

pub fn create_featured_banner() -> gtk::Box {
    let banner = gtk::Box::new(gtk::Orientation::Horizontal, 24);
    banner.add_css_class("card");
    banner.set_margin_top(8);
    banner.set_size_request(-1, 180);

    // Left content
    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 10);
    text_box.set_valign(gtk::Align::Center);
    text_box.set_hexpand(true);
    text_box.set_margin_start(28);
    text_box.set_margin_top(20);
    text_box.set_margin_bottom(20);

    // Badge
    let badge = gtk::Label::builder()
        .label("✨ Featured")
        .halign(gtk::Align::Start)
        .build();
    badge.add_css_class("featured-badge");

    let title = gtk::Label::builder()
        .label("Discover Great Software")
        .css_classes(["title-1"])
        .halign(gtk::Align::Start)
        .build();

    let subtitle = gtk::Label::builder()
        .label("Thousands of apps from Flathub and Debian repositories")
        .css_classes(["dim-label"])
        .halign(gtk::Align::Start)
        .wrap(true)
        .max_width_chars(40)
        .build();

    let browse_btn = gtk::Button::builder()
        .label("Browse All Apps →")
        .css_classes(["suggested-action", "pill"])
        .halign(gtk::Align::Start)
        .margin_top(8)
        .build();

    text_box.append(&badge);
    text_box.append(&title);
    text_box.append(&subtitle);
    text_box.append(&browse_btn);

    // Right icon
    let icon_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    icon_box.set_valign(gtk::Align::Center);
    icon_box.set_margin_end(28);

    let icon = gtk::Image::builder()
        .icon_name("system-software-install-symbolic")
        .pixel_size(72)
        .opacity(0.4)
        .build();

    icon_box.append(&icon);

    banner.append(&text_box);
    banner.append(&icon_box);

    banner
}

pub fn create_categories_grid() -> gtk::FlowBox {
    let flow = gtk::FlowBox::builder()
        .max_children_per_line(4)
        .min_children_per_line(2)
        .selection_mode(gtk::SelectionMode::None)
        .row_spacing(10)
        .column_spacing(10)
        .homogeneous(true)
        .margin_top(10)
        .build();

    let categories = [
        ("applications-internet-symbolic", "Internet", "🌐"),
        ("applications-multimedia-symbolic", "Multimedia", "🎬"),
        ("applications-office-symbolic", "Office", "📄"),
        ("applications-graphics-symbolic", "Graphics", "🎨"),
        ("applications-games-symbolic", "Games", "🎮"),
        ("applications-utilities-symbolic", "Utilities", "🔧"),
        ("applications-development-symbolic", "Development", "💻"),
        ("applications-science-symbolic", "Science", "🔬"),
    ];

    for (icon, name, _emoji) in categories {
        let card = create_category_card(icon, name);
        flow.append(&card);
    }

    flow
}

fn create_category_card(icon: &str, name: &str) -> gtk::Button {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 8);
    content.set_valign(gtk::Align::Center);
    content.set_margin_top(16);
    content.set_margin_bottom(16);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(36)
        .opacity(0.85)
        .build();

    let label = gtk::Label::builder()
        .label(name)
        .css_classes(["heading"])
        .build();

    // App count badge
    let count = gtk::Label::builder()
        .label("100+ apps")
        .css_classes(["caption", "dim-label"])
        .build();

    content.append(&icon_widget);
    content.append(&label);
    content.append(&count);

    let btn = gtk::Button::builder()
        .child(&content)
        .css_classes(["flat", "card"])
        .build();

    btn.set_size_request(140, 110);
    btn
}

pub fn create_app_row(apps: &[AppInfo]) -> gtk::Box {
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    container.set_margin_top(10);

    for app in apps {
        let card = create_app_card(app);
        container.append(&card);
    }

    // "See more" button at the end
    let more_btn = gtk::Button::builder()
        .css_classes(["flat", "card"])
        .build();
    more_btn.set_size_request(100, -1);

    let more_content = gtk::Box::new(gtk::Orientation::Vertical, 6);
    more_content.set_valign(gtk::Align::Center);
    more_content.set_margin_top(16);
    more_content.set_margin_bottom(16);

    let more_icon = gtk::Image::builder()
        .icon_name("go-next-symbolic")
        .pixel_size(24)
        .opacity(0.5)
        .build();

    let more_label = gtk::Label::builder()
        .label("See all")
        .css_classes(["caption", "dim-label"])
        .build();

    more_content.append(&more_icon);
    more_content.append(&more_label);
    more_btn.set_child(Some(&more_content));

    container.append(&more_btn);

    container
}

pub fn create_app_card(app: &AppInfo) -> gtk::Button {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 6);
    content.set_size_request(130, -1);
    content.set_margin_top(14);
    content.set_margin_bottom(14);
    content.set_margin_start(10);
    content.set_margin_end(10);

    let icon = gtk::Image::builder()
        .icon_name(&app.icon)
        .pixel_size(52)
        .build();

    let name = gtk::Label::builder()
        .label(&app.name)
        .css_classes(["heading"])
        .ellipsize(gtk::pango::EllipsizeMode::End)
        .build();

    let summary = gtk::Label::builder()
        .label(&app.summary)
        .css_classes(["caption", "dim-label"])
        .ellipsize(gtk::pango::EllipsizeMode::End)
        .lines(1)
        .build();

    // Source badge with styling
    let badge_box = gtk::Box::new(gtk::Orientation::Horizontal, 0);
    badge_box.set_halign(gtk::Align::Center);
    badge_box.set_margin_top(6);

    let source_label = match app.source {
        AppSource::Flatpak => "Flatpak",
        AppSource::System => "System",
    };

    let badge = gtk::Label::builder()
        .label(source_label)
        .css_classes(["source-badge"])
        .build();

    badge_box.append(&badge);

    content.append(&icon);
    content.append(&name);
    content.append(&summary);
    content.append(&badge_box);

    gtk::Button::builder()
        .child(&content)
        .css_classes(["flat", "card"])
        .build()
}

pub fn create_installed_row(app: &AppInfo) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(&app.name)
        .activatable(true)
        .build();

    // Subtitle with source and version
    let source_text = match app.source {
        AppSource::Flatpak => "Flatpak",
        AppSource::System => "System",
    };
    row.set_subtitle(&format!("{} • v{}", source_text, app.version));

    // App icon
    let icon = gtk::Image::builder()
        .icon_name(&app.icon)
        .pixel_size(44)
        .build();
    row.add_prefix(&icon);

    // Action buttons
    let btn_box = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    btn_box.set_valign(gtk::Align::Center);

    let open_btn = gtk::Button::builder()
        .label("Open")
        .css_classes(["flat"])
        .build();

    let uninstall_btn = gtk::Button::builder()
        .icon_name("user-trash-symbolic")
        .css_classes(["flat", "circular"])
        .tooltip_text("Uninstall")
        .build();

    let app_clone = app.clone();
    uninstall_btn.connect_clicked(move |btn| {
        btn.set_sensitive(false);
        let _ = crate::backend::uninstall_app(&app_clone);
    });

    btn_box.append(&open_btn);
    btn_box.append(&uninstall_btn);

    row.add_suffix(&btn_box);

    row
}

pub fn create_update_row(app: &AppInfo) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(&app.name)
        .subtitle("Update available")
        .build();

    let icon = gtk::Image::builder()
        .icon_name(&app.icon)
        .pixel_size(44)
        .build();
    row.add_prefix(&icon);

    // Update badge
    let badge = gtk::Label::builder()
        .label("NEW")
        .css_classes(["update-badge"])
        .valign(gtk::Align::Center)
        .build();

    let update_btn = gtk::Button::builder()
        .label("Update")
        .css_classes(["suggested-action"])
        .valign(gtk::Align::Center)
        .build();

    row.add_suffix(&badge);
    row.add_suffix(&update_btn);

    row
}
