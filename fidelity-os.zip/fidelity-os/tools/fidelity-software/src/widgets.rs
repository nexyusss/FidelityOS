// UI widgets for Software Center

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

use crate::backend::{AppInfo, AppSource};

pub fn create_featured_banner() -> gtk::Box {
    let banner = gtk::Box::new(gtk::Orientation::Horizontal, 24);
    banner.add_css_class("featured-banner");
    banner.set_size_request(-1, 200);

    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 8);
    text_box.set_valign(gtk::Align::Center);
    text_box.set_hexpand(true);

    let title = gtk::Label::builder()
        .label("Discover Great Software")
        .css_classes(["title-1"])
        .halign(gtk::Align::Start)
        .build();

    let subtitle = gtk::Label::builder()
        .label("Thousands of apps from Flathub and Debian")
        .css_classes(["subtitle"])
        .halign(gtk::Align::Start)
        .build();

    text_box.append(&title);
    text_box.append(&subtitle);

    let icon = gtk::Image::builder()
        .icon_name("system-software-install-symbolic")
        .pixel_size(96)
        .css_classes(["featured-icon"])
        .build();

    banner.append(&text_box);
    banner.append(&icon);

    banner
}

pub fn create_categories_grid() -> gtk::FlowBox {
    let flow = gtk::FlowBox::builder()
        .max_children_per_line(4)
        .min_children_per_line(2)
        .selection_mode(gtk::SelectionMode::None)
        .row_spacing(12)
        .column_spacing(12)
        .homogeneous(true)
        .build();

    let categories = [
        ("applications-internet-symbolic", "Internet"),
        ("applications-multimedia-symbolic", "Multimedia"),
        ("applications-office-symbolic", "Office"),
        ("applications-graphics-symbolic", "Graphics"),
        ("applications-games-symbolic", "Games"),
        ("applications-utilities-symbolic", "Utilities"),
        ("applications-development-symbolic", "Development"),
        ("applications-science-symbolic", "Science"),
    ];

    for (icon, name) in categories {
        let card = create_category_card(icon, name);
        flow.append(&card);
    }

    flow
}

fn create_category_card(icon: &str, name: &str) -> gtk::Button {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 8);
    content.set_valign(gtk::Align::Center);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(48)
        .build();

    let label = gtk::Label::new(Some(name));

    content.append(&icon_widget);
    content.append(&label);

    let btn = gtk::Button::builder()
        .child(&content)
        .css_classes(["category-card"])
        .build();

    btn.set_size_request(150, 100);
    btn
}

pub fn create_app_carousel(apps: &[AppInfo]) -> gtk::Box {
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    container.add_css_class("app-carousel");

    for app in apps {
        let card = create_app_card(app);
        container.append(&card);
    }

    container
}

pub fn create_app_card(app: &AppInfo) -> gtk::Button {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 8);
    content.set_size_request(140, -1);

    let icon = gtk::Image::builder()
        .icon_name(&app.icon)
        .pixel_size(64)
        .build();

    let name = gtk::Label::builder()
        .label(&app.name)
        .css_classes(["app-card-name"])
        .ellipsize(gtk::pango::EllipsizeMode::End)
        .build();

    let summary = gtk::Label::builder()
        .label(&app.summary)
        .css_classes(["caption", "dim-label"])
        .ellipsize(gtk::pango::EllipsizeMode::End)
        .lines(2)
        .wrap(true)
        .build();

    let source_label = match app.source {
        AppSource::Flatpak => "Flatpak",
        AppSource::System => "System",
    };

    let badge = gtk::Label::builder()
        .label(source_label)
        .css_classes(["source-badge"])
        .build();

    content.append(&icon);
    content.append(&name);
    content.append(&summary);
    content.append(&badge);

    let btn = gtk::Button::builder()
        .child(&content)
        .css_classes(["app-card"])
        .build();

    btn
}

pub fn create_installed_row(app: &AppInfo) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(&app.name)
        .subtitle(&format!("{} • {}", match app.source {
            AppSource::Flatpak => "Flatpak",
            AppSource::System => "System",
        }, app.version))
        .activatable(true)
        .build();

    let icon = gtk::Image::builder()
        .icon_name(&app.icon)
        .pixel_size(48)
        .build();
    row.add_prefix(&icon);

    // Uninstall button
    let uninstall_btn = gtk::Button::builder()
        .icon_name("user-trash-symbolic")
        .css_classes(["flat", "circular"])
        .valign(gtk::Align::Center)
        .tooltip_text("Uninstall")
        .build();

    let app_clone = app.clone();
    uninstall_btn.connect_clicked(move |btn| {
        btn.set_sensitive(false);
        let _ = crate::backend::uninstall_app(&app_clone);
    });

    row.add_suffix(&uninstall_btn);
    row.add_suffix(&gtk::Image::from_icon_name("go-next-symbolic"));

    row
}

pub fn create_update_row(app: &AppInfo) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(&app.name)
        .subtitle("Update available")
        .build();

    let icon = gtk::Image::builder()
        .icon_name(&app.icon)
        .pixel_size(48)
        .build();
    row.add_prefix(&icon);

    let update_btn = gtk::Button::builder()
        .label("Update")
        .css_classes(["suggested-action"])
        .valign(gtk::Align::Center)
        .build();

    row.add_suffix(&update_btn);

    row
}

pub fn create_search_result_row(app: &AppInfo) -> adw::ActionRow {
    let row = adw::ActionRow::builder()
        .title(&app.name)
        .subtitle(&app.summary)
        .activatable(true)
        .build();

    let icon = gtk::Image::builder()
        .icon_name(&app.icon)
        .pixel_size(48)
        .build();
    row.add_prefix(&icon);

    let action_btn = if app.installed {
        gtk::Button::builder()
            .label("Open")
            .css_classes(["flat"])
            .valign(gtk::Align::Center)
            .build()
    } else {
        gtk::Button::builder()
            .label("Install")
            .css_classes(["suggested-action"])
            .valign(gtk::Align::Center)
            .build()
    };

    let app_clone = app.clone();
    action_btn.connect_clicked(move |btn| {
        if !app_clone.installed {
            btn.set_label("Installing...");
            btn.set_sensitive(false);
            let _ = crate::backend::install_app(&app_clone);
        }
    });

    row.add_suffix(&action_btn);

    row
}
