// Main software center window - Fixed layout with proper content loading

use gtk4 as gtk;
use libadwaita as adw;
use glib;
use gtk::prelude::*;
use adw::prelude::*;

use crate::backend::{self, AppInfo, AppSource};
use crate::widgets;

pub fn build_window(app: &adw::Application) -> adw::ApplicationWindow {
    let window = adw::ApplicationWindow::builder()
        .application(app)
        .title("Software")
        .default_width(1000)
        .default_height(700)
        .build();

    let main_box = gtk::Box::new(gtk::Orientation::Vertical, 0);

    // Header bar with search
    let header = adw::HeaderBar::new();
    
    let search_btn = gtk::ToggleButton::builder()
        .icon_name("system-search-symbolic")
        .build();

    let menu_btn = gtk::MenuButton::builder()
        .icon_name("open-menu-symbolic")
        .build();

    header.pack_start(&search_btn);
    header.pack_end(&menu_btn);

    // Search bar
    let search_bar = gtk::SearchBar::builder()
        .show_close_button(true)
        .build();

    let search_entry = gtk::SearchEntry::builder()
        .placeholder_text("Search applications...")
        .hexpand(true)
        .build();

    search_bar.set_child(Some(&search_entry));
    search_bar.connect_entry(&search_entry);

    search_btn.bind_property("active", &search_bar, "search-mode-enabled")
        .bidirectional()
        .build();

    // Navigation using ViewStack
    let view_stack = adw::ViewStack::new();
    view_stack.set_vexpand(true);

    // Create pages
    let explore_page = create_explore_page();
    let installed_page = create_installed_page();
    let updates_page = create_updates_page();

    view_stack.add_titled_with_icon(&explore_page, Some("explore"), "Explore", "view-grid-symbolic");
    view_stack.add_titled_with_icon(&installed_page, Some("installed"), "Installed", "view-list-symbolic");
    view_stack.add_titled_with_icon(&updates_page, Some("updates"), "Updates", "software-update-available-symbolic");

    // View switcher in header
    let view_switcher = adw::ViewSwitcher::builder()
        .stack(&view_stack)
        .policy(adw::ViewSwitcherPolicy::Wide)
        .build();

    header.set_title_widget(Some(&view_switcher));

    main_box.append(&header);
    main_box.append(&search_bar);
    main_box.append(&view_stack);

    window.set_content(Some(&main_box));
    window
}

fn create_explore_page() -> gtk::ScrolledWindow {
    let scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vexpand(true)
        .build();

    let content = gtk::Box::new(gtk::Orientation::Vertical, 20);
    content.set_margin_start(24);
    content.set_margin_end(24);
    content.set_margin_top(20);
    content.set_margin_bottom(24);

    // Featured banner
    let featured = widgets::create_featured_banner();
    content.append(&featured);

    // Categories section
    let categories_label = gtk::Label::builder()
        .label("Categories")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .margin_top(16)
        .build();

    let categories = widgets::create_categories_grid();
    content.append(&categories_label);
    content.append(&categories);

    // Editor's Picks
    let picks_label = gtk::Label::builder()
        .label("Editor's Picks")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .margin_top(20)
        .build();

    let picks = widgets::create_app_row(&get_editor_picks());
    content.append(&picks_label);
    content.append(&picks);

    // Popular Apps
    let popular_label = gtk::Label::builder()
        .label("Popular Apps")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .margin_top(20)
        .build();

    let popular = widgets::create_app_row(&get_popular_apps());
    content.append(&popular_label);
    content.append(&popular);

    scroll.set_child(Some(&content));
    scroll
}

fn create_installed_page() -> gtk::ScrolledWindow {
    let scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vexpand(true)
        .build();

    let content = gtk::Box::new(gtk::Orientation::Vertical, 12);
    content.set_margin_start(24);
    content.set_margin_end(24);
    content.set_margin_top(20);
    content.set_margin_bottom(24);

    let header = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    
    let title = gtk::Label::builder()
        .label("Installed Applications")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .hexpand(true)
        .build();

    let filter = gtk::DropDown::from_strings(&["All", "Flatpak", "System"]);
    
    header.append(&title);
    header.append(&filter);
    content.append(&header);

    // List of installed apps
    let list = gtk::ListBox::builder()
        .selection_mode(gtk::SelectionMode::None)
        .css_classes(["boxed-list"])
        .margin_top(12)
        .build();

    let installed = backend::get_installed_apps();
    
    if installed.is_empty() {
        // Show placeholder if no apps
        let placeholder = adw::StatusPage::builder()
            .icon_name("package-x-generic-symbolic")
            .title("No Applications Found")
            .description("Install apps from the Explore tab")
            .build();
        content.append(&placeholder);
    } else {
        for app in installed {
            let row = widgets::create_installed_row(&app);
            list.append(&row);
        }
        content.append(&list);
    }

    scroll.set_child(Some(&content));
    scroll
}

fn create_updates_page() -> gtk::ScrolledWindow {
    let scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .vexpand(true)
        .build();

    let content = gtk::Box::new(gtk::Orientation::Vertical, 12);
    content.set_margin_start(24);
    content.set_margin_end(24);
    content.set_margin_top(20);
    content.set_margin_bottom(24);

    let header = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    
    let title = gtk::Label::builder()
        .label("Updates")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .hexpand(true)
        .build();

    let update_all_btn = gtk::Button::builder()
        .label("Update All")
        .css_classes(["suggested-action"])
        .build();

    update_all_btn.connect_clicked(|btn| {
        btn.set_label("Updating...");
        btn.set_sensitive(false);
        backend::update_all();
    });

    header.append(&title);
    header.append(&update_all_btn);
    content.append(&header);

    // Status page for updates
    let status = adw::StatusPage::builder()
        .icon_name("emblem-ok-symbolic")
        .title("System Up to Date")
        .description("All applications are up to date")
        .vexpand(true)
        .build();

    content.append(&status);

    scroll.set_child(Some(&content));
    scroll
}

fn get_editor_picks() -> Vec<AppInfo> {
    vec![
        AppInfo {
            id: "org.mozilla.firefox".to_string(),
            name: "Firefox".to_string(),
            summary: "Fast, private web browser".to_string(),
            icon: "firefox-esr".to_string(),
            source: AppSource::System,
            installed: true,
            version: "121.0".to_string(),
        },
        AppInfo {
            id: "org.libreoffice.LibreOffice".to_string(),
            name: "LibreOffice".to_string(),
            summary: "Powerful office suite".to_string(),
            icon: "libreoffice-startcenter".to_string(),
            source: AppSource::System,
            installed: true,
            version: "7.6".to_string(),
        },
        AppInfo {
            id: "org.gnome.Nautilus".to_string(),
            name: "Files".to_string(),
            summary: "Access and organize files".to_string(),
            icon: "org.gnome.Nautilus".to_string(),
            source: AppSource::System,
            installed: true,
            version: "45.0".to_string(),
        },
        AppInfo {
            id: "org.keepassxc.KeePassXC".to_string(),
            name: "KeePassXC".to_string(),
            summary: "Password manager".to_string(),
            icon: "keepassxc".to_string(),
            source: AppSource::System,
            installed: true,
            version: "2.7".to_string(),
        },
    ]
}

fn get_popular_apps() -> Vec<AppInfo> {
    vec![
        AppInfo {
            id: "com.spotify.Client".to_string(),
            name: "Spotify".to_string(),
            summary: "Music streaming".to_string(),
            icon: "com.spotify.Client".to_string(),
            source: AppSource::Flatpak,
            installed: false,
            version: "1.2.0".to_string(),
        },
        AppInfo {
            id: "com.discordapp.Discord".to_string(),
            name: "Discord".to_string(),
            summary: "Voice and text chat".to_string(),
            icon: "com.discordapp.Discord".to_string(),
            source: AppSource::Flatpak,
            installed: false,
            version: "0.0.35".to_string(),
        },
        AppInfo {
            id: "com.visualstudio.code".to_string(),
            name: "VS Code".to_string(),
            summary: "Code editor".to_string(),
            icon: "com.visualstudio.code".to_string(),
            source: AppSource::Flatpak,
            installed: false,
            version: "1.85".to_string(),
        },
        AppInfo {
            id: "org.gimp.GIMP".to_string(),
            name: "GIMP".to_string(),
            summary: "Image editor".to_string(),
            icon: "gimp".to_string(),
            source: AppSource::System,
            installed: true,
            version: "2.10".to_string(),
        },
    ]
}
