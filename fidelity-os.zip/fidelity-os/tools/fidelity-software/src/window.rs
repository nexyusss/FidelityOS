// Main software center window

use gtk4 as gtk;
use libadwaita as adw;
use glib;
use gtk::prelude::*;
use adw::prelude::*;

use crate::backend::{self, AppInfo, AppSource};
use crate::widgets;

pub fn build_window(app: &adw::Application) -> adw::ApplicationWindow {
    let window = adw::ApplicationWindow::builder()
        .application(app)
        .title("Software")
        .default_width(1100)
        .default_height(750)
        .build();

    let main_box = gtk::Box::new(gtk::Orientation::Vertical, 0);

    // Header bar with search
    let header = adw::HeaderBar::new();
    
    let search_btn = gtk::ToggleButton::builder()
        .icon_name("system-search-symbolic")
        .build();

    let menu_btn = gtk::MenuButton::builder()
        .icon_name("open-menu-symbolic")
        .build();

    header.pack_start(&search_btn);
    header.pack_end(&menu_btn);

    // Search bar
    let search_bar = gtk::SearchBar::builder()
        .show_close_button(true)
        .build();

    let search_entry = gtk::SearchEntry::builder()
        .placeholder_text("Search applications...")
        .hexpand(true)
        .build();

    search_bar.set_child(Some(&search_entry));
    search_bar.connect_entry(&search_entry);

    search_btn.bind_property("active", &search_bar, "search-mode-enabled")
        .bidirectional()
        .build();

    // Navigation view using ViewStack for ViewSwitcher compatibility
    let view_stack = adw::ViewStack::new();

    // Create pages
    let explore_page = create_explore_page();
    let installed_page = create_installed_page();
    let updates_page = create_updates_page();

    view_stack.add_titled_with_icon(&explore_page, Some("explore"), "Explore", "view-grid-symbolic");
    view_stack.add_titled_with_icon(&installed_page, Some("installed"), "Installed", "view-list-symbolic");
    view_stack.add_titled_with_icon(&updates_page, Some("updates"), "Updates", "software-update-available-symbolic");

    // View switcher
    let view_switcher = adw::ViewSwitcher::builder()
        .stack(&view_stack)
        .policy(adw::ViewSwitcherPolicy::Wide)
        .build();

    header.set_title_widget(Some(&view_switcher));

    // Search functionality
    search_entry.connect_search_changed(move |entry| {
        let query = entry.text().to_string();
        if !query.is_empty() {
            perform_search(&query);
        }
    });

    main_box.append(&header);
    main_box.append(&search_bar);
    main_box.append(&view_stack);

    window.set_content(Some(&main_box));
    window
}

fn create_explore_page() -> gtk::ScrolledWindow {
    let scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .build();

    let content = gtk::Box::new(gtk::Orientation::Vertical, 24);
    content.set_margin_start(32);
    content.set_margin_end(32);
    content.set_margin_top(24);
    content.set_margin_bottom(32);

    // Featured banner
    let featured = widgets::create_featured_banner();
    content.append(&featured);

    // Categories
    let categories_label = gtk::Label::builder()
        .label("Categories")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .build();

    let categories = widgets::create_categories_grid();
    content.append(&categories_label);
    content.append(&categories);

    // Editor's Picks
    let picks_label = gtk::Label::builder()
        .label("Editor's Picks")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .margin_top(24)
        .build();

    let picks = widgets::create_app_carousel(&get_editor_picks());
    content.append(&picks_label);
    content.append(&picks);

    // Recently Updated
    let recent_label = gtk::Label::builder()
        .label("Recently Updated")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .margin_top(24)
        .build();

    let recent = widgets::create_app_carousel(&get_recent_apps());
    content.append(&recent_label);
    content.append(&recent);

    scroll.set_child(Some(&content));
    scroll
}

fn create_installed_page() -> gtk::ScrolledWindow {
    let scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .build();

    let content = gtk::Box::new(gtk::Orientation::Vertical, 16);
    content.set_margin_start(32);
    content.set_margin_end(32);
    content.set_margin_top(24);
    content.set_margin_bottom(32);

    let header = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    
    let title = gtk::Label::builder()
        .label("Installed Applications")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .hexpand(true)
        .build();

    let filter = gtk::DropDown::from_strings(&["All", "Flatpak", "System"]);
    
    header.append(&title);
    header.append(&filter);
    content.append(&header);

    // List of installed apps
    let list = gtk::ListBox::builder()
        .selection_mode(gtk::SelectionMode::None)
        .css_classes(["boxed-list"])
        .build();

    let installed = backend::get_installed_apps();
    for app in installed {
        let row = widgets::create_installed_row(&app);
        list.append(&row);
    }

    content.append(&list);
    scroll.set_child(Some(&content));
    scroll
}

fn create_updates_page() -> gtk::ScrolledWindow {
    let scroll = gtk::ScrolledWindow::builder()
        .hscrollbar_policy(gtk::PolicyType::Never)
        .build();

    let content = gtk::Box::new(gtk::Orientation::Vertical, 16);
    content.set_margin_start(32);
    content.set_margin_end(32);
    content.set_margin_top(24);
    content.set_margin_bottom(32);

    let header = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    
    let title = gtk::Label::builder()
        .label("Updates")
        .css_classes(["title-2"])
        .halign(gtk::Align::Start)
        .hexpand(true)
        .build();

    let update_all_btn = gtk::Button::builder()
        .label("Update All")
        .css_classes(["suggested-action"])
        .build();

    update_all_btn.connect_clicked(|_| {
        backend::update_all();
    });

    header.append(&title);
    header.append(&update_all_btn);
    content.append(&header);

    // Check for updates status
    let status = gtk::Label::builder()
        .label("Checking for updates...")
        .css_classes(["dim-label"])
        .margin_top(48)
        .margin_bottom(48)
        .build();

    content.append(&status);

    // Spawn update check
    glib::spawn_future_local(async move {
        // Updates would be fetched here
    });

    scroll.set_child(Some(&content));
    scroll
}

fn perform_search(query: &str) {
    // Search implementation
    let _results = backend::search_apps(query);
}

fn get_editor_picks() -> Vec<AppInfo> {
    vec![
        AppInfo {
            id: "org.mozilla.firefox".to_string(),
            name: "Firefox".to_string(),
            summary: "Fast, private web browser".to_string(),
            icon: "firefox".to_string(),
            source: AppSource::System,
            installed: true,
            version: "121.0".to_string(),
        },
        AppInfo {
            id: "org.libreoffice.LibreOffice".to_string(),
            name: "LibreOffice".to_string(),
            summary: "Powerful office suite".to_string(),
            icon: "libreoffice-startcenter".to_string(),
            source: AppSource::System,
            installed: true,
            version: "7.6".to_string(),
        },
        AppInfo {
            id: "com.spotify.Client".to_string(),
            name: "Spotify".to_string(),
            summary: "Music streaming".to_string(),
            icon: "com.spotify.Client".to_string(),
            source: AppSource::Flatpak,
            installed: false,
            version: "1.2.0".to_string(),
        },
    ]
}

fn get_recent_apps() -> Vec<AppInfo> {
    vec![
        AppInfo {
            id: "org.gnome.Calculator".to_string(),
            name: "Calculator".to_string(),
            summary: "Perform calculations".to_string(),
            icon: "org.gnome.Calculator".to_string(),
            source: AppSource::System,
            installed: true,
            version: "45.0".to_string(),
        },
    ]
}
