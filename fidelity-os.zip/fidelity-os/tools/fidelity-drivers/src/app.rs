use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

use crate::window::FidelityDriversWindow;
use crate::style;

pub struct FidelityDriversApp {
    app: adw::Application,
}

impl FidelityDriversApp {
    pub fn new() -> Self {
        let app = adw::Application::builder()
            .application_id("org.fidelityos.drivers")
            .build();

        app.connect_startup(|_| {
            style::load_css();
        });

        app.connect_activate(|app| {
            let window = FidelityDriversWindow::new(app);
            window.present();
        });

        Self { app }
    }

    pub fn run(&self) -> glib::ExitCode {
        self.app.run()
    }
}
