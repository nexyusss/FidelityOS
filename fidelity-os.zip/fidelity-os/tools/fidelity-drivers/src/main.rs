// FidelityOS Driver Manager
// GTK4 + libadwaita GUI for installing proprietary drivers

mod app;
mod window;
mod drivers;
mod style;

use gtk4 as gtk;
use gtk::prelude::*;

fn main() -> glib::ExitCode {
    let app = app::FidelityDriversApp::new();
    app.run()
}
