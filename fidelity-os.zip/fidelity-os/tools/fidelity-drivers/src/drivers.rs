// Driver detection and installation backend

use std::process::Command;

#[derive(Clone, Debug)]
pub struct Driver {
    pub id: String,
    pub name: String,
    pub vendor: String,
    pub version: String,
    pub description: String,
    pub status: DriverStatus,
    pub recommended: bool,
    pub packages: Vec<String>,
    pub icon: String,
}

#[derive(Clone, Debug, PartialEq)]
pub enum DriverStatus {
    Installed,
    Available,
    NotAvailable,
}

impl Driver {
    pub fn status_text(&self) -> &str {
        match self.status {
            DriverStatus::Installed => "Installed",
            DriverStatus::Available => "Available",
            DriverStatus::NotAvailable => "Not Available",
        }
    }
    
    pub fn status_class(&self) -> &str {
        match self.status {
            DriverStatus::Installed => "driver-status-installed",
            DriverStatus::Available => "driver-status-available",
            DriverStatus::NotAvailable => "driver-status-available",
        }
    }
}

pub fn detect_hardware() -> Vec<Driver> {
    let mut drivers = Vec::new();
    
    // Detect NVIDIA GPU
    if let Some(nvidia) = detect_nvidia() {
        drivers.push(nvidia);
    }
    
    // Detect AMD GPU
    if let Some(amd) = detect_amd() {
        drivers.push(amd);
    }
    
    // Detect Intel GPU
    if let Some(intel) = detect_intel() {
        drivers.push(intel);
    }
    
    // Detect Broadcom WiFi
    if let Some(broadcom) = detect_broadcom_wifi() {
        drivers.push(broadcom);
    }
    
    // Detect Realtek WiFi
    if let Some(realtek) = detect_realtek_wifi() {
        drivers.push(realtek);
    }
    
    // Detect Intel WiFi
    if let Some(intel_wifi) = detect_intel_wifi() {
        drivers.push(intel_wifi);
    }
    
    drivers
}

fn detect_nvidia() -> Option<Driver> {
    let output = Command::new("lspci")
        .args(["-nn"])
        .output()
        .ok()?;
    
    let lspci = String::from_utf8_lossy(&output.stdout);
    
    if lspci.contains("NVIDIA") || lspci.contains("[10de:") {
        // Check if proprietary driver is installed
        let nvidia_installed = Command::new("dpkg")
            .args(["-l", "nvidia-driver"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        
        // Detect GPU model for version recommendation
        let (version, recommended) = if lspci.contains("RTX 40") || lspci.contains("RTX 30") {
            ("535", true)
        } else if lspci.contains("RTX 20") || lspci.contains("GTX 16") {
            ("535", true)
        } else if lspci.contains("GTX 10") || lspci.contains("GTX 9") {
            ("470", true)
        } else {
            ("390", false)
        };
        
        Some(Driver {
            id: "nvidia".to_string(),
            name: "NVIDIA Proprietary Driver".to_string(),
            vendor: "NVIDIA Corporation".to_string(),
            version: version.to_string(),
            description: "High-performance proprietary driver for NVIDIA GPUs. Provides better gaming performance, CUDA support, and hardware video encoding.".to_string(),
            status: if nvidia_installed { DriverStatus::Installed } else { DriverStatus::Available },
            recommended,
            packages: vec![
                format!("nvidia-driver-{}", version),
                "nvidia-settings".to_string(),
                "nvidia-cuda-toolkit".to_string(),
            ],
            icon: "video-display-symbolic".to_string(),
        })
    } else {
        None
    }
}

fn detect_amd() -> Option<Driver> {
    let output = Command::new("lspci")
        .args(["-nn"])
        .output()
        .ok()?;
    
    let lspci = String::from_utf8_lossy(&output.stdout);
    
    if lspci.contains("AMD") && (lspci.contains("VGA") || lspci.contains("Display")) {
        // AMD uses open-source amdgpu driver by default, but firmware may be needed
        let firmware_installed = Command::new("dpkg")
            .args(["-l", "firmware-amd-graphics"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        
        Some(Driver {
            id: "amd".to_string(),
            name: "AMD GPU Firmware".to_string(),
            vendor: "Advanced Micro Devices".to_string(),
            version: "latest".to_string(),
            description: "Firmware for AMD Radeon GPUs. The open-source amdgpu driver is used by default, but this firmware enables full hardware features.".to_string(),
            status: if firmware_installed { DriverStatus::Installed } else { DriverStatus::Available },
            recommended: true,
            packages: vec![
                "firmware-amd-graphics".to_string(),
                "libdrm-amdgpu1".to_string(),
                "mesa-vulkan-drivers".to_string(),
            ],
            icon: "video-display-symbolic".to_string(),
        })
    } else {
        None
    }
}

fn detect_intel() -> Option<Driver> {
    let output = Command::new("lspci")
        .args(["-nn"])
        .output()
        .ok()?;
    
    let lspci = String::from_utf8_lossy(&output.stdout);
    
    if lspci.contains("Intel") && lspci.contains("VGA") {
        let firmware_installed = Command::new("dpkg")
            .args(["-l", "intel-media-va-driver"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        
        Some(Driver {
            id: "intel-gpu".to_string(),
            name: "Intel Graphics".to_string(),
            vendor: "Intel Corporation".to_string(),
            version: "latest".to_string(),
            description: "Intel integrated graphics drivers and hardware video acceleration support.".to_string(),
            status: if firmware_installed { DriverStatus::Installed } else { DriverStatus::Available },
            recommended: true,
            packages: vec![
                "intel-media-va-driver".to_string(),
                "intel-gpu-tools".to_string(),
            ],
            icon: "video-display-symbolic".to_string(),
        })
    } else {
        None
    }
}

fn detect_broadcom_wifi() -> Option<Driver> {
    let output = Command::new("lspci")
        .args(["-nn"])
        .output()
        .ok()?;
    
    let lspci = String::from_utf8_lossy(&output.stdout);
    
    if lspci.contains("Broadcom") && lspci.contains("Network") {
        let driver_installed = Command::new("dpkg")
            .args(["-l", "broadcom-sta-dkms"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        
        Some(Driver {
            id: "broadcom-wifi".to_string(),
            name: "Broadcom WiFi Driver".to_string(),
            vendor: "Broadcom Inc.".to_string(),
            version: "latest".to_string(),
            description: "Proprietary wireless driver for Broadcom WiFi adapters. Required for many MacBook and Dell laptops.".to_string(),
            status: if driver_installed { DriverStatus::Installed } else { DriverStatus::Available },
            recommended: true,
            packages: vec![
                "broadcom-sta-dkms".to_string(),
            ],
            icon: "network-wireless-symbolic".to_string(),
        })
    } else {
        None
    }
}

fn detect_realtek_wifi() -> Option<Driver> {
    let output = Command::new("lspci")
        .args(["-nn"])
        .output()
        .ok()?;
    
    let lspci = String::from_utf8_lossy(&output.stdout);
    
    // Also check USB devices
    let usb_output = Command::new("lsusb")
        .output()
        .ok();
    
    let has_realtek = lspci.contains("Realtek") && lspci.contains("Network")
        || usb_output.map(|o| String::from_utf8_lossy(&o.stdout).contains("Realtek")).unwrap_or(false);
    
    if has_realtek {
        let firmware_installed = Command::new("dpkg")
            .args(["-l", "firmware-realtek"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        
        Some(Driver {
            id: "realtek-wifi".to_string(),
            name: "Realtek WiFi Firmware".to_string(),
            vendor: "Realtek Semiconductor".to_string(),
            version: "latest".to_string(),
            description: "Firmware for Realtek wireless and ethernet adapters.".to_string(),
            status: if firmware_installed { DriverStatus::Installed } else { DriverStatus::Available },
            recommended: true,
            packages: vec![
                "firmware-realtek".to_string(),
            ],
            icon: "network-wireless-symbolic".to_string(),
        })
    } else {
        None
    }
}

fn detect_intel_wifi() -> Option<Driver> {
    let output = Command::new("lspci")
        .args(["-nn"])
        .output()
        .ok()?;
    
    let lspci = String::from_utf8_lossy(&output.stdout);
    
    if lspci.contains("Intel") && lspci.contains("Wireless") {
        let firmware_installed = Command::new("dpkg")
            .args(["-l", "firmware-iwlwifi"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        
        Some(Driver {
            id: "intel-wifi".to_string(),
            name: "Intel WiFi Firmware".to_string(),
            vendor: "Intel Corporation".to_string(),
            version: "latest".to_string(),
            description: "Firmware for Intel wireless adapters (WiFi 6, AX200, AX201, etc).".to_string(),
            status: if firmware_installed { DriverStatus::Installed } else { DriverStatus::Available },
            recommended: true,
            packages: vec![
                "firmware-iwlwifi".to_string(),
            ],
            icon: "network-wireless-symbolic".to_string(),
        })
    } else {
        None
    }
}

pub fn install_driver(driver: &Driver) -> Result<(), String> {
    // Add non-free repository if needed
    let _ = Command::new("pkexec")
        .args(["bash", "-c", "apt-add-repository -y non-free non-free-firmware 2>/dev/null || true"])
        .output();
    
    // Update package lists
    let update = Command::new("pkexec")
        .args(["apt-get", "update"])
        .output()
        .map_err(|e| e.to_string())?;
    
    if !update.status.success() {
        return Err("Failed to update package lists".to_string());
    }
    
    // Install packages
    let packages: Vec<&str> = driver.packages.iter().map(|s| s.as_str()).collect();
    let mut args = vec!["apt-get", "install", "-y"];
    args.extend(packages);
    
    let install = Command::new("pkexec")
        .args(&args)
        .output()
        .map_err(|e| e.to_string())?;
    
    if install.status.success() {
        Ok(())
    } else {
        Err(String::from_utf8_lossy(&install.stderr).to_string())
    }
}

pub fn remove_driver(driver: &Driver) -> Result<(), String> {
    let packages: Vec<&str> = driver.packages.iter().map(|s| s.as_str()).collect();
    let mut args = vec!["apt-get", "remove", "-y"];
    args.extend(packages);
    
    let remove = Command::new("pkexec")
        .args(&args)
        .output()
        .map_err(|e| e.to_string())?;
    
    if remove.status.success() {
        Ok(())
    } else {
        Err(String::from_utf8_lossy(&remove.stderr).to_string())
    }
}
