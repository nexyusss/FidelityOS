use gtk4 as gtk;
use gtk::prelude::*;

pub fn load_css() {
    let provider = gtk::CssProvider::new();
    provider.load_from_data(CSS);
    
    gtk::style_context_add_provider_for_display(
        &gtk::gdk::Display::default().expect("Could not get display"),
        &provider,
        gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
}

const CSS: &str = r#"
.driver-card {
    padding: 16px;
    border-radius: 12px;
    background: alpha(@card_bg_color, 0.8);
    margin: 6px;
}

.driver-card:hover {
    background: alpha(@card_bg_color, 1.0);
}

.driver-icon {
    color: @accent_color;
}

.driver-name {
    font-weight: bold;
    font-size: 14px;
}

.driver-version {
    font-size: 12px;
    color: alpha(@window_fg_color, 0.7);
}

.driver-status-installed {
    color: #2ecc71;
    font-weight: bold;
}

.driver-status-available {
    color: @accent_color;
}

.driver-status-recommended {
    color: #f39c12;
    font-weight: bold;
}

.section-title {
    font-weight: bold;
    font-size: 18px;
    margin-bottom: 8px;
}

.section-subtitle {
    color: alpha(@window_fg_color, 0.7);
    margin-bottom: 16px;
}

.warning-banner {
    background: alpha(#f39c12, 0.15);
    border-radius: 8px;
    padding: 12px;
    margin: 8px 0;
}

.success-banner {
    background: alpha(#2ecc71, 0.15);
    border-radius: 8px;
    padding: 12px;
    margin: 8px 0;
}
"#;
