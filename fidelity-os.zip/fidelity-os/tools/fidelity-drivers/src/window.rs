use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;
use std::cell::RefCell;
use std::rc::Rc;

use crate::drivers::{self, Driver, DriverStatus};

pub struct FidelityDriversWindow {
    pub window: adw::ApplicationWindow,
}

impl FidelityDriversWindow {
    pub fn new(app: &adw::Application) -> Self {
        let window = adw::ApplicationWindow::builder()
            .application(app)
            .title("Driver Manager")
            .default_width(700)
            .default_height(550)
            .build();

        let content = Self::build_content();
        window.set_content(Some(&content));

        Self { window }
    }

    pub fn present(&self) {
        self.window.present();
    }

    fn build_content() -> gtk::Widget {
        let main_box = gtk::Box::new(gtk::Orientation::Vertical, 0);

        // Header bar
        let header = adw::HeaderBar::new();
        let title = adw::WindowTitle::new("Driver Manager", "Install proprietary drivers");
        header.set_title_widget(Some(&title));

        // Refresh button
        let refresh_btn = gtk::Button::from_icon_name("view-refresh-symbolic");
        refresh_btn.set_tooltip_text(Some("Scan for hardware"));
        header.pack_end(&refresh_btn);

        main_box.append(&header);

        // Scrolled content
        let scrolled = gtk::ScrolledWindow::builder()
            .vexpand(true)
            .hscrollbar_policy(gtk::PolicyType::Never)
            .build();

        let content_box = gtk::Box::new(gtk::Orientation::Vertical, 16);
        content_box.set_margin_start(24);
        content_box.set_margin_end(24);
        content_box.set_margin_top(16);
        content_box.set_margin_bottom(24);

        // Info banner
        let info_box = gtk::Box::new(gtk::Orientation::Horizontal, 12);
        info_box.add_css_class("warning-banner");
        
        let info_icon = gtk::Image::from_icon_name("dialog-information-symbolic");
        let info_label = gtk::Label::new(Some(
            "Proprietary drivers may improve hardware support but are not open source. A reboot is required after installation."
        ));
        info_label.set_wrap(true);
        info_label.set_xalign(0.0);
        info_label.set_hexpand(true);
        
        info_box.append(&info_icon);
        info_box.append(&info_label);
        content_box.append(&info_box);

        // Driver list container
        let driver_list = gtk::Box::new(gtk::Orientation::Vertical, 8);
        let driver_list_rc = Rc::new(RefCell::new(driver_list.clone()));

        // Initial scan
        Self::populate_drivers(&driver_list);

        content_box.append(&driver_list);
        scrolled.set_child(Some(&content_box));
        main_box.append(&scrolled);

        // Refresh button action
        let driver_list_clone = driver_list_rc.clone();
        refresh_btn.connect_clicked(move |_| {
            let list = driver_list_clone.borrow();
            // Clear existing
            while let Some(child) = list.first_child() {
                list.remove(&child);
            }
            Self::populate_drivers(&list);
        });

        main_box.upcast()
    }

    fn populate_drivers(container: &gtk::Box) {
        let drivers = drivers::detect_hardware();

        if drivers.is_empty() {
            let empty_box = gtk::Box::new(gtk::Orientation::Vertical, 16);
            empty_box.set_valign(gtk::Align::Center);
            empty_box.set_vexpand(true);

            let icon = gtk::Image::from_icon_name("emblem-ok-symbolic");
            icon.set_pixel_size(64);
            icon.set_opacity(0.5);

            let label = gtk::Label::new(Some("All hardware is using open-source drivers"));
            label.add_css_class("dim-label");

            let sublabel = gtk::Label::new(Some("No proprietary drivers needed"));
            sublabel.add_css_class("dim-label");
            sublabel.add_css_class("caption");

            empty_box.append(&icon);
            empty_box.append(&label);
            empty_box.append(&sublabel);
            container.append(&empty_box);
            return;
        }

        // Section title
        let title = gtk::Label::new(Some("Available Drivers"));
        title.add_css_class("section-title");
        title.set_halign(gtk::Align::Start);
        container.append(&title);

        let subtitle = gtk::Label::new(Some("Hardware detected on your system"));
        subtitle.add_css_class("section-subtitle");
        subtitle.set_halign(gtk::Align::Start);
        container.append(&subtitle);

        // Driver cards
        for driver in drivers {
            let card = Self::create_driver_card(&driver);
            container.append(&card);
        }
    }

    fn create_driver_card(driver: &Driver) -> gtk::Box {
        let card = gtk::Box::new(gtk::Orientation::Horizontal, 16);
        card.add_css_class("driver-card");

        // Icon
        let icon = gtk::Image::from_icon_name(&driver.icon);
        icon.set_pixel_size(48);
        icon.add_css_class("driver-icon");

        // Info
        let info_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
        info_box.set_hexpand(true);

        let name_box = gtk::Box::new(gtk::Orientation::Horizontal, 8);
        let name = gtk::Label::new(Some(&driver.name));
        name.add_css_class("driver-name");
        name.set_halign(gtk::Align::Start);
        name_box.append(&name);

        if driver.recommended {
            let badge = gtk::Label::new(Some("Recommended"));
            badge.add_css_class("driver-status-recommended");
            badge.add_css_class("caption");
            name_box.append(&badge);
        }

        let vendor = gtk::Label::new(Some(&format!("{} • Version {}", driver.vendor, driver.version)));
        vendor.add_css_class("driver-version");
        vendor.set_halign(gtk::Align::Start);

        let desc = gtk::Label::new(Some(&driver.description));
        desc.set_wrap(true);
        desc.set_xalign(0.0);
        desc.set_margin_top(4);
        desc.add_css_class("dim-label");
        desc.add_css_class("caption");

        let status = gtk::Label::new(Some(driver.status_text()));
        status.add_css_class(driver.status_class());
        status.set_halign(gtk::Align::Start);
        status.set_margin_top(4);

        info_box.append(&name_box);
        info_box.append(&vendor);
        info_box.append(&desc);
        info_box.append(&status);

        // Action button
        let action_box = gtk::Box::new(gtk::Orientation::Vertical, 8);
        action_box.set_valign(gtk::Align::Center);

        let driver_clone = driver.clone();
        
        if driver.status == DriverStatus::Installed {
            let remove_btn = gtk::Button::with_label("Remove");
            remove_btn.add_css_class("destructive-action");
            
            remove_btn.connect_clicked(move |btn| {
                btn.set_sensitive(false);
                btn.set_label("Removing...");
                
                match drivers::remove_driver(&driver_clone) {
                    Ok(_) => {
                        btn.set_label("Removed");
                    }
                    Err(e) => {
                        btn.set_label("Failed");
                        eprintln!("Error: {}", e);
                    }
                }
            });
            
            action_box.append(&remove_btn);
        } else if driver.status == DriverStatus::Available {
            let install_btn = gtk::Button::with_label("Install");
            install_btn.add_css_class("suggested-action");
            
            install_btn.connect_clicked(move |btn| {
                btn.set_sensitive(false);
                btn.set_label("Installing...");
                
                match drivers::install_driver(&driver_clone) {
                    Ok(_) => {
                        btn.set_label("Installed ✓");
                    }
                    Err(e) => {
                        btn.set_label("Failed");
                        btn.set_sensitive(true);
                        eprintln!("Error: {}", e);
                    }
                }
            });
            
            action_box.append(&install_btn);
        }

        card.append(&icon);
        card.append(&info_box);
        card.append(&action_box);

        card
    }
}
