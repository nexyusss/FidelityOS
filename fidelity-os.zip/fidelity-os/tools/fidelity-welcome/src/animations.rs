// Animations module - Smooth transitions and effects

use gtk4 as gtk;
use gtk::prelude::*;

/// Animate the initial window entrance
pub fn animate_window_enter(carousel: &libadwaita::Carousel) {
    let first_page = carousel.nth_page(0);
    animate_page_enter(&first_page);
}

/// Animate a page when it becomes visible
pub fn animate_page_enter(widget: &gtk::Widget) {
    // Add animation class that triggers CSS animations
    widget.add_css_class("page-enter");
    
    // Remove after animation completes
    let widget_clone = widget.clone();
    glib::timeout_add_local_once(std::time::Duration::from_millis(600), move || {
        widget_clone.remove_css_class("page-enter");
    });
}

/// Staggered animation for child widgets
pub fn animate_children_staggered(container: &gtk::Box, delay_ms: u32) {
    let mut child = container.first_child();
    let mut index = 0u32;
    
    while let Some(widget) = child {
        let widget_clone = widget.clone();
        let delay = delay_ms * index;
        
        widget.set_opacity(0.0);
        
        glib::timeout_add_local_once(std::time::Duration::from_millis(delay as u64), move || {
            widget_clone.set_opacity(1.0);
            widget_clone.add_css_class("animate-fade-in");
        });
        
        child = widget.next_sibling();
        index += 1;
    }
}

/// Pulse animation for emphasis
pub fn pulse(widget: &gtk::Widget) {
    widget.add_css_class("animate-pulse");
    
    let widget_clone = widget.clone();
    glib::timeout_add_local_once(std::time::Duration::from_millis(1000), move || {
        widget_clone.remove_css_class("animate-pulse");
    });
}

/// Shake animation for errors
pub fn shake(widget: &gtk::Widget) {
    widget.add_css_class("animate-shake");
    
    let widget_clone = widget.clone();
    glib::timeout_add_local_once(std::time::Duration::from_millis(500), move || {
        widget_clone.remove_css_class("animate-shake");
    });
}
