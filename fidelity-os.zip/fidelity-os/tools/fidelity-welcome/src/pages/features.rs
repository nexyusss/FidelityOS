// Features page - Polished 2x3 grid with hover effects

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 16);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("features-page");

    // Header with icon
    let header = gtk::Box::new(gtk::Orientation::Vertical, 8);
    header.set_halign(gtk::Align::Center);

    let header_icon = gtk::Image::builder()
        .icon_name("starred-symbolic")
        .pixel_size(32)
        .opacity(0.6)
        .build();

    let title = gtk::Label::builder()
        .label("Designed for You")
        .build();
    title.add_css_class("title-1");

    let subtitle = gtk::Label::builder()
        .label("Everything you need, nothing you don't")
        .build();
    subtitle.add_css_class("subtitle");

    header.append(&header_icon);
    header.append(&title);
    header.append(&subtitle);

    // Features grid - 2 columns, 3 rows
    let features_grid = gtk::Grid::builder()
        .row_spacing(12)
        .column_spacing(12)
        .halign(gtk::Align::Center)
        .margin_top(24)
        .build();

    let features = [
        ("computer-symbolic", "Modern Desktop", "GNOME with a beautiful custom theme", "#5DADE2"),
        ("preferences-system-performance-symbolic", "Efficient", "Low resource usage, fast boot times", "#2ECC71"),
        ("security-high-symbolic", "Secure", "AppArmor, firewall, and sandboxing", "#9B59B6"),
        ("emblem-synchronizing-symbolic", "Always Updated", "Automatic security patches", "#E67E22"),
        ("system-software-install-symbolic", "Easy Software", "Flatpak + APT unified experience", "#3498DB"),
        ("preferences-desktop-symbolic", "Customizable", "Make it truly yours", "#E74C3C"),
    ];

    for (i, (icon, title_text, desc, _color)) in features.iter().enumerate() {
        let row = (i / 2) as i32;
        let col = (i % 2) as i32;
        let card = create_feature_card(icon, title_text, desc);
        features_grid.attach(&card, col, row, 1, 1);
    }

    container.append(&header);
    container.append(&features_grid);

    Page {
        widget: container,
        title: "Features".to_string(),
    }
}

fn create_feature_card(icon: &str, title: &str, description: &str) -> gtk::Box {
    let card = gtk::Box::new(gtk::Orientation::Horizontal, 14);
    card.add_css_class("feature-card");
    card.set_size_request(310, -1);

    // Icon container with subtle background
    let icon_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    icon_box.set_valign(gtk::Align::Center);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(36)
        .build();
    icon_widget.add_css_class("feature-icon");

    icon_box.append(&icon_widget);

    // Text content
    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 3);
    text_box.set_hexpand(true);
    text_box.set_valign(gtk::Align::Center);
    
    let title_label = gtk::Label::builder()
        .label(title)
        .halign(gtk::Align::Start)
        .build();
    title_label.add_css_class("feature-title");

    let desc_label = gtk::Label::builder()
        .label(description)
        .halign(gtk::Align::Start)
        .wrap(true)
        .max_width_chars(26)
        .build();
    desc_label.add_css_class("feature-desc");

    text_box.append(&title_label);
    text_box.append(&desc_label);

    card.append(&icon_box);
    card.append(&text_box);

    card
}
