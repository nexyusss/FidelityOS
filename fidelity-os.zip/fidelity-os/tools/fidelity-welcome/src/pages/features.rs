// Features page - Showcase what makes FidelityOS special

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 24);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("features-page");

    let title = gtk::Label::builder()
        .label("Designed for You")
        .build();
    title.add_css_class("title-1");

    let subtitle = gtk::Label::builder()
        .label("Everything you need, nothing you don't")
        .build();
    subtitle.add_css_class("subtitle");

    let features_grid = gtk::Grid::builder()
        .row_spacing(16)
        .column_spacing(16)
        .halign(gtk::Align::Center)
        .margin_top(32)
        .build();

    let features = [
        ("computer-symbolic", "Modern Desktop", "GNOME with a beautiful custom theme"),
        ("preferences-system-performance-symbolic", "Efficient", "Low resource usage, fast boot times"),
        ("security-high-symbolic", "Secure", "AppArmor, firewall, and sandboxing"),
        ("emblem-synchronizing-symbolic", "Always Updated", "Automatic security patches"),
        ("system-software-install-symbolic", "Easy Software", "Flatpak + APT unified experience"),
        ("preferences-desktop-symbolic", "Customizable", "Make it truly yours"),
    ];

    for (i, (icon, title_text, desc)) in features.iter().enumerate() {
        let row = (i / 2) as i32;
        let col = (i % 2) as i32;
        
        let card = create_feature_card(icon, title_text, desc);
        features_grid.attach(&card, col, row, 1, 1);
    }

    container.append(&title);
    container.append(&subtitle);
    container.append(&features_grid);

    Page {
        widget: container,
        title: "Features".to_string(),
    }
}

fn create_feature_card(icon: &str, title: &str, description: &str) -> gtk::Box {
    let card = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    card.add_css_class("feature-card");
    card.set_size_request(300, -1);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(48)
        .build();
    icon_widget.add_css_class("feature-icon");

    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
    text_box.set_hexpand(true);
    
    let title_label = gtk::Label::builder()
        .label(title)
        .halign(gtk::Align::Start)
        .build();
    title_label.add_css_class("feature-title");

    let desc_label = gtk::Label::builder()
        .label(description)
        .halign(gtk::Align::Start)
        .wrap(true)
        .max_width_chars(25)
        .build();
    desc_label.add_css_class("feature-desc");
    desc_label.add_css_class("dim-label");

    text_box.append(&title_label);
    text_box.append(&desc_label);

    card.append(&icon_widget);
    card.append(&text_box);

    card
}
