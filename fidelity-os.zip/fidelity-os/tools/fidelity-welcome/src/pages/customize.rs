// Customize page - Theme and appearance options with horizontal layout

use gtk4 as gtk;
use libadwaita as adw;
use gdk4;
use glib;
use gtk::prelude::*;
use adw::prelude::*;
use std::cell::RefCell;
use std::rc::Rc;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 20);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("customize-page");

    // Header
    let header = gtk::Box::new(gtk::Orientation::Vertical, 8);
    header.set_halign(gtk::Align::Center);

    let title = gtk::Label::builder()
        .label("Make It Yours")
        .build();
    title.add_css_class("title-1");

    let subtitle = gtk::Label::builder()
        .label("Personalize your desktop experience")
        .build();
    subtitle.add_css_class("subtitle");

    header.append(&title);
    header.append(&subtitle);

    // Options container - horizontal sections
    let options = gtk::Box::new(gtk::Orientation::Vertical, 24);
    options.set_margin_top(24);

    // Theme selection
    let theme_section = create_theme_section();
    
    // Accent color selection
    let accent_section = create_accent_section();

    // Layout selection
    let layout_section = create_layout_section();

    options.append(&theme_section);
    options.append(&accent_section);
    options.append(&layout_section);

    container.append(&header);
    container.append(&options);

    Page {
        widget: container,
        title: "Customize".to_string(),
    }
}

fn create_theme_section() -> gtk::Box {
    let section = gtk::Box::new(gtk::Orientation::Vertical, 10);

    let label = gtk::Label::builder()
        .label("APPEARANCE")
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .build();

    let theme_box = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    theme_box.set_halign(gtk::Align::Center);

    let themes = [
        ("Dark", "weather-clear-night-symbolic", true),
        ("Light", "weather-clear-symbolic", false),
        ("Auto", "emblem-synchronizing-symbolic", false),
    ];

    let buttons: Vec<gtk::ToggleButton> = themes.iter().map(|(name, icon, active)| {
        let btn = create_theme_button(name, icon);
        btn.set_active(*active);
        btn
    }).collect();

    for (i, btn) in buttons.iter().enumerate() {
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                for (j, other) in buttons_clone.iter().enumerate() {
                    if j != idx {
                        other.set_active(false);
                    }
                }
                apply_theme(idx);
            }
        });
        
        theme_box.append(btn);
    }

    section.append(&label);
    section.append(&theme_box);
    section
}

fn create_theme_button(name: &str, icon: &str) -> gtk::ToggleButton {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 6);
    content.set_size_request(80, -1);
    
    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(28)
        .build();

    let label = gtk::Label::new(Some(name));

    content.append(&icon_widget);
    content.append(&label);

    gtk::ToggleButton::builder()
        .child(&content)
        .css_classes(["theme-btn"])
        .build()
}

fn create_accent_section() -> gtk::Box {
    let section = gtk::Box::new(gtk::Orientation::Vertical, 10);

    let label = gtk::Label::builder()
        .label("ACCENT COLOR")
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .build();

    let colors_box = gtk::Box::new(gtk::Orientation::Horizontal, 10);
    colors_box.set_halign(gtk::Align::Center);

    // Light blue as default accent
    let colors = [
        ("#5DADE2", "Blue", true),     // Light blue - default
        ("#48C9B0", "Teal", false),
        ("#58D68D", "Green", false),
        ("#AF7AC5", "Purple", false),
        ("#EC7063", "Red", false),
        ("#F4D03F", "Yellow", false),
    ];

    let buttons: Rc<RefCell<Vec<gtk::ToggleButton>>> = Rc::new(RefCell::new(Vec::new()));

    for (i, (color, name, active)) in colors.iter().enumerate() {
        let btn = gtk::ToggleButton::builder()
            .tooltip_text(*name)
            .active(*active)
            .width_request(40)
            .height_request(40)
            .build();
        
        let color_class = format!("accent-color-{}", i);
        btn.add_css_class("accent-btn");
        btn.add_css_class("circular");
        btn.add_css_class(&color_class);

        let css = format!(
            ".{} {{ background: {}; background-color: {}; min-width: 36px; min-height: 36px; }}",
            color_class, color, color
        );
        let provider = gtk::CssProvider::new();
        provider.load_from_data(&css);
        
        if let Some(display) = gdk4::Display::default() {
            gtk::style_context_add_provider_for_display(
                &display,
                &provider,
                gtk::STYLE_PROVIDER_PRIORITY_USER,
            );
        }

        buttons.borrow_mut().push(btn.clone());
        
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                for (j, other) in buttons_clone.borrow().iter().enumerate() {
                    if j != idx && other.is_active() {
                        other.set_active(false);
                    }
                }
                apply_accent(idx);
            }
        });

        colors_box.append(&btn);
    }

    section.append(&label);
    section.append(&colors_box);
    section
}

fn create_layout_section() -> gtk::Box {
    let section = gtk::Box::new(gtk::Orientation::Vertical, 10);

    let label = gtk::Label::builder()
        .label("DESKTOP LAYOUT")
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .build();

    let layouts_box = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    layouts_box.set_halign(gtk::Align::Center);

    let layouts = [
        ("Modern", "Top bar with activities", true),
        ("Traditional", "Bottom panel with app menu", false),
        ("Minimal", "Clean, distraction-free", false),
    ];

    let buttons: Vec<gtk::ToggleButton> = layouts.iter().map(|(name, desc, active)| {
        let btn = create_layout_button(name, desc);
        btn.set_active(*active);
        btn
    }).collect();

    for (i, btn) in buttons.iter().enumerate() {
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                for (j, other) in buttons_clone.iter().enumerate() {
                    if j != idx {
                        other.set_active(false);
                    }
                }
                apply_layout(idx);
            }
        });
        
        layouts_box.append(btn);
    }

    section.append(&label);
    section.append(&layouts_box);
    section
}

fn create_layout_button(name: &str, description: &str) -> gtk::ToggleButton {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 4);
    content.set_size_request(150, -1);
    
    let title = gtk::Label::builder()
        .label(name)
        .css_classes(["layout-title"])
        .build();

    let desc = gtk::Label::builder()
        .label(description)
        .css_classes(["caption", "dim-label"])
        .wrap(true)
        .build();

    content.append(&title);
    content.append(&desc);

    gtk::ToggleButton::builder()
        .child(&content)
        .css_classes(["layout-btn"])
        .build()
}

fn apply_theme(index: usize) {
    let scheme = match index {
        0 => "prefer-dark",
        1 => "prefer-light",
        _ => "default",
    };
    
    let _ = std::process::Command::new("gsettings")
        .args(["set", "org.gnome.desktop.interface", "color-scheme", scheme])
        .spawn();
}

fn apply_accent(index: usize) {
    let colors = ["blue", "teal", "green", "purple", "red", "yellow"];
    if let Some(color) = colors.get(index) {
        let _ = std::process::Command::new("gsettings")
            .args(["set", "org.gnome.desktop.interface", "accent-color", color])
            .spawn();
    }
}

fn apply_layout(index: usize) {
    let config_dir = glib::user_config_dir().join("fidelity");
    std::fs::create_dir_all(&config_dir).ok();
    
    let layout = match index {
        0 => "modern",
        1 => "traditional",
        _ => "minimal",
    };
    
    std::fs::write(config_dir.join("layout"), layout).ok();
}
