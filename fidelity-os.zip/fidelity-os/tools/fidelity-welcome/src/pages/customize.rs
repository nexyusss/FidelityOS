// Customize page - Theme and appearance options

use gtk4 as gtk;
use libadwaita as adw;
use gdk4;
use glib;
use gtk::prelude::*;
use adw::prelude::*;
use std::cell::RefCell;
use std::rc::Rc;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 24);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("customize-page");

    let title = gtk::Label::builder()
        .label("Make It Yours")
        .css_classes(["title-1"])
        .build();

    let subtitle = gtk::Label::builder()
        .label("Personalize your desktop experience")
        .css_classes(["subtitle"])
        .build();

    // Theme selection
    let theme_section = create_theme_section();
    
    // Accent color selection
    let accent_section = create_accent_section();

    // Layout selection
    let layout_section = create_layout_section();

    container.append(&title);
    container.append(&subtitle);
    container.append(&theme_section);
    container.append(&accent_section);
    container.append(&layout_section);

    Page {
        widget: container,
        title: "Customize".to_string(),
    }
}

fn create_theme_section() -> gtk::Box {
    let section = gtk::Box::new(gtk::Orientation::Vertical, 12);
    section.set_margin_top(24);

    let label = gtk::Label::builder()
        .label("Appearance")
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .build();

    let theme_box = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    theme_box.set_halign(gtk::Align::Center);

    let themes = [
        ("Dark", "weather-clear-night-symbolic", true),
        ("Light", "weather-clear-symbolic", false),
        ("Auto", "emblem-synchronizing-symbolic", false),
    ];

    let buttons: Vec<gtk::ToggleButton> = themes.iter().map(|(name, icon, active)| {
        let btn = create_theme_button(name, icon);
        btn.set_active(*active);
        btn
    }).collect();

    // Radio group behavior
    for (i, btn) in buttons.iter().enumerate() {
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                for (j, other) in buttons_clone.iter().enumerate() {
                    if j != idx {
                        other.set_active(false);
                    }
                }
                // Apply theme
                apply_theme(idx);
            }
        });
        
        theme_box.append(btn);
    }

    section.append(&label);
    section.append(&theme_box);
    section
}

fn create_theme_button(name: &str, icon: &str) -> gtk::ToggleButton {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 8);
    
    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(32)
        .build();

    let label = gtk::Label::new(Some(name));

    content.append(&icon_widget);
    content.append(&label);

    gtk::ToggleButton::builder()
        .child(&content)
        .css_classes(["theme-btn"])
        .build()
}

fn create_accent_section() -> gtk::Box {
    let section = gtk::Box::new(gtk::Orientation::Vertical, 12);
    section.set_margin_top(16);

    let label = gtk::Label::builder()
        .label("Accent Color")
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .build();

    let colors_box = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    colors_box.set_halign(gtk::Align::Center);

    let colors = [
        ("#88C0D0", "Frost", true),   // Nord frost - default
        ("#81A1C1", "Ocean", false),
        ("#A3BE8C", "Aurora", false),
        ("#B48EAD", "Purple", false),
        ("#BF616A", "Red", false),
        ("#EBCB8B", "Yellow", false),
    ];

    let buttons: Rc<RefCell<Vec<gtk::ToggleButton>>> = Rc::new(RefCell::new(Vec::new()));

    for (i, (color, name, active)) in colors.iter().enumerate() {
        let btn = gtk::ToggleButton::builder()
            .tooltip_text(*name)
            .active(*active)
            .width_request(44)
            .height_request(44)
            .build();
        
        // Use unique CSS class per color to avoid global style conflicts
        let color_class = format!("accent-color-{}", i);
        btn.add_css_class("accent-btn");
        btn.add_css_class("circular");
        btn.add_css_class(&color_class);

        // Apply color via display-level CSS provider (GTK4 way)
        let css = format!(
            ".{} {{ background: {}; background-color: {}; min-width: 40px; min-height: 40px; }}",
            color_class, color, color
        );
        let provider = gtk::CssProvider::new();
        provider.load_from_data(&css);
        
        // In GTK4, add provider to the display instead of style_context
        if let Some(display) = gdk4::Display::default() {
            gtk::style_context_add_provider_for_display(
                &display,
                &provider,
                gtk::STYLE_PROVIDER_PRIORITY_USER,
            );
        }

        buttons.borrow_mut().push(btn.clone());
        
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                // Deselect others
                for (j, other) in buttons_clone.borrow().iter().enumerate() {
                    if j != idx && other.is_active() {
                        other.set_active(false);
                    }
                }
                apply_accent(idx);
            }
        });

        colors_box.append(&btn);
    }

    section.append(&label);
    section.append(&colors_box);
    section
}

fn create_layout_section() -> gtk::Box {
    let section = gtk::Box::new(gtk::Orientation::Vertical, 12);
    section.set_margin_top(16);

    let label = gtk::Label::builder()
        .label("Desktop Layout")
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .build();

    let layouts_box = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    layouts_box.set_halign(gtk::Align::Center);

    let layouts = [
        ("Modern", "Top bar with activities", true),
        ("Traditional", "Bottom panel with app menu", false),
        ("Minimal", "Clean, distraction-free", false),
    ];

    let buttons: Vec<gtk::ToggleButton> = layouts.iter().map(|(name, desc, active)| {
        let btn = create_layout_button(name, desc);
        btn.set_active(*active);
        btn
    }).collect();

    for (i, btn) in buttons.iter().enumerate() {
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                for (j, other) in buttons_clone.iter().enumerate() {
                    if j != idx {
                        other.set_active(false);
                    }
                }
                apply_layout(idx);
            }
        });
        
        layouts_box.append(btn);
    }

    section.append(&label);
    section.append(&layouts_box);
    section
}

fn create_layout_button(name: &str, description: &str) -> gtk::ToggleButton {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 4);
    content.set_size_request(140, -1);
    
    let title = gtk::Label::builder()
        .label(name)
        .css_classes(["layout-title"])
        .build();

    let desc = gtk::Label::builder()
        .label(description)
        .css_classes(["caption", "dim-label"])
        .wrap(true)
        .build();

    content.append(&title);
    content.append(&desc);

    gtk::ToggleButton::builder()
        .child(&content)
        .css_classes(["layout-btn"])
        .build()
}

fn apply_theme(index: usize) {
    let scheme = match index {
        0 => "prefer-dark",
        1 => "prefer-light",
        _ => "default",
    };
    
    // Apply via gsettings
    let _ = std::process::Command::new("gsettings")
        .args(["set", "org.gnome.desktop.interface", "color-scheme", scheme])
        .spawn();
}

fn apply_accent(index: usize) {
    let colors = ["blue", "teal", "green", "purple", "red", "yellow"];
    if let Some(color) = colors.get(index) {
        let _ = std::process::Command::new("gsettings")
            .args(["set", "org.gnome.desktop.interface", "accent-color", color])
            .spawn();
    }
}

fn apply_layout(index: usize) {
    // Layout changes would involve GNOME extensions
    // For now, save preference to config
    let config_dir = glib::user_config_dir().join("fidelity");
    std::fs::create_dir_all(&config_dir).ok();
    
    let layout = match index {
        0 => "modern",
        1 => "traditional",
        _ => "minimal",
    };
    
    std::fs::write(config_dir.join("layout"), layout).ok();
}
