// Welcome app pages

mod welcome;
mod features;
mod privacy;
mod apps;
mod customize;
mod ready;

use gtk4 as gtk;

pub struct Page {
    pub widget: gtk::Box,
    pub title: String,
}

pub fn create_all_pages() -> Vec<Page> {
    vec![
        welcome::create(),
        features::create(),
        privacy::create(),
        apps::create(),
        customize::create(),
        ready::create(),
    ]
}
