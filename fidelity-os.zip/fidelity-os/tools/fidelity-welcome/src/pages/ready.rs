// Ready page - Final page with call to action

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 24);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("ready-page");

    // Celebration icon
    let icon_container = gtk::Box::new(gtk::Orientation::Vertical, 0);
    icon_container.add_css_class("celebration-container");

    let icon = gtk::Image::builder()
        .icon_name("emblem-ok-symbolic")
        .pixel_size(96)
        .build();
    icon.add_css_class("celebration-icon");

    icon_container.append(&icon);

    let title = gtk::Label::builder()
        .label("You're All Set!")
        .build();
    title.add_css_class("title-1");
    title.add_css_class("ready-title");

    let subtitle = gtk::Label::builder()
        .label("FidelityOS is ready for you")
        .build();
    subtitle.add_css_class("subtitle");

    // Quick tips
    let tips_box = gtk::Box::new(gtk::Orientation::Vertical, 12);
    tips_box.set_margin_top(40);
    tips_box.add_css_class("tips-container");

    let tips_label = gtk::Label::builder()
        .label("Quick Tips")
        .halign(gtk::Align::Start)
        .build();
    tips_label.add_css_class("heading");

    let tips = [
        ("Activities corner", "Move mouse to top-left to see all windows"),
        ("Super key", "Press to search apps and files"),
        ("Software Center", "Install apps with one click"),
        ("Settings", "Customize everything in FidelityOS Settings"),
    ];

    tips_box.append(&tips_label);

    for (tip_title, desc) in tips {
        let tip = create_tip(tip_title, desc);
        tips_box.append(&tip);
    }

    // Help resources
    let help_box = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    help_box.set_halign(gtk::Align::Center);
    help_box.set_margin_top(24);

    let docs_btn = gtk::Button::builder()
        .label("Documentation")
        .build();
    docs_btn.add_css_class("flat");

    docs_btn.connect_clicked(|_| {
        open_url("https://fidelityos.org/docs");
    });

    let community_btn = gtk::Button::builder()
        .label("Community")
        .build();
    community_btn.add_css_class("flat");

    community_btn.connect_clicked(|_| {
        open_url("https://fidelityos.org/community");
    });

    help_box.append(&docs_btn);
    help_box.append(&community_btn);

    container.append(&icon_container);
    container.append(&title);
    container.append(&subtitle);
    container.append(&tips_box);
    container.append(&help_box);

    Page {
        widget: container,
        title: "Ready".to_string(),
    }
}

fn create_tip(title: &str, description: &str) -> gtk::Box {
    let tip = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    tip.add_css_class("tip-item");

    let bullet = gtk::Label::builder()
        .label("•")
        .build();
    bullet.add_css_class("tip-bullet");

    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 2);
    
    let title_label = gtk::Label::builder()
        .label(title)
        .halign(gtk::Align::Start)
        .build();
    title_label.add_css_class("tip-title");

    let desc_label = gtk::Label::builder()
        .label(description)
        .halign(gtk::Align::Start)
        .build();
    desc_label.add_css_class("tip-desc");
    desc_label.add_css_class("dim-label");

    text_box.append(&title_label);
    text_box.append(&desc_label);

    tip.append(&bullet);
    tip.append(&text_box);

    tip
}

fn open_url(url: &str) {
    let _ = gtk::gio::AppInfo::launch_default_for_uri(
        url,
        None::<&gtk::gio::AppLaunchContext>,
    );
}
