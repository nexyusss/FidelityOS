// Ready page - Celebration with confetti-style design

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    // Horizontal layout - celebration on left, content on right
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 48);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("ready-page");

    // Left side - Success celebration
    let celebration_side = gtk::Box::new(gtk::Orientation::Vertical, 12);
    celebration_side.set_valign(gtk::Align::Center);
    celebration_side.add_css_class("celebration-container");

    let icon = gtk::Image::builder()
        .icon_name("emblem-ok-symbolic")
        .pixel_size(80)
        .build();
    icon.add_css_class("celebration-icon");

    // Decorative dots
    let dots = gtk::Label::builder()
        .label("• • •")
        .opacity(0.3)
        .build();

    celebration_side.append(&icon);
    celebration_side.append(&dots);

    // Right side - Content
    let content_side = gtk::Box::new(gtk::Orientation::Vertical, 14);
    content_side.set_valign(gtk::Align::Center);
    content_side.set_size_request(360, -1);

    // Success badge
    let badge = gtk::Label::builder()
        .label("🎉 Setup Complete")
        .halign(gtk::Align::Start)
        .build();
    badge.add_css_class("success-badge");

    let title = gtk::Label::builder()
        .label("You're All Set!")
        .halign(gtk::Align::Start)
        .build();
    title.add_css_class("title-1");
    title.add_css_class("ready-title");

    let subtitle = gtk::Label::builder()
        .label("FidelityOS is ready for you to explore")
        .halign(gtk::Align::Start)
        .build();
    subtitle.add_css_class("subtitle");

    // Tips box
    let tips_box = gtk::Box::new(gtk::Orientation::Vertical, 8);
    tips_box.set_margin_top(16);
    tips_box.add_css_class("tips-container");

    let tips_header = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    
    let tips_icon = gtk::Image::builder()
        .icon_name("dialog-information-symbolic")
        .pixel_size(16)
        .opacity(0.6)
        .build();

    let tips_label = gtk::Label::builder()
        .label("QUICK TIPS")
        .build();
    tips_label.add_css_class("heading");

    tips_header.append(&tips_icon);
    tips_header.append(&tips_label);
    tips_box.append(&tips_header);

    let tips = [
        ("→", "Activities", "Top-left corner or Super key"),
        ("→", "Search", "Just start typing to find apps"),
        ("→", "Settings", "Customize in FidelityOS Settings"),
    ];

    for (bullet, tip_title, desc) in tips {
        let tip = create_tip(bullet, tip_title, desc);
        tips_box.append(&tip);
    }

    // Action buttons
    let actions = gtk::Box::new(gtk::Orientation::Horizontal, 10);
    actions.set_margin_top(16);

    let docs_btn = gtk::Button::builder()
        .label("📖 Documentation")
        .build();
    docs_btn.add_css_class("flat");

    docs_btn.connect_clicked(|_| {
        open_url("https://fidelityos.org/docs");
    });

    let community_btn = gtk::Button::builder()
        .label("💬 Community")
        .build();
    community_btn.add_css_class("flat");

    community_btn.connect_clicked(|_| {
        open_url("https://fidelityos.org/community");
    });

    actions.append(&docs_btn);
    actions.append(&community_btn);

    content_side.append(&badge);
    content_side.append(&title);
    content_side.append(&subtitle);
    content_side.append(&tips_box);
    content_side.append(&actions);

    container.append(&celebration_side);
    container.append(&content_side);

    Page {
        widget: container,
        title: "Ready".to_string(),
    }
}

fn create_tip(bullet: &str, title: &str, description: &str) -> gtk::Box {
    let tip = gtk::Box::new(gtk::Orientation::Horizontal, 10);
    tip.add_css_class("tip-item");

    let bullet_label = gtk::Label::builder()
        .label(bullet)
        .build();
    bullet_label.add_css_class("tip-bullet");

    let text_box = gtk::Box::new(gtk::Orientation::Horizontal, 6);
    
    let title_label = gtk::Label::builder()
        .label(title)
        .build();
    title_label.add_css_class("tip-title");

    let sep = gtk::Label::new(Some("—"));
    sep.add_css_class("dim-label");
    sep.set_opacity(0.5);

    let desc_label = gtk::Label::builder()
        .label(description)
        .build();
    desc_label.add_css_class("tip-desc");

    text_box.append(&title_label);
    text_box.append(&sep);
    text_box.append(&desc_label);

    tip.append(&bullet_label);
    tip.append(&text_box);

    tip
}

fn open_url(url: &str) {
    let _ = gtk::gio::AppInfo::launch_default_for_uri(
        url,
        None::<&gtk::gio::AppLaunchContext>,
    );
}
