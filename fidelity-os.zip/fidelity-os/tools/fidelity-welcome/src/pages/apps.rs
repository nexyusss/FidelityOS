// Apps page - Polished grid with app icons

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 16);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("apps-page");

    // Header
    let header = gtk::Box::new(gtk::Orientation::Vertical, 8);
    header.set_halign(gtk::Align::Center);

    let header_icon = gtk::Image::builder()
        .icon_name("view-grid-symbolic")
        .pixel_size(32)
        .opacity(0.6)
        .build();

    let title = gtk::Label::builder()
        .label("Ready to Work")
        .build();
    title.add_css_class("title-1");

    let subtitle = gtk::Label::builder()
        .label("Essential apps, pre-installed and ready")
        .build();
    subtitle.add_css_class("subtitle");

    header.append(&header_icon);
    header.append(&title);
    header.append(&subtitle);

    // Apps grid - 4x2
    let apps_grid = gtk::Grid::builder()
        .row_spacing(10)
        .column_spacing(10)
        .halign(gtk::Align::Center)
        .margin_top(20)
        .build();

    let apps = [
        ("firefox", "Firefox", "Browser"),
        ("thunderbird", "Thunderbird", "Email"),
        ("libreoffice-writer", "LibreOffice", "Office"),
        ("keepassxc", "KeePassXC", "Passwords"),
        ("org.gnome.Nautilus", "Files", "Manager"),
        ("utilities-terminal", "Terminal", "CLI"),
        ("accessories-text-editor", "Editor", "Notes"),
        ("accessories-calculator", "Calculator", "Math"),
    ];

    for (i, (icon, name, category)) in apps.iter().enumerate() {
        let row = (i / 4) as i32;
        let col = (i % 4) as i32;
        let card = create_app_card(icon, name, category);
        apps_grid.attach(&card, col, row, 1, 1);
    }

    // Footer with CTA
    let footer = gtk::Box::new(gtk::Orientation::Vertical, 12);
    footer.set_halign(gtk::Align::Center);
    footer.set_margin_top(24);

    let divider = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    divider.set_halign(gtk::Align::Center);

    let line_left = gtk::Separator::new(gtk::Orientation::Horizontal);
    line_left.set_size_request(60, -1);
    line_left.set_opacity(0.3);

    let more_label = gtk::Label::builder()
        .label("Want more?")
        .build();
    more_label.add_css_class("dim-label");
    more_label.add_css_class("caption");

    let line_right = gtk::Separator::new(gtk::Orientation::Horizontal);
    line_right.set_size_request(60, -1);
    line_right.set_opacity(0.3);

    divider.append(&line_left);
    divider.append(&more_label);
    divider.append(&line_right);

    let software_btn = gtk::Button::builder()
        .label("Open Software Center →")
        .build();
    software_btn.add_css_class("pill");
    software_btn.add_css_class("suggested-action");

    software_btn.connect_clicked(|_| {
        let _ = std::process::Command::new("fidelity-software").spawn();
    });

    footer.append(&divider);
    footer.append(&software_btn);

    container.append(&header);
    container.append(&apps_grid);
    container.append(&footer);

    Page {
        widget: container,
        title: "Apps".to_string(),
    }
}

fn create_app_card(icon: &str, name: &str, category: &str) -> gtk::Box {
    let card = gtk::Box::new(gtk::Orientation::Vertical, 6);
    card.add_css_class("app-card");
    card.set_size_request(105, -1);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(40)
        .build();
    icon_widget.add_css_class("app-icon");

    let name_label = gtk::Label::builder()
        .label(name)
        .ellipsize(gtk::pango::EllipsizeMode::End)
        .build();
    name_label.add_css_class("app-name");

    let category_label = gtk::Label::builder()
        .label(category)
        .build();
    category_label.add_css_class("app-category");

    card.append(&icon_widget);
    card.append(&name_label);
    card.append(&category_label);

    card
}
