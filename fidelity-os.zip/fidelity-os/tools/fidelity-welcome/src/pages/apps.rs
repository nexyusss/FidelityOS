// Apps page - Show pre-installed apps and optional installs

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 24);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("apps-page");

    let title = gtk::Label::builder()
        .label("Ready to Work")
        .build();
    title.add_css_class("title-1");

    let subtitle = gtk::Label::builder()
        .label("Essential apps, pre-installed and ready")
        .build();
    subtitle.add_css_class("subtitle");

    // Pre-installed apps showcase
    let apps_flow = gtk::FlowBox::builder()
        .max_children_per_line(4)
        .min_children_per_line(3)
        .selection_mode(gtk::SelectionMode::None)
        .row_spacing(16)
        .column_spacing(16)
        .halign(gtk::Align::Center)
        .margin_top(24)
        .build();

    let apps = [
        ("firefox", "Firefox", "Web Browser"),
        ("thunderbird", "Thunderbird", "Email"),
        ("libreoffice-writer", "LibreOffice", "Office Suite"),
        ("keepassxc", "KeePassXC", "Passwords"),
        ("org.gnome.Nautilus", "Files", "File Manager"),
        ("utilities-terminal", "Terminal", "Command Line"),
        ("accessories-text-editor", "Text Editor", "Notes"),
        ("accessories-calculator", "Calculator", "Math"),
    ];

    for (icon, name, category) in apps {
        let app_widget = create_app_card(icon, name, category);
        apps_flow.append(&app_widget);
    }

    // Optional apps section
    let optional_label = gtk::Label::builder()
        .label("Want more? Install from the Software Center")
        .margin_top(32)
        .build();
    optional_label.add_css_class("caption");
    optional_label.add_css_class("dim-label");

    let software_btn = gtk::Button::builder()
        .label("Open Software Center")
        .halign(gtk::Align::Center)
        .margin_top(12)
        .build();
    software_btn.add_css_class("pill");
    software_btn.add_css_class("suggested-action");

    software_btn.connect_clicked(|_| {
        let _ = std::process::Command::new("fidelity-software").spawn();
    });

    container.append(&title);
    container.append(&subtitle);
    container.append(&apps_flow);
    container.append(&optional_label);
    container.append(&software_btn);

    Page {
        widget: container,
        title: "Apps".to_string(),
    }
}

fn create_app_card(icon: &str, name: &str, category: &str) -> gtk::Box {
    let card = gtk::Box::new(gtk::Orientation::Vertical, 8);
    card.add_css_class("app-card");
    card.set_size_request(100, -1);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(48)
        .build();
    icon_widget.add_css_class("app-icon");

    let name_label = gtk::Label::builder()
        .label(name)
        .ellipsize(gtk::pango::EllipsizeMode::End)
        .build();
    name_label.add_css_class("app-name");

    let category_label = gtk::Label::builder()
        .label(category)
        .build();
    category_label.add_css_class("app-category");
    category_label.add_css_class("dim-label");
    category_label.add_css_class("caption");

    card.append(&icon_widget);
    card.append(&name_label);
    card.append(&category_label);

    card
}
