// Welcome page - Polished horizontal layout with visual details

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    // Main horizontal layout - logo on left, content on right
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 56);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("welcome-page");

    // Left side - Logo with background circle
    let logo_side = gtk::Box::new(gtk::Orientation::Vertical, 0);
    logo_side.set_valign(gtk::Align::Center);
    logo_side.set_halign(gtk::Align::Center);
    logo_side.add_css_class("logo-container");

    let logo = gtk::Image::builder()
        .icon_name("security-high-symbolic")
        .pixel_size(100)
        .build();
    logo.add_css_class("logo-icon");

    logo_side.append(&logo);

    // Right side - Text content
    let content_side = gtk::Box::new(gtk::Orientation::Vertical, 12);
    content_side.set_valign(gtk::Align::Center);
    content_side.set_halign(gtk::Align::Start);
    content_side.set_size_request(420, -1);

    // Welcome badge
    let badge = gtk::Label::builder()
        .label("✨ Welcome")
        .halign(gtk::Align::Start)
        .build();
    badge.add_css_class("welcome-badge");

    let title = gtk::Label::builder()
        .label("Welcome to FidelityOS")
        .halign(gtk::Align::Start)
        .build();
    title.add_css_class("welcome-title");

    let subtitle = gtk::Label::builder()
        .label("Clean. Fast. Private. Yours.")
        .halign(gtk::Align::Start)
        .build();
    subtitle.add_css_class("welcome-subtitle");

    // Feature highlights - horizontal row with icons
    let highlights = create_highlights();

    let version = gtk::Label::builder()
        .label("Version 1.0 • Built on Debian Bookworm")
        .halign(gtk::Align::Start)
        .build();
    version.add_css_class("version-label");

    content_side.append(&badge);
    content_side.append(&title);
    content_side.append(&subtitle);
    content_side.append(&highlights);
    content_side.append(&version);

    container.append(&logo_side);
    container.append(&content_side);

    Page {
        widget: container,
        title: "Welcome".to_string(),
    }
}

fn create_highlights() -> gtk::Box {
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    container.set_halign(gtk::Align::Start);
    container.set_margin_top(28);
    container.set_margin_bottom(12);
    container.add_css_class("highlights-container");

    let items = [
        ("emblem-system-symbolic", "Lightning Fast"),
        ("security-high-symbolic", "Privacy First"),
        ("application-x-executable-symbolic", "Modern Apps"),
    ];

    for (icon, title) in items {
        let item = gtk::Box::new(gtk::Orientation::Horizontal, 10);
        item.add_css_class("highlight-item");

        let icon_widget = gtk::Image::builder()
            .icon_name(icon)
            .pixel_size(20)
            .build();
        icon_widget.add_css_class("highlight-icon");

        let title_label = gtk::Label::new(Some(title));
        title_label.add_css_class("highlight-label");

        item.append(&icon_widget);
        item.append(&title_label);
        container.append(&item);
    }

    container
}
