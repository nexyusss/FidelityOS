// Welcome page - First impression with animated logo

use gtk4 as gtk;
use gtk::prelude::*;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 24);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("welcome-page");

    // Logo container
    let logo_container = gtk::Box::new(gtk::Orientation::Vertical, 0);
    logo_container.add_css_class("logo-container");
    logo_container.set_margin_bottom(16);

    // Logo icon - using a shield for privacy/security theme
    let logo = gtk::Image::builder()
        .icon_name("security-high-symbolic")
        .pixel_size(120)
        .build();
    logo.add_css_class("logo-icon");

    logo_container.append(&logo);

    // Title
    let title = gtk::Label::builder()
        .label("Welcome to FidelityOS")
        .build();
    title.add_css_class("title-1");
    title.add_css_class("welcome-title");

    // Subtitle with tagline
    let subtitle = gtk::Label::builder()
        .label("Clean. Fast. Private. Yours.")
        .build();
    subtitle.add_css_class("subtitle");
    subtitle.add_css_class("welcome-subtitle");

    // Feature highlights
    let highlights = create_highlights();

    // Version info
    let version = gtk::Label::builder()
        .label("Version 1.0 • Built on Debian Bookworm")
        .build();
    version.add_css_class("caption");
    version.add_css_class("version-label");

    container.append(&logo_container);
    container.append(&title);
    container.append(&subtitle);
    container.append(&highlights);
    container.append(&version);

    Page {
        widget: container,
        title: "Welcome".to_string(),
    }
}

fn create_highlights() -> gtk::Box {
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 24);
    container.set_halign(gtk::Align::Center);
    container.set_margin_top(40);
    container.set_margin_bottom(16);
    container.add_css_class("highlights-container");

    let items = [
        ("emblem-system-symbolic", "Lightning Fast", "Optimized for speed"),
        ("security-high-symbolic", "Privacy First", "Your data stays yours"),
        ("application-x-executable-symbolic", "Modern Apps", "Flatpak & APT"),
    ];

    for (icon, title, desc) in items {
        let item = gtk::Box::new(gtk::Orientation::Vertical, 8);
        item.add_css_class("highlight-item");
        item.set_size_request(140, -1);

        let icon_widget = gtk::Image::builder()
            .icon_name(icon)
            .pixel_size(36)
            .build();
        icon_widget.add_css_class("highlight-icon");

        let title_label = gtk::Label::builder()
            .label(title)
            .build();
        title_label.add_css_class("highlight-label");

        let desc_label = gtk::Label::builder()
            .label(desc)
            .build();
        desc_label.add_css_class("caption");
        desc_label.add_css_class("dim-label");

        item.append(&icon_widget);
        item.append(&title_label);
        item.append(&desc_label);
        container.append(&item);
    }

    container
}
