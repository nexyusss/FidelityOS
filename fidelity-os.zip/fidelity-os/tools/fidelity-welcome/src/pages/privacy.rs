// Privacy page - Privacy settings and explanation

use gtk4 as gtk;
use gtk::prelude::*;
use std::cell::RefCell;
use std::rc::Rc;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 24);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("privacy-page");

    let icon = gtk::Image::builder()
        .icon_name("security-high-symbolic")
        .pixel_size(64)
        .build();
    icon.add_css_class("privacy-icon");

    let title = gtk::Label::builder()
        .label("Your Privacy Matters")
        .build();
    title.add_css_class("title-1");

    let subtitle = gtk::Label::builder()
        .label("Choose your privacy level")
        .build();
    subtitle.add_css_class("subtitle");

    // Privacy level selector
    let level_box = gtk::Box::new(gtk::Orientation::Vertical, 12);
    level_box.set_margin_top(32);
    level_box.add_css_class("privacy-levels");

    let levels = [
        ("Standard", "Basic protection with firewall enabled", &["Firewall (UFW)", "No telemetry"][..]),
        ("Enhanced", "Recommended for most users", &["Everything in Standard", "DNS-over-HTTPS", "MAC randomization"][..]),
        ("Maximum", "For privacy enthusiasts", &["Everything in Enhanced", "Tor Browser ready", "VPN support"][..]),
    ];

    let buttons: Rc<RefCell<Vec<gtk::ToggleButton>>> = Rc::new(RefCell::new(Vec::new()));

    for (i, (name, desc, features)) in levels.iter().enumerate() {
        let btn = create_privacy_level_button(name, desc, features);
        if i == 1 {
            btn.set_active(true); // Enhanced is default
        }
        
        buttons.borrow_mut().push(btn.clone());
        
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                for (j, other) in buttons_clone.borrow().iter().enumerate() {
                    if j != idx && other.is_active() {
                        other.set_active(false);
                    }
                }
                save_privacy_level(idx);
            }
        });
        
        level_box.append(&btn);
    }

    // Info note
    let note = gtk::Label::builder()
        .label("You can change these settings anytime in FidelityOS Settings")
        .margin_top(24)
        .build();
    note.add_css_class("caption");
    note.add_css_class("dim-label");

    container.append(&icon);
    container.append(&title);
    container.append(&subtitle);
    container.append(&level_box);
    container.append(&note);

    Page {
        widget: container,
        title: "Privacy".to_string(),
    }
}

fn create_privacy_level_button(name: &str, description: &str, features: &[&str]) -> gtk::ToggleButton {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 8);
    content.set_halign(gtk::Align::Start);
    content.set_margin_start(8);
    content.set_margin_end(8);
    content.set_margin_top(4);
    content.set_margin_bottom(4);

    let header = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    
    let title = gtk::Label::builder()
        .label(name)
        .halign(gtk::Align::Start)
        .build();
    title.add_css_class("privacy-level-title");

    let desc = gtk::Label::builder()
        .label(description)
        .halign(gtk::Align::Start)
        .build();
    desc.add_css_class("dim-label");
    desc.add_css_class("caption");

    header.append(&title);
    header.append(&desc);

    let features_box = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    features_box.add_css_class("privacy-features");
    features_box.set_margin_top(4);
    
    for feature in features {
        let chip = gtk::Label::builder()
            .label(*feature)
            .build();
        chip.add_css_class("privacy-chip");
        features_box.append(&chip);
    }

    content.append(&header);
    content.append(&features_box);

    let btn = gtk::ToggleButton::builder()
        .child(&content)
        .build();
    btn.add_css_class("privacy-level-btn");

    btn
}

fn save_privacy_level(level: usize) {
    let config_dir = glib::user_config_dir().join("fidelity");
    std::fs::create_dir_all(&config_dir).ok();
    
    let level_name = match level {
        0 => "standard",
        1 => "enhanced",
        _ => "maximum",
    };
    
    std::fs::write(config_dir.join("privacy-level"), level_name).ok();
}
