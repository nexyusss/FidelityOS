// Privacy page - Horizontal layout with clean cards

use gtk4 as gtk;
use gtk::prelude::*;
use glib;
use std::cell::RefCell;
use std::rc::Rc;

use super::Page;

pub fn create() -> Page {
    let container = gtk::Box::new(gtk::Orientation::Vertical, 20);
    container.set_valign(gtk::Align::Center);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("page");
    container.add_css_class("privacy-page");

    // Header with icon
    let header = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    header.set_halign(gtk::Align::Center);

    let icon = gtk::Image::builder()
        .icon_name("security-high-symbolic")
        .pixel_size(48)
        .build();
    icon.add_css_class("privacy-icon");

    let title_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
    
    let title = gtk::Label::builder()
        .label("Your Privacy Matters")
        .halign(gtk::Align::Start)
        .build();
    title.add_css_class("title-1");

    let subtitle = gtk::Label::builder()
        .label("Choose your privacy level")
        .halign(gtk::Align::Start)
        .build();
    subtitle.add_css_class("subtitle");

    title_box.append(&title);
    title_box.append(&subtitle);

    header.append(&icon);
    header.append(&title_box);

    // Privacy levels - horizontal row
    let level_box = gtk::Box::new(gtk::Orientation::Horizontal, 14);
    level_box.set_halign(gtk::Align::Center);
    level_box.set_margin_top(28);

    let levels = [
        ("Standard", "Basic protection", &["Firewall enabled", "No telemetry", "Auto-updates"][..]),
        ("Enhanced", "Recommended", &["DNS-over-HTTPS", "MAC randomization", "AppArmor"][..]),
        ("Maximum", "Hardened system", &["Kernel hardening", "Strict firewall", "Audit logging", "USB protection"][..]),
    ];

    let buttons: Rc<RefCell<Vec<gtk::ToggleButton>>> = Rc::new(RefCell::new(Vec::new()));

    for (i, (name, desc, features)) in levels.iter().enumerate() {
        let btn = create_privacy_level_button(name, desc, features);
        if i == 1 {
            btn.set_active(true);
        }
        
        buttons.borrow_mut().push(btn.clone());
        
        let buttons_clone = buttons.clone();
        let idx = i;
        
        btn.connect_toggled(move |button| {
            if button.is_active() {
                for (j, other) in buttons_clone.borrow().iter().enumerate() {
                    if j != idx && other.is_active() {
                        other.set_active(false);
                    }
                }
                save_privacy_level(idx);
            }
        });
        
        level_box.append(&btn);
    }

    let note = gtk::Label::builder()
        .label("You can change these settings anytime in FidelityOS Settings")
        .margin_top(20)
        .build();
    note.add_css_class("caption");
    note.add_css_class("dim-label");

    container.append(&header);
    container.append(&level_box);
    container.append(&note);

    Page {
        widget: container,
        title: "Privacy".to_string(),
    }
}

fn create_privacy_level_button(name: &str, description: &str, features: &[&str]) -> gtk::ToggleButton {
    let content = gtk::Box::new(gtk::Orientation::Vertical, 8);
    content.set_size_request(180, -1);
    content.set_margin_start(8);
    content.set_margin_end(8);
    content.set_margin_top(8);
    content.set_margin_bottom(8);

    let title = gtk::Label::builder()
        .label(name)
        .build();
    title.add_css_class("privacy-level-title");

    let desc = gtk::Label::builder()
        .label(description)
        .build();
    desc.add_css_class("dim-label");
    desc.add_css_class("caption");

    let features_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
    features_box.set_margin_top(8);
    
    for feature in features {
        let chip = gtk::Label::builder()
            .label(*feature)
            .build();
        chip.add_css_class("privacy-chip");
        features_box.append(&chip);
    }

    content.append(&title);
    content.append(&desc);
    content.append(&features_box);

    let btn = gtk::ToggleButton::builder()
        .child(&content)
        .build();
    btn.add_css_class("privacy-level-btn");

    btn
}

fn save_privacy_level(level: usize) {
    let config_dir = glib::user_config_dir().join("fidelity");
    std::fs::create_dir_all(&config_dir).ok();
    
    let level_name = match level {
        0 => "standard",
        1 => "enhanced",
        _ => "maximum",
    };
    
    std::fs::write(config_dir.join("privacy-level"), level_name).ok();
    
    // For Maximum security, create a flag file to trigger hardening on next boot
    if level == 2 {
        std::fs::write(config_dir.join("apply-maximum-security"), "1").ok();
    } else {
        std::fs::remove_file(config_dir.join("apply-maximum-security")).ok();
    }
}
