// Main application window with carousel navigation

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;
use std::cell::RefCell;
use std::rc::Rc;

use crate::pages;
use crate::animations;

pub fn build_window(app: &adw::Application) -> adw::ApplicationWindow {
    // Check if welcome was already completed
    let config_path = glib::user_config_dir().join("fidelity/welcome-complete");
    if config_path.exists() {
        // Show a simpler "welcome back" or just close
        // For now, we'll still show the window but could skip
    }

    let window = adw::ApplicationWindow::builder()
        .application(app)
        .title("Welcome to FidelityOS")
        .default_width(920)
        .default_height(640)
        .resizable(false)
        .build();

    // Add window styling
    window.add_css_class("welcome-window");

    // Main container
    let main_box = gtk::Box::new(gtk::Orientation::Vertical, 0);
    main_box.add_css_class("main-container");
    main_box.set_vexpand(true);

    // Create carousel for page navigation
    let carousel = adw::Carousel::builder()
        .interactive(false)
        .allow_scroll_wheel(false)
        .allow_mouse_drag(false)
        .build();
    carousel.add_css_class("welcome-carousel");

    // Carousel indicator dots
    let carousel_dots = adw::CarouselIndicatorDots::builder()
        .carousel(&carousel)
        .build();
    carousel_dots.add_css_class("carousel-dots");

    // Create all pages
    let pages_data = pages::create_all_pages();
    let page_count = pages_data.len();
    
    for page in &pages_data {
        carousel.append(&page.widget);
    }

    // Navigation buttons container
    let nav_box = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    nav_box.set_halign(gtk::Align::Center);
    nav_box.set_margin_bottom(32);
    nav_box.add_css_class("nav-container");

    let back_btn = gtk::Button::builder()
        .label("Back")
        .css_classes(["nav-button", "back-button"])
        .sensitive(false)
        .build();

    let next_btn = gtk::Button::builder()
        .label("Next")
        .css_classes(["nav-button", "next-button", "suggested-action"])
        .build();

    let skip_btn = gtk::Button::builder()
        .label("Skip")
        .css_classes(["nav-button", "skip-button", "flat"])
        .build();

    nav_box.append(&back_btn);
    nav_box.append(&carousel_dots);
    nav_box.append(&next_btn);
    nav_box.append(&skip_btn);

    // Current page tracking
    let current_page = Rc::new(RefCell::new(0usize));

    // Navigation logic
    let carousel_clone = carousel.clone();
    let current_clone = current_page.clone();
    let back_clone = back_btn.clone();
    let next_clone = next_btn.clone();
    let skip_clone = skip_btn.clone();
    let window_clone = window.clone();

    next_btn.connect_clicked(move |_| {
        let mut current = current_clone.borrow_mut();
        if *current < page_count - 1 {
            *current += 1;
            let page = carousel_clone.nth_page(*current as u32);
            carousel_clone.scroll_to(&page, true);
            
            back_clone.set_sensitive(true);
            
            if *current == page_count - 1 {
                next_clone.set_label("Get Started");
                skip_clone.set_visible(false);
            }
        } else {
            // Final page - close and mark setup complete
            mark_setup_complete();
            window_clone.close();
        }
        
        // Trigger page animation
        animations::animate_page_enter(&carousel_clone.nth_page(*current as u32));
    });

    let carousel_clone = carousel.clone();
    let current_clone = current_page.clone();
    let back_clone = back_btn.clone();
    let next_clone = next_btn.clone();
    let skip_clone = skip_btn.clone();

    back_btn.connect_clicked(move |btn| {
        let mut current = current_clone.borrow_mut();
        if *current > 0 {
            *current -= 1;
            let page = carousel_clone.nth_page(*current as u32);
            carousel_clone.scroll_to(&page, true);
            
            if *current == 0 {
                btn.set_sensitive(false);
            }
            
            next_clone.set_label("Next");
            skip_clone.set_visible(true);
        }
    });

    let window_clone = window.clone();
    skip_btn.connect_clicked(move |_| {
        mark_setup_complete();
        window_clone.close();
    });

    // Assemble layout
    main_box.append(&carousel);
    main_box.append(&nav_box);

    window.set_content(Some(&main_box));

    // Initial animation
    glib::timeout_add_local_once(std::time::Duration::from_millis(100), move || {
        animations::animate_window_enter(&carousel);
    });

    window
}

fn mark_setup_complete() {
    let config_dir = glib::user_config_dir().join("fidelity");
    std::fs::create_dir_all(&config_dir).ok();
    std::fs::write(config_dir.join("welcome-complete"), "1").ok();
}
