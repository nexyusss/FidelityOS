// FidelityOS Welcome Application
// A stunning, animated welcome experience for new users

mod app;
mod pages;
mod widgets;
mod animations;
mod actions;

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;

const APP_ID: &str = "org.fidelityos.welcome";

fn main() -> glib::ExitCode {
    // Initialize GTK and Libadwaita
    let app = adw::Application::builder()
        .application_id(APP_ID)
        .build();

    app.connect_startup(|_| {
        // Load custom CSS
        load_css();
    });

    app.connect_activate(|app| {
        let window = app::build_window(app);
        window.present();
    });

    app.run()
}

fn load_css() {
    let provider = gtk::CssProvider::new();
    provider.load_from_data(include_str!("style.css"));

    gtk::style_context_add_provider_for_display(
        &gdk4::Display::default().expect("Could not get default display"),
        &provider,
        gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
}
