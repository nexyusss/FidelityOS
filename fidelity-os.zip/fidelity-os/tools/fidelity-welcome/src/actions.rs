// System actions for FidelityOS Welcome

use std::process::Command;
use glib;

/// Apply privacy settings based on selected level
pub fn apply_privacy_level(level: usize) -> Result<(), String> {
    match level {
        0 => apply_standard_privacy(),
        1 => apply_enhanced_privacy(),
        2 => apply_maximum_privacy(),
        _ => Err("Invalid privacy level".to_string()),
    }
}

fn apply_standard_privacy() -> Result<(), String> {
    // Enable UFW firewall
    run_command("sudo", &["ufw", "enable"])?;
    run_command("sudo", &["ufw", "default", "deny", "incoming"])?;
    run_command("sudo", &["ufw", "default", "allow", "outgoing"])?;
    
    save_privacy_config("standard")
}

fn apply_enhanced_privacy() -> Result<(), String> {
    // Standard + DNS-over-HTTPS + MAC randomization
    apply_standard_privacy()?;
    
    // Enable DNS-over-HTTPS via systemd-resolved
    let doh_config = r#"[Resolve]
DNS=1.1.1.1#cloudflare-dns.com 1.0.0.1#cloudflare-dns.com
DNSOverTLS=yes
"#;
    
    std::fs::create_dir_all("/etc/systemd/resolved.conf.d").ok();
    std::fs::write("/etc/systemd/resolved.conf.d/fidelity-doh.conf", doh_config)
        .map_err(|e| e.to_string())?;
    
    // Enable MAC randomization
    let nm_config = r#"[device]
wifi.scan-rand-mac-address=yes

[connection]
wifi.cloned-mac-address=random
ethernet.cloned-mac-address=random
"#;
    
    std::fs::write("/etc/NetworkManager/conf.d/fidelity-privacy.conf", nm_config)
        .map_err(|e| e.to_string())?;
    
    run_command("sudo", &["systemctl", "restart", "systemd-resolved"])?;
    run_command("sudo", &["systemctl", "restart", "NetworkManager"])?;
    
    save_privacy_config("enhanced")
}

fn apply_maximum_privacy() -> Result<(), String> {
    // Enhanced + Tor + VPN support
    apply_enhanced_privacy()?;
    
    // Install Tor browser if not present
    run_command("flatpak", &["install", "-y", "flathub", "com.github.nickvergessen.TorBrowser"]).ok();
    
    // Install WireGuard
    run_command("sudo", &["apt", "install", "-y", "wireguard"]).ok();
    
    save_privacy_config("maximum")
}

fn save_privacy_config(level: &str) -> Result<(), String> {
    let config_dir = glib::user_config_dir().join("fidelity");
    std::fs::create_dir_all(&config_dir).map_err(|e| e.to_string())?;
    std::fs::write(config_dir.join("privacy-level"), level).map_err(|e| e.to_string())?;
    Ok(())
}

fn run_command(cmd: &str, args: &[&str]) -> Result<(), String> {
    Command::new(cmd)
        .args(args)
        .output()
        .map_err(|e| e.to_string())?;
    Ok(())
}

/// Enable Flatpak and add Flathub
pub fn setup_flatpak() -> Result<(), String> {
    run_command("flatpak", &["remote-add", "--if-not-exists", "flathub", 
                            "https://flathub.org/repo/flathub.flatpakrepo"])
}

/// Apply desktop layout
pub fn apply_layout(layout: &str) -> Result<(), String> {
    match layout {
        "modern" => {
            // Default GNOME layout
            run_command("gsettings", &["reset", "org.gnome.shell", "enabled-extensions"])
        }
        "traditional" => {
            // Enable dash-to-panel extension
            run_command("gsettings", &["set", "org.gnome.shell", "enabled-extensions", 
                                       "['dash-to-panel@jderose9.github.com']"])
        }
        "minimal" => {
            // Hide top bar, minimal UI
            run_command("gsettings", &["set", "org.gnome.shell", "enabled-extensions",
                                       "['hidetopbar@mathieu.bidon.ca']"])
        }
        _ => Err("Unknown layout".to_string()),
    }
}
