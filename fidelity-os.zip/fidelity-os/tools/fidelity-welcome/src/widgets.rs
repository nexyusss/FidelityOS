// Custom widgets for FidelityOS Welcome - Enhanced

use gtk4 as gtk;
use libadwaita as adw;
use gtk::prelude::*;
use adw::prelude::*;
use glib;

/// Create a styled card widget
pub fn card(content: &gtk::Widget) -> gtk::Frame {
    let frame = gtk::Frame::builder()
        .child(content)
        .css_classes(["card"])
        .build();
    frame
}

/// Create a feature row with icon and text
pub fn feature_row(icon_name: &str, title: &str, description: &str) -> gtk::Box {
    let row = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    row.add_css_class("feature-row");

    let icon = gtk::Image::builder()
        .icon_name(icon_name)
        .pixel_size(32)
        .css_classes(["feature-row-icon"])
        .build();

    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
    
    let title_label = gtk::Label::builder()
        .label(title)
        .css_classes(["feature-row-title"])
        .halign(gtk::Align::Start)
        .build();

    let desc_label = gtk::Label::builder()
        .label(description)
        .css_classes(["feature-row-desc", "dim-label"])
        .halign(gtk::Align::Start)
        .wrap(true)
        .build();

    text_box.append(&title_label);
    text_box.append(&desc_label);

    row.append(&icon);
    row.append(&text_box);

    row
}

/// Create a pill-shaped button
pub fn pill_button(label: &str, suggested: bool) -> gtk::Button {
    let mut classes = vec!["pill"];
    if suggested {
        classes.push("suggested-action");
    }
    
    gtk::Button::builder()
        .label(label)
        .css_classes(classes)
        .build()
}

/// Create a section header
pub fn section_header(title: &str) -> gtk::Label {
    gtk::Label::builder()
        .label(title)
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .margin_top(24)
        .margin_bottom(12)
        .build()
}

/// Create a loading spinner with label
pub fn loading_indicator(message: &str) -> gtk::Box {
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    container.set_halign(gtk::Align::Center);

    let spinner = gtk::Spinner::builder()
        .spinning(true)
        .build();

    let label = gtk::Label::builder()
        .label(message)
        .css_classes(["dim-label"])
        .build();

    container.append(&spinner);
    container.append(&label);

    container
}

/// Create a success indicator
pub fn success_indicator(message: &str) -> gtk::Box {
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 10);
    container.set_halign(gtk::Align::Center);
    container.add_css_class("success-indicator");

    let icon = gtk::Image::builder()
        .icon_name("emblem-ok-symbolic")
        .pixel_size(20)
        .build();
    icon.add_css_class("success");

    let label = gtk::Label::builder()
        .label(message)
        .css_classes(["success"])
        .build();

    container.append(&icon);
    container.append(&label);

    container
}

/// Create a badge label
pub fn badge(text: &str, style: BadgeStyle) -> gtk::Label {
    let css_class = match style {
        BadgeStyle::Primary => "badge-primary",
        BadgeStyle::Success => "badge-success",
        BadgeStyle::Warning => "badge-warning",
        BadgeStyle::Info => "badge-info",
    };

    gtk::Label::builder()
        .label(text)
        .css_classes([css_class, "badge"])
        .build()
}

pub enum BadgeStyle {
    Primary,
    Success,
    Warning,
    Info,
}

/// Create an info banner
pub fn info_banner(icon: &str, title: &str, message: &str) -> gtk::Box {
    let banner = gtk::Box::new(gtk::Orientation::Horizontal, 14);
    banner.add_css_class("info-banner");
    banner.set_margin_top(16);
    banner.set_margin_bottom(16);

    let icon_widget = gtk::Image::builder()
        .icon_name(icon)
        .pixel_size(24)
        .opacity(0.8)
        .build();

    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 2);
    text_box.set_hexpand(true);

    let title_label = gtk::Label::builder()
        .label(title)
        .halign(gtk::Align::Start)
        .css_classes(["heading"])
        .build();

    let message_label = gtk::Label::builder()
        .label(message)
        .halign(gtk::Align::Start)
        .css_classes(["dim-label", "caption"])
        .wrap(true)
        .build();

    text_box.append(&title_label);
    text_box.append(&message_label);

    banner.append(&icon_widget);
    banner.append(&text_box);

    banner
}

/// Show a toast notification (requires AdwToastOverlay in parent)
pub fn show_toast(overlay: &adw::ToastOverlay, message: &str) {
    let toast = adw::Toast::builder()
        .title(message)
        .timeout(3)
        .build();
    overlay.add_toast(toast);
}

/// Create a step indicator (1 of 6, etc.)
pub fn step_indicator(current: u32, total: u32) -> gtk::Box {
    let container = gtk::Box::new(gtk::Orientation::Horizontal, 8);
    container.set_halign(gtk::Align::Center);

    for i in 1..=total {
        let dot = gtk::Box::new(gtk::Orientation::Vertical, 0);
        
        if i == current {
            dot.set_size_request(24, 8);
            dot.add_css_class("step-active");
        } else if i < current {
            dot.set_size_request(8, 8);
            dot.add_css_class("step-complete");
        } else {
            dot.set_size_request(8, 8);
            dot.add_css_class("step-pending");
        }
        
        container.append(&dot);
    }

    container
}

/// Create a keyboard shortcut display
pub fn keyboard_shortcut(keys: &str, action: &str) -> gtk::Box {
    let row = gtk::Box::new(gtk::Orientation::Horizontal, 12);
    row.add_css_class("shortcut-row");

    let action_label = gtk::Label::builder()
        .label(action)
        .halign(gtk::Align::Start)
        .hexpand(true)
        .build();

    let keys_box = gtk::Box::new(gtk::Orientation::Horizontal, 4);
    
    for key in keys.split(" + ") {
        let key_label = gtk::Label::builder()
            .label(key)
            .css_classes(["keyboard-key"])
            .build();
        keys_box.append(&key_label);
        
        // Add + separator except for last key
        if key != keys.split(" + ").last().unwrap_or("") {
            let plus = gtk::Label::builder()
                .label("+")
                .css_classes(["dim-label"])
                .build();
            keys_box.append(&plus);
        }
    }

    row.append(&action_label);
    row.append(&keys_box);

    row
}

/// Animate a widget with a fade-in effect
pub fn fade_in(widget: &gtk::Widget, delay_ms: u64) {
    widget.set_opacity(0.0);
    
    let widget_clone = widget.clone();
    glib::timeout_add_local_once(
        std::time::Duration::from_millis(delay_ms),
        move || {
            widget_clone.set_opacity(1.0);
        }
    );
}
