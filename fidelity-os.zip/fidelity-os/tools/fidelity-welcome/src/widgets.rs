// Custom widgets for FidelityOS Welcome

use gtk4 as gtk;
use gtk::prelude::*;

/// Create a styled card widget
pub fn card(content: &gtk::Widget) -> gtk::Frame {
    let frame = gtk::Frame::builder()
        .child(content)
        .css_classes(["card"])
        .build();
    frame
}

/// Create a feature row with icon and text
pub fn feature_row(icon_name: &str, title: &str, description: &str) -> gtk::Box {
    let row = gtk::Box::new(gtk::Orientation::Horizontal, 16);
    row.add_css_class("feature-row");

    let icon = gtk::Image::builder()
        .icon_name(icon_name)
        .pixel_size(32)
        .css_classes(["feature-row-icon"])
        .build();

    let text_box = gtk::Box::new(gtk::Orientation::Vertical, 4);
    
    let title_label = gtk::Label::builder()
        .label(title)
        .css_classes(["feature-row-title"])
        .halign(gtk::Align::Start)
        .build();

    let desc_label = gtk::Label::builder()
        .label(description)
        .css_classes(["feature-row-desc", "dim-label"])
        .halign(gtk::Align::Start)
        .wrap(true)
        .build();

    text_box.append(&title_label);
    text_box.append(&desc_label);

    row.append(&icon);
    row.append(&text_box);

    row
}

/// Create a pill-shaped button
pub fn pill_button(label: &str, suggested: bool) -> gtk::Button {
    let mut classes = vec!["pill"];
    if suggested {
        classes.push("suggested-action");
    }
    
    gtk::Button::builder()
        .label(label)
        .css_classes(classes)
        .build()
}

/// Create a section header
pub fn section_header(title: &str) -> gtk::Label {
    gtk::Label::builder()
        .label(title)
        .css_classes(["heading"])
        .halign(gtk::Align::Start)
        .margin_top(24)
        .margin_bottom(12)
        .build()
}
