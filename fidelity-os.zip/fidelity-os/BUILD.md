# FidelityOS Build Guide

Complete instructions for building FidelityOS from source on a fresh Debian 12 (Bookworm) server.

## Requirements

- Debian 12 (Bookworm) server or VM
- Minimum 8GB RAM recommended
- 50GB+ free disk space
- Root access

## Quick Build (Copy & Paste)

Run this entire block on a fresh Debian 12 server:

```bash
# 1. Install all required packages
apt update && apt install -y \
    git \
    live-build \
    debootstrap \
    squashfs-tools \
    xorriso \
    grub-pc-bin \
    grub-efi-amd64-bin \
    mtools \
    dosfstools \
    unzip \
    curl \
    wget

# 2. Clone the repository
cd /opt
git clone https://github.com/nexyusss/FidelityOS.git
cd FidelityOS/fidelity-os

# 3. Fix Windows line endings (CRITICAL!)
find . -type f \( -name "*.sh" -o -name "*.chroot" -o -name "*.list.chroot" -o -path "*/auto/*" \) -exec sed -i 's/\r$//' {} \;

# 4. Make scripts executable
chmod +x auto/* scripts/* config/hooks/live/*

# 5. Clean any previous build
sudo lb clean --purge

# 6. Build the ISO
sudo ./scripts/build.sh
```

## Step-by-Step Instructions

### 1. Install Build Dependencies

```bash
apt update
apt install -y \
    git \
    live-build \
    debootstrap \
    squashfs-tools \
    xorriso \
    grub-pc-bin \
    grub-efi-amd64-bin \
    mtools \
    dosfstools \
    unzip \
    curl \
    wget
```

### 2. Clone Repository

```bash
cd /opt
git clone https://github.com/nexyusss/FidelityOS.git
cd FidelityOS/fidelity-os
```

### 3. Fix Line Endings

Windows creates files with CRLF line endings. Linux needs LF only. This step is **critical**:

```bash
find . -type f \( -name "*.sh" -o -name "*.chroot" -o -name "*.list.chroot" -o -path "*/auto/*" \) -exec sed -i 's/\r$//' {} \;
```

### 4. Set Permissions

```bash
chmod +x auto/*
chmod +x scripts/*
chmod +x config/hooks/live/*
```

### 5. Clean Previous Builds

```bash
sudo lb clean --purge
```

### 6. Build ISO

```bash
sudo ./scripts/build.sh
```

Build takes 30-60 minutes depending on server speed and internet connection.

## Output

After successful build, you'll find:
- `fidelity-os-amd64.hybrid.iso` (or similar) in the project directory
- SHA256 checksum printed to console

## Download ISO to Local Machine

### Option 1: SCP (from your local machine)

```powershell
scp root@YOUR_SERVER_IP:/opt/FidelityOS/fidelity-os/*.iso C:\Users\YourName\Downloads\
```

### Option 2: Python HTTP Server (on server)

```bash
cd /opt/FidelityOS/fidelity-os
python3 -m http.server 8080
```

Then download from: `http://YOUR_SERVER_IP:8080/filename.iso`

## Flash to USB

Use one of these tools:
- **Rufus** (Windows) - Recommended, use DD mode
- **balenaEtcher** (Cross-platform)
- **Ventoy** (Multi-ISO USB)

## Troubleshooting

### "command not found" errors
Line endings issue. Re-run the `sed` command in step 3.

### Package not found errors
Check `/etc/apt/sources.list` includes all Debian repos:
```bash
deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
```

### Build fails midway
```bash
sudo lb clean
sudo ./scripts/build.sh
```

### Out of disk space
Need at least 50GB free. Check with `df -h`.

## Rebuild After Changes

```bash
cd /opt/FidelityOS/fidelity-os
git pull
find . -type f \( -name "*.sh" -o -name "*.chroot" -o -name "*.list.chroot" -o -path "*/auto/*" \) -exec sed -i 's/\r$//' {} \;
chmod +x auto/* scripts/* config/hooks/live/*
sudo lb clean
sudo ./scripts/build.sh
```

## Server Costs

If using Linode/cloud:
- **Stop billing**: Delete the server when done (powered off still charges)
- **8GB Linode**: ~$0.06/hour
- Typical build: ~1 hour = ~$0.06

## Support

Issues: https://github.com/nexyusss/FidelityOS/issues
