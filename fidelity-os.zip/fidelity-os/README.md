# FidelityOS

A clean, user-friendly Debian-based Linux distribution.

## Quick Build

### Prerequisites (WSL Debian)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install build dependencies
sudo apt install -y live-build debootstrap git
```

### Build ISO

```bash
cd fidelity-os
sudo ./scripts/build.sh
```

The ISO will be created in the `fidelity-os` directory.

### Test in VM

1. Copy the `.iso` file to Windows
2. Create a new VM in VirtualBox/VMware
3. Mount the ISO and boot

## Project Structure

```
fidelity-os/
├── auto/                    # live-build configuration
├── config/
│   ├── package-lists/       # Package selections
│   ├── includes.chroot/     # Files included in image
│   └── hooks/               # Build-time scripts
├── scripts/
│   └── build.sh             # Main build script
└── README.md
```

## Features

- Debian Bookworm base
- GNOME desktop (Wayland default)
- Flatpak + Flathub enabled
- Firefox with privacy settings
- UFW firewall enabled
- AppArmor security

## License

GPL-3.0
